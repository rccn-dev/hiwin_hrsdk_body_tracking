﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using SDKHrobot;

namespace _09.SyncOutput {
    class Program {
        private static HRobot.CallBackFun callback = new HRobot.CallBackFun( EventFun );
        static void Main( string[] args ) {
            StringBuilder SDK_ver = new StringBuilder();
            StringBuilder HRS_ver = new StringBuilder();
            SDKHrobot.HRobot.get_hrsdk_version( SDK_ver );
            Console.WriteLine( "SDK version: " + SDK_ver );
            int device_id = HRobot.open_connection( "127.0.0.1", 1, callback );
            HRobot.set_motor_state( device_id, 1 );
            if ( device_id >= 0 ) {
                SDKHrobot.HRobot.get_hrss_version( device_id, HRS_ver );
                Console.WriteLine( "HRS version: " + HRS_ver );
                Console.WriteLine( "connect successful." );
                SyncOutput( device_id, callback );

                Console.WriteLine( "\n Press \"Enter\" key to quit the program." );
                Console.ReadLine();
                SDKHrobot.HRobot.disconnect( device_id );
            } else {
                Console.WriteLine( "connect failure." );
            }
        }

        public static bool wait_for_stop_motion( int device_id ) {
            while ( HRobot.get_motion_state( device_id ) != 1 ) {
                if ( HRobot.get_connection_level( device_id ) == -1 ) {
                    return false;  // The robot is not connected anymore
                }
                Thread.Sleep( 200 );
            }
            return true;
        }

        public static void SyncOutput( int device_id, HRobot.CallBackFun callback ) {
            double[] p1 = { -10, -200, -90, 0, 0, 0 };
            double[] p2 = { 10, 150, -90, 0, 0, 0 };
            int type = 0;  //DO
            int id = 1;
            int ON = 1;
            int OFF = 0;
            int delay = 1000;
            int distance = 50;
            int Start = 0;
            int End = 1;
            int Path = 2;
            bool[] is_on = new bool[8];

            for ( int i = 1; i <= 8; i++ ) {
                HRobot.set_digital_output( device_id, i, false );
            }
            HRobot.set_override_ratio( device_id, 100 );
            Console.WriteLine( "jog home \n" );
            HRobot.jog_home( device_id );
            wait_for_stop_motion( device_id );
            HRobot.set_override_ratio( device_id, 10 );
            Thread.Sleep( 100 );

            Console.WriteLine( "Syncoutput test \n" );
            HRobot.lin_rel_pos( device_id, 0, 0, p1 );
            HRobot.SyncOutput( device_id, type, id, ON, Start, delay, distance );
            HRobot.SyncOutput( device_id, type, 2, ON, Path, -1000, distance );
            HRobot.SyncOutput( device_id, type, 3, ON, Path, 0, distance );
            HRobot.SyncOutput( device_id, type, 4, ON, Path, delay, distance );
            HRobot.SyncOutput( device_id, type, 5, ON, Path, -1000, -50 );
            HRobot.SyncOutput( device_id, type, 6, ON, Path, 0, -50 );
            HRobot.SyncOutput( device_id, type, 7, ON, Path, 1000, -50 );
            HRobot.SyncOutput( device_id, type, 8, ON, End, -1000, distance );
            HRobot.lin_rel_pos( device_id, 0, 0, p2 );

            while ( true ) {
                if ( HRobot.get_motion_state( device_id ) == 1 ) {
                    break;
                }
                for ( int i = 1; i <= 8; i++ ) {
                    if ( HRobot.get_digital_output( device_id, i ) == 1 && is_on[i - 1] != true ) {
                        Console.WriteLine( "Digital output [{0}] is ON \n", i );
                        is_on[i - 1] = true;
                    }
                }
                Thread.Sleep( 200 );
            }
        }

        public static void EventFun( UInt16 cmd, UInt16 rlt, ref UInt16 Msg, int len ) {
            //Console.WriteLine( Msg );
        }
    }
}
