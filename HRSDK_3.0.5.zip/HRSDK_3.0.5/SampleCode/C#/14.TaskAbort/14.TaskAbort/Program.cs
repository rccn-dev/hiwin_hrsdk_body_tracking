﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using SDKHrobot;

namespace _14.TaskAbort {
    class Program {
        private static int device_id = -1;
        private static HRobot.CallBackFun callback = new HRobot.CallBackFun( EventFun );
        private static bool is_task_abort = false;

        static void Main( string[] args ) {
            string connect_ip = "";
            Console.WriteLine( "Input robot IP:" );
            connect_ip = Console.ReadLine();
            device_id = HRobot.open_connection( connect_ip, 1, callback );
            //device_id = HRobot.open_connection( "127.0.0.1", 1, callback );

            StringBuilder sdk_version = new StringBuilder();
            StringBuilder HRS_ver = new StringBuilder();
            HRobot.get_hrsdk_version( sdk_version );
            Console.WriteLine( "sdk version: " + sdk_version );
            if ( device_id >= 0 ) {
                HRobot.get_hrss_version( device_id, HRS_ver );
                Console.WriteLine( "HRS version: " + HRS_ver );
                Console.WriteLine( "connect successful." );
                HRobot.set_motor_state( device_id, 1 );

                TaskAbortExample();

                Console.WriteLine( " \n Please press enter key to end." );
                Console.ReadLine();
                HRobot.disconnect( device_id );
            } else {
                Console.WriteLine( "connect failure." );
                Console.ReadLine();
            }
        }

        private static void TaskAbortExample() {
            double[] dest_pos = new double[6];
            int pos_count = 100;
            HRobot.set_override_ratio( device_id, 5 );

            dest_pos[0] = 0;
            dest_pos[1] = 350;
            dest_pos[2] = 290;
            dest_pos[3] = -170;
            dest_pos[4] = 0;
            dest_pos[5] = 80;

            HRobot.lin_pos( device_id, 1, 100, new double[] { 0, 350, 230, -170, 0, 80 } );
            Thread.Sleep( 2000 );

            HRobot.motion_abort( device_id );
            is_task_abort = true;
            HRobot.task_abort( device_id );

            WaitForTaskAboutFinish();

            for ( int i = 0; i < pos_count; i++ ) {
                dest_pos[0] -= 1;
                HRobot.lin_pos( device_id, 1, 100, dest_pos );
            }
            for ( int i = 0; i < pos_count; i++ ) {
                dest_pos[0] += 1;
                HRobot.lin_pos( device_id, 1, 100, dest_pos );
            }

            System.Threading.Thread thread_show_pos = new System.Threading.Thread( () => {
                double[] pos = new double[9];
                int rlt = 0;
                while ( true ) {
                    rlt =  HRobot.get_current_position( device_id, pos );
                    Console.WriteLine( string.Format( "pos: {0}, {1}, {2}, {3}, {4}, {5}",
                                                      pos[0], pos[1], pos[2], pos[3], pos[4], pos[5] ) );
                    if ( rlt != 0 ) {
                        return;
                    }
                    Thread.Sleep( 1000 );
                }
            } );
            thread_show_pos.Start();
        }

        private static bool WaitForTaskAboutFinish() {
            int counter = 0;
            while ( is_task_abort ) {
                if ( counter > 30 ) {
                    Console.WriteLine( "task_abort timeout." );
                    return false;
                }
                counter++;
                Thread.Sleep( 100 );
            }
            return true;
        }

        public static void EventFun( UInt16 cmd, UInt16 rlt, ref UInt16 Msg, int len ) {
            //Console.WriteLine( "[Notify] Command: " + cmd + "  Result: " + rlt + "  Msg:  " + Msg );
            if ( cmd == 4004 ) {
                switch ( rlt ) {
                    case 4018:
                        Console.WriteLine( "[Notify] task_abort finish." );
                        is_task_abort = false;
                        break;
                }
            }
        }
    }
}
