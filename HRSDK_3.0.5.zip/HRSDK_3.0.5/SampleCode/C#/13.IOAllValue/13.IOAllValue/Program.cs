using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using SDKHrobot;

namespace _13_IOAllValue {
    class Program {
        private static SDKHrobot.HRobot.CallBackFun callback = new SDKHrobot.HRobot.CallBackFun( EventFun );
        static void Main( string[] args ) {
            StringBuilder SDK_ver = new StringBuilder();
            StringBuilder HRS_ver = new StringBuilder();
            SDKHrobot.HRobot.get_hrsdk_version( SDK_ver );
            Console.WriteLine( "SDK version: " + SDK_ver );
            int device_id = SDKHrobot.HRobot.open_connection( "127.0.0.1", 1, callback );
            if ( device_id >= 0 ) {
                SDKHrobot.HRobot.get_hrss_version( device_id, HRS_ver );
                Console.WriteLine( "HRS version: " + HRS_ver );
                Console.WriteLine( "connect successful." );

                GetDIO( device_id );
                GetCounter( device_id );
                GetTimer( device_id );
                GetSystemIO( device_id );
                GetSIO( device_id );
                GetMIO( device_id );
                GetPR( device_id );

                SetDIO( device_id );
                SetReg( device_id );
                SetFieldbus( device_id );
                SetIO( device_id );

                SDKHrobot.HRobot.disconnect( device_id );
            } else {
                Console.WriteLine( "connect failure." );
            }

            Console.WriteLine( "\n Press \"Enter\" key to quit the program." );
            Console.ReadLine();
        }

        public static bool ShowComment( ref int idx, int[]values, UInt16[] comment, int next_idx, string type_str ) {
            string str = "";
            for ( int j = 0; j < comment[0]; j++ ) {
                str += ( char )comment[j + 1];
            }
            string[] str_split = str.Split( '\t' );
            for ( int k = 0; k < str_split.Length; k++ ) {
                if ( idx - 1 < 0 || idx > values.Length ) {
                    break;
                }
                Console.WriteLine( string.Format( $"{type_str}[{idx}]:{values[idx-1]}  {str_split[k]} " ) );
                idx += 1;
            }
            Array.Clear( comment, 0, comment.Length );
            if ( next_idx != 0 ) {
                idx = next_idx - 1;
            } else {
                return true;
            }
            return false;
        }

        public static void GetDIO( int device_id ) {
            int[] di_values = new int[48];
            int[] do_values = new int[48];
            UInt16[] comment = new UInt16[250];
            HRobot.get_DI_range( device_id, 1, 48, di_values );
            HRobot.get_DO_range( device_id, 1, 48, do_values );
            for ( int idx = 1; idx <= 48; idx++ ) {
                int next_comment = 0;
                int rlt = HRobot.get_DI_comment_range( device_id, idx, 48, comment, ref next_comment );
                if ( rlt != 0 ) {
                    continue;
                }
                bool is_end = ShowComment( ref idx, di_values, comment, next_comment, "DI" );
                if ( is_end ) {
                    break;
                }
            }
            Console.WriteLine();
        }

        public static void GetCounter( int device_id ) {
            const int MAX_COUNTER_NUM = 20;
            int[] values = new int[MAX_COUNTER_NUM];
            UInt16[] comment = new UInt16[250];
            HRobot.get_counter_value_all( device_id, values );
            for ( int idx = 1; idx <= MAX_COUNTER_NUM; idx++ ) {
                int next_comment = 0;
                int rlt = HRobot.get_counter_comment_range( device_id, idx, MAX_COUNTER_NUM, comment, ref next_comment );
                if ( rlt != 0 ) {
                    continue;
                }
                bool is_end = ShowComment( ref idx, values, comment, next_comment, "Counter" );
                if ( is_end ) {
                    break;
                }
            }
            Console.WriteLine();
        }

        public static void GetTimer( int device_id ) {
            const int MAX_TIMER_NUM = 20;
            int[] values = new int[MAX_TIMER_NUM];
            int[] status = new int[MAX_TIMER_NUM];
            UInt16[] comment = new UInt16[250];
            HRobot.get_timer_value_all( device_id, values );
            HRobot.get_timer_status_all( device_id, status );
            for ( int idx = 1; idx <= MAX_TIMER_NUM; idx++ ) {
                int next_comment = 0;
                int rlt = HRobot.get_timer_comment_range( device_id, idx, MAX_TIMER_NUM, comment, ref next_comment );
                if ( rlt != 0 ) {
                    continue;
                }
                bool is_end = ShowComment( ref idx, values, comment, next_comment, "Timer" );
                if ( is_end ) {
                    break;
                }
            }
            Console.WriteLine();
        }

        public static void GetSystemIO( int device_id ) {
            const int SYSTEM_IO_MAX_NUM = 11;
            int[] in_value = new int[SYSTEM_IO_MAX_NUM];
            int[] out_value = new int[SYSTEM_IO_MAX_NUM];
            UInt16[] in_comment = new UInt16[250];
            UInt16[] out_comment = new UInt16[250];
            HRobot.get_system_input_all( device_id, in_value, in_comment );
            HRobot.get_system_output_all( device_id, out_value, out_comment );
            int next_comment = 0;
            for ( int idx = 1; idx <= SYSTEM_IO_MAX_NUM; idx++ ) {
                bool is_end = ShowComment( ref idx, in_value, in_comment, next_comment, "System In" );
                if ( is_end ) {
                    break;
                }
            }
            for ( int idx = 1; idx <= SYSTEM_IO_MAX_NUM; idx++ ) {
                bool is_end = ShowComment( ref idx, out_value, out_comment, next_comment, "System Out" );
                if ( is_end ) {
                    break;
                }
            }
            Console.WriteLine();
        }

        public static void GetSIO( int device_id ) {
            int[] si_values = new int[128];
            int[] so_values = new int[128];
            UInt16[] comment = new UInt16[250];
            HRobot.get_SI_range( device_id, 1, 128, si_values );
            HRobot.get_SI_range( device_id, 129, 256, si_values );
            HRobot.get_SO_range( device_id, 1, 128, so_values );
            HRobot.get_SO_range( device_id, 129, 256, so_values );
            for ( int idx = 1; idx <= 48; idx++ ) {
                int next_comment = 0;
                int rlt = HRobot.get_SI_comment_range( device_id, idx, 128, comment, ref next_comment );
                if ( rlt != 0 ) {
                    continue;
                }
                bool is_end = ShowComment( ref idx, si_values, comment, next_comment, "SI" );
                if ( is_end ) {
                    break;
                }
            }
            Console.WriteLine();
        }

        public static void GetMIO( int device_id ) {
            const int MIO_COUNT = 32;
            int[] sim = new int[MIO_COUNT];
            int[] values = new int[MIO_COUNT];
            int[] types = new int[MIO_COUNT];
            int[] starts = new int[MIO_COUNT];
            int[] ends = new int[MIO_COUNT];
            UInt16[] comment = new UInt16[250];
            HRobot.get_MI_config_all( device_id, sim, values, types, starts, ends );
            for ( int i = 0; i < MIO_COUNT; i++ ) {
                Console.WriteLine( $"MI[{i}] sim:{sim[i]} value:{values[i]} type:{types[i]} start:{starts[i]} end:{ends[i]}" );
            }
            Console.WriteLine();

            HRobot.get_MO_config_all( device_id, values, types, starts, ends );
            for ( int i = 0; i < MIO_COUNT; i++ ) {
                Console.WriteLine( $"MO[{i}] value:{values[i]} type:{types[i]} start:{ starts[i]} end:{ends[i]}"  );
            }
            Console.WriteLine();
        }

        public static void GetPR( int device_id ) {
            UInt16[] pr_comment = new UInt16[250];
            int next_idx = 0;
            int[] idx_array = new int[100];
            for ( int i = 0; i < 100; i++ ) {
                idx_array[i] = i + 1;
            }
            for ( int idx = 1; idx < 100; idx++ ) {
                int rlt = HRobot.get_PR_comment_array( device_id, idx_array, idx, 100, pr_comment, ref next_idx );
                if ( rlt != 0 ) {
                    continue;
                }
                string str = "";
                for ( int j = 0; j < pr_comment[0]; j++ ) {
                    str += ( char )pr_comment[j + 1];
                }
                string[] str_split = str.Split( '\t' );
                for ( int k = 0; k < str_split.Length; k++ ) {
                    if ( idx - 1 < 0 ) {
                        break;
                    }
                    Console.WriteLine( string.Format( $"PR[{idx}]: {str_split[k]} " ) );
                    idx += 1;
                }
                Array.Clear( pr_comment, 0, pr_comment.Length );
                if ( next_idx != 0 ) {
                    idx = next_idx - 1;
                } else {
                    break;
                }
            }
        }



        public static void SetDIO( int device_id ) {
            const int len = 8;
            int[] indexes = new int[len] { 2, 14, 3, 6, 8, 11, 15, 1 };
            int[] values = new int[len] { 1, 1, 1, 1, 0, 1, 1, 0 };
            HRobot.set_DI_sim_array( device_id, indexes, values, len );
            HRobot.set_DI_array( device_id, indexes, values, len );
            HRobot.set_DO_array( device_id, indexes, values, len );
        }

        public static void SetReg( int device_id ) {
            const int len = 8;
            int[] indexes = new int[len] { 2, 14, 3, 6, 8, 11, 15, 1 };
            int[] values = new int[len] { 111, 222, 123456, 654321, 500, 600, 700, 800 };
            HRobot.set_timer_value_array( device_id, indexes, values, len );
            HRobot.set_counter_array( device_id, indexes, values, len );
        }

        public static void SetFieldbus( int device_id ) {
            const int len = 8;
            int[] indexes = new int[len] { 2, 14, 3, 6, 8, 11, 15, 1 };
            int[] values1 = new int[len] { 1, 1, 1, 1, 0, 1, 1, 0 };
            int[] values2 = new int[len] { 111, 222, -1256, 6321, -500, 600, 700, -800 };
            HRobot.set_SI_sim_array( device_id, indexes, values1, len );
            HRobot.set_SI_array( device_id, indexes, values1, len );
            HRobot.set_SO_array( device_id, indexes, values1, len );
            HRobot.set_fieldbus_srw_array( device_id, indexes, values2, len );
        }

        public static void SetIO( int device_id ) {
            int len = 5;
            int[] indexes1 = new int[5] { 1, 2, 3, 4, 5 };
            int[] values1 = new int[5] { 1, 1, 0, 1, 1 };
            int[] vo_idx = new int[3] { 1, 2, 3 };
            int[] vo_val = new int[3] { 1, 0, 1 };
            int[] get_val = new int[8];
            HRobot.set_MO_array( device_id, indexes1, values1, len );
            HRobot.set_RO_array( device_id, indexes1, values1, len );
            HRobot.set_VO_array( device_id, vo_idx, vo_val, 3 );
            HRobot.get_RO_all( device_id, get_val );
            Console.Write( "RO: " );
            for ( int i = 0; i < 8; i++ ) {
                Console.Write( "{0} ", get_val[i] );
            }
            Console.Write( "\nVO: " );
            HRobot.get_VO_all( device_id, get_val );
            for ( int i = 0; i < 3; i++ ) {
                Console.Write( "{0} ", get_val[i] );
            }
            Console.WriteLine();
        }

        public static void EventFun( UInt16 cmd, UInt16 rlt, ref UInt16 Msg, int len ) {
            //Console.WriteLine( "Command: " + cmd + " Resault: " + rlt );
        }
    }
}