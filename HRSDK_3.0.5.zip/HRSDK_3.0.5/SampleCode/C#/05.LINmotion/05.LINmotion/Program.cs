﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using SDKHrobot;

namespace _05_LINmotion {
    class Program {
        private static SDKHrobot.HRobot.CallBackFun callback = new SDKHrobot.HRobot.CallBackFun( EventFun );
        static void Main( string[] args ) {
            StringBuilder SDK_ver = new StringBuilder();
            StringBuilder HRS_ver = new StringBuilder();
            SDKHrobot.HRobot.get_hrsdk_version( SDK_ver );
            Console.WriteLine( "SDK version: " + SDK_ver );
            int device_id = SDKHrobot.HRobot.open_connection( "127.0.0.1", 1, callback );
            if ( device_id >= 0 ) {
                SDKHrobot.HRobot.get_hrss_version( device_id, HRS_ver );
                Console.WriteLine( "HRS version: " + HRS_ver );
                Console.WriteLine( "connect successful." );

                LINMotion( device_id, callback );
                Console.WriteLine( "\n Press \"Enter\" key to quit the program." );
                Console.ReadLine();
                SDKHrobot.HRobot.disconnect( device_id );
            } else {
                Console.WriteLine( "connect failure." );
                return;
            }
        }

        public static bool wait_for_stop_motion( int device_id ) {
            while ( HRobot.get_motion_state( device_id ) != 1 ) {
                if ( HRobot.get_connection_level( device_id ) == -1 ) {
                    return false;  // The robot is not connected anymore
                }
                Thread.Sleep( 200 );
            }
            return true;
        }

        public static void run_lin_pos( int device_id, double[][] pos, int mode, double smooth_value ) {
            HRobot.lin_pos( device_id, mode, smooth_value, pos[0] );
            HRobot.lin_pos( device_id, mode, smooth_value, pos[1] );
            HRobot.lin_pos( device_id, mode, smooth_value, pos[2] );
            HRobot.lin_pos( device_id, mode, smooth_value, pos[3] );
            HRobot.lin_pos( device_id, mode, smooth_value, pos[0] );
            wait_for_stop_motion( device_id );
        }


        public static void LINMotion( int device_id, SDKHrobot.HRobot.CallBackFun callback ) {
            SDKHrobot.HRobot.set_override_ratio( device_id, 100 );
            if ( SDKHrobot.HRobot.get_motor_state( device_id ) == 0 ) {
                SDKHrobot.HRobot.set_motor_state( device_id, 1 ); // Servo on
                Thread.Sleep( 3000 );
            }

            double[][] pos = {
                new double[] { -150, 450, -50, 0, 0, 0 },
                new double[] { 150, 450, -100, 0, 0, 0 },
                new double[] { 150, 300, -150, 0, 0, 0 },
                new double[] { -150, 300, -200, 0, 0, 0 }
            };
            double[][] rel_pos = {
                new double[] { 0, -200, 0, 0, 0, 0 },
                new double[] { 0, 100, 0, 0, 0, 0 },
                new double[] { -50, 0, 0, 0, 0, 0 },
                new double[] { 0, -100, 0, 0, 0, 0 },
                new double[] { 0, 200, 0, 0, 0, 0 },
                new double[] { -50, 0, 0, 0, 0, 0 },
                new double[] { 0, -200, 0, 0, 0, 0 },
            };

            HRobot.jog_home( device_id );
            wait_for_stop_motion( device_id );

            // lin motion
            Console.WriteLine( "Run line position. \n" );
            run_lin_pos( device_id, pos, 0, 0 );

            Console.WriteLine( "Run line relative position \n" );
            double[] lin_rel_home = { 0, 480, -60, 0, 0, 0 };
            double[] ext_pos = { 0, 0, 0 };
            HRobot.lin_pos( device_id, 0, 0, lin_rel_home );
            Thread.Sleep( 1000 );
            for ( int i = 0; i < rel_pos.Length; i++ ) {
                HRobot.lin_rel_pos( device_id, 0, 0, rel_pos[i] );
                wait_for_stop_motion( device_id );
            }

            // rel_pr
            Console.WriteLine( "Run line point register \n" );
            HRobot.set_pr( device_id, 1, 0, lin_rel_home, ext_pos, 0, 0 );
            HRobot.lin_pr( device_id, 0, 0, 1 );
            wait_for_stop_motion( device_id );

        }

        public static void EventFun( UInt16 cmd, UInt16 rlt, ref UInt16 Msg, int len ) {
            //Console.WriteLine( "Command: " + cmd + " Resault: " + rlt );
        }
    }
}