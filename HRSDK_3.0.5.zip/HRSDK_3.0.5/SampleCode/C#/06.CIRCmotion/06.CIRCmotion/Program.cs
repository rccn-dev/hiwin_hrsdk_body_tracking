﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace _06_CIRCmotion {
    class Program {
        private static SDKHrobot.HRobot.CallBackFun callback = new SDKHrobot.HRobot.CallBackFun( EventFun );
        static void Main( string[] args ) {
            StringBuilder SDK_ver = new StringBuilder();
            StringBuilder HRS_ver = new StringBuilder();
            SDKHrobot.HRobot.get_hrsdk_version( SDK_ver );
            Console.WriteLine( "SDK version: " + SDK_ver );
            int device_id = SDKHrobot.HRobot.open_connection( "127.0.0.1", 1, callback );
            if ( device_id >= 0 ) {
                SDKHrobot.HRobot.get_hrss_version( device_id, HRS_ver );
                Console.WriteLine( "HRS version: " + HRS_ver );
                Console.WriteLine( "connect successful." );
                CIRCMotion( device_id, callback );
                Console.WriteLine( "\n Press \"Enter\" key to quit the program." );
                Console.ReadLine();
                SDKHrobot.HRobot.disconnect( device_id );
            } else {
                Console.WriteLine( "connect failure." );
                return;
            }
        }
        public static void CIRCMotion( int device_id, SDKHrobot.HRobot.CallBackFun callback ) {
            if ( SDKHrobot.HRobot.get_motor_state( device_id ) == 0 ) {
                SDKHrobot.HRobot.set_motor_state( device_id, 1 ); // Servo on
                Thread.Sleep( 3000 );
            }

            double[] cp1 = { -90, 400, -90, 0, 0, 0 };
            double[] cp2 = { -60, 350, -90, 0, 0, 0 };
            double[] cp3 = { 30, 300, -90, 0, 0, 0 };
            double[] cp4 = { -75, 350, -90, 0, 0, 0 };
            double[] cp5 = { 26, -80, -90, 0, 0, 0 };
            double[] cp6 = { 32, -70, -90, 0, 0, 0 };
            double[] cp7 = { 41, -70, -90, 0, 0, 0 };
            double[] cp8 = { 37, -83, -90, 0, 0, 0 };
            double[] Home = { 0, 0, 0, 0, -90, 0 };
            double[] ext_pos = { 0, 0, 0 };

            Console.WriteLine( "run CIRC motion." );
            SDKHrobot.HRobot.set_override_ratio( device_id, 100 ); //override speed ratio
            SDKHrobot.HRobot.ptp_axis( device_id, 0, Home ); //ptp to axis home

            SDKHrobot.HRobot.ptp_pos( device_id, 0, cp1 );
            SDKHrobot.HRobot.circ_pos( device_id, 0, cp2, cp3 ); // circ motion
            SDKHrobot.HRobot.circ_pos( device_id, 0, cp4, cp1 );
            SDKHrobot.HRobot.circ_axis( device_id, 0, cp5, cp6 );
            SDKHrobot.HRobot.circ_axis( device_id, 0, cp7, cp8 );
            SDKHrobot.HRobot.set_pr( device_id, 2, 0, cp2, ext_pos, 0, 0 );
            SDKHrobot.HRobot.set_pr( device_id, 3, 0, cp3, ext_pos, 0, 0 );
            SDKHrobot.HRobot.circ_pr( device_id, 0, 2, 3 );
            Thread.Sleep( 5000 );

        }

        public static void EventFun( UInt16 cmd, UInt16 rlt, ref UInt16 Msg, int len ) {
            //Console.WriteLine( "Command: " + cmd + " Resault: " + rlt );
        }
    }
}