﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using SDKHrobot;


namespace _11.CallbackNotify {
    class Program {
        static int device_id = -1;
        static bool show_notify = true;
        static bool show_command_msg = false;
        private static HRobot.CallBackFun callback = new HRobot.CallBackFun( EventFun );
        static void Main( string[] args ) {
            device_id = HRobot.open_connection( "127.0.0.1", 1, callback );
            Thread.Sleep( 1000 );
            StringBuilder sdk_version = new StringBuilder( 30 );
            HRobot.get_hrsdk_version( sdk_version );
            Console.WriteLine( "sdk version: " + sdk_version );
            if ( device_id >= 0 ) {
                Console.WriteLine( "connect successful." );
                HRobot.set_motor_state( device_id, 1 );
                Notify();
                Console.ReadKey();
                HRobot.disconnect( device_id );
            } else {
                Console.WriteLine( "connect failure." );
                Console.ReadKey();
            }
        }

        public static void EventFun( UInt16 cmd, UInt16 rlt, ref UInt16 Msg, int len ) {
            //Console.Clear();
            String info_p = "";
            unsafe {
                fixed ( UInt16* p = &Msg ) {
                    for ( int i = 0; i < len; i++ ) {
                        info_p += ( char )p[i];
                    }
                }
            }

            if ( rlt != 4702 ) {
                if ( show_command_msg ) {
                    Console.WriteLine( "Command: " + cmd + "  Result: " + rlt + "  Msg: " + info_p + "  len: " + len );
                }
            }
            if ( cmd == 0 ) {
                string[] info = info_p.Split( ',' );
                switch ( rlt ) {
                    case 4030:
                        Console.WriteLine( "[Notify] HRSS alarm notify: " + info_p );
                        break;
                    case 4145:
                        Console.WriteLine( "[Notify] System Output {0}: {1}", info[0], info[1] );
                        break;
                    case 4702:
                        if ( show_notify ) {
                            Console.WriteLine( "[Notify] Robot Information" );
                            Console.WriteLine( "[Notify] HRSS Mode: " + info[0] );
                            Console.WriteLine( "[Notify] Operation Mode: " + info[1] );
                            Console.WriteLine( "[Notify] Override Ratio: " + info[2] );
                            Console.WriteLine( "[Notify] Motor State: " + info[3] );
                            Console.WriteLine( "[Notify] Exe File Name: " + info[4] );
                            Console.WriteLine( "[Notify] Function Output: " + info[5] );
                            Console.WriteLine( "[Notify] Alarm Count: " + info[6] );
                            Console.WriteLine( "[Notify] Keep Alive: " + info[7] );
                            Console.WriteLine( "[Notify] Motion Status: " + info[8] );
                            Console.WriteLine( "[Notify] payload: " + info[9] );
                            Console.WriteLine( "[Notify] Speed: " + info[10] ); // safe: 0   normal: 1
                            Console.WriteLine( "[Notify] Position: " + info[11] );
                            Console.WriteLine( "[Notify] Coor: {0}, {1}, {2}, {3}, {4}, {5} ", info[14], info[15], info[16], info[17], info[18], info[19] );
                            Console.WriteLine( "[Notify] Joint: {0}, {1}, {2}, {3}, {4}, {5} ", info[20], info[21], info[22], info[23], info[24], info[25] );
                            Console.WriteLine( "" );
                        }
                        break;
                    case 4703:
                        Console.WriteLine( "[Notify] Timer {0}: {1} ", Int32.Parse( info[0] ) + 1, info[1] );
                        break;
                    case 4704:
                        Console.WriteLine( "[Notify] Counter {0}: {1}", Int32.Parse( info[0] ) + 1, info[1] );
                        break;
                    case 4705:
                        Console.WriteLine( "[Notify] MI {0}: {1}", Int32.Parse( info[0] ) + 1, info[1] );
                        break;
                    case 4706:
                        Console.WriteLine( "[Notify] MO {0}: {1}", Int32.Parse( info[0] ) + 1, info[1] );
                        break;
                    case 4707:
                        Console.WriteLine( "[Notify] SI {0}: {1}", Int32.Parse( info[0] ) + 1, info[1] );
                        break;
                    case 4708:
                        Console.WriteLine( "[Notify] SO {0}: {1}", Int32.Parse( info[0] ) + 1, info[1] );
                        break;
                    case 4710:
                        ShowPRNotification( info );
                        break;
                    case 4711:
                        Console.WriteLine( "[Notify] DI {0}: {1}", Int32.Parse( info[0] ), info[1] );
                        break;
                    case 4712:
                        Console.WriteLine( "[Notify] DO {0}: {1}", Int32.Parse( info[0] ), info[1] );
                        break;
                    case 4714:
                        Console.WriteLine( "[Notify] Utilization start notify: " + info_p );
                        break;
                    case 4715:
                        Console.WriteLine( "[Notify] Utilization end notify: " + info_p );
                        break;
                }
            } else if ( cmd == 1450 ) {
                switch ( rlt ) {
                    case 4028:
                        Console.WriteLine( "[Notify] HRSS start clear alarm" );
                        break;
                    case 4029:
                        Console.WriteLine( "[Notify] HRSS finish clear alarm" );
                        break;
                }
            } else if ( cmd == 1456 ) {
                Console.WriteLine( "[Notify] SET_SPEED_LIMIT: " + Msg );
            } else if ( cmd == 2161 ) {
                switch ( rlt ) {
                    case 0:
                        Console.WriteLine( "[Notify] DOWNLOAD_LOG_FILE: " + Msg );
                        break;
                    case 201:
                        Console.WriteLine( "[Notify] FILE_IS_NOT_EXIST: " + Msg );
                        break;
                }
            } else if ( cmd == 4000 ) {
                switch ( rlt ) {
                    case 0:
                        Console.WriteLine( "[Notify] run ext task start cmd: " );
                        break;
                    case 201:
                        Console.WriteLine( "[Notify] ext task already exist." );
                        break;
                }
            } else if ( cmd == 4001 ) {
                switch ( rlt ) {
                    case 2006:
                        Console.WriteLine( "[Notify] task start motion already exist." );
                        break;
                    case 4012:
                        Console.WriteLine( "[Notify] task start file name error." );
                        break;
                    case 4013:
                        Console.WriteLine( "[Notify] task start already exist." );
                        break;
                    case 4014:
                        Console.WriteLine( "[Notify] task start Run." );
                        break;
                }

            } else if ( cmd == 4004 ) {
                switch ( rlt ) {
                    case 4018:
                        Console.WriteLine( "[Notify] task abort finish." );
                        break;
                }
            } else if ( cmd == 4009 ) {
                switch ( rlt ) {
                    case 0:
                        Console.WriteLine( "[Notify] Download file." );
                        break;
                    case 201:
                        Console.WriteLine( "[Notify] File is not exist." );
                        break;
                }
            } else if ( cmd == 4010 ) {
                Console.WriteLine( "[Notify] Send file." );
            } else if ( cmd == 4018 ) {
                Console.WriteLine( "[Notify] SAVE_DATABASE" );
            } else if ( cmd == 4019 ) {
                Console.WriteLine( "[Notify] LOAD_DATABASE" );
            } else if ( cmd == 4709 ) {
                Console.WriteLine( "[Notify] Save module IO." );
            }

            void ShowPRNotification( string[] info ) {
                int pr_len = Convert.ToInt32( info[0] );
                int pr_type = -1, pr_num = -1;

                for ( int i = 0; i < pr_len; i++ ) {
                    pr_num = Convert.ToInt32( info[1 + 11 * i] );
                    pr_type = Convert.ToInt32( info[2 + 11 * i] );
                    Console.WriteLine( "[Notify] PR {0}: {1} \n" +
                                       "Pos: {2}, {3}, {4}, {5}, {6}, {7} Ext: {8}, {9}, {10}", pr_num, pr_type, // Type  1:Degree  2:Cartesian
                                       info[3 + 11 * i], info[4 + 11 * i], info[5 + 11 * i], info[6 + 11 * i], info[7 + 11 * i], info[8 + 11 * i],
                                       info[9 + 11 * i], info[10 + 11 * i], info[11 + 11 * i] );
                }
            }
        }
        public static int rand( int min, int max ) {
            var rand = new Random();
            int rand_re = rand.Next() % ( max - min ) + min;
            return rand_re;
        }
        public static void Notify() {
            show_notify = true;
            show_command_msg = false;
            if ( show_notify ) {
                double[] pos = new double[6];
                HRobot.get_current_position( device_id, pos );   // 必須有這一行
            }
            Thread.Sleep( 2000 );
            show_notify = false;

            //// IO and register notify
            HRobot.set_timer( device_id, 1, rand( 1, 1000 ) );
            Thread.Sleep( 200 );
            HRobot.set_counter( device_id, 1, rand( 1, 1000 ) );
            Thread.Sleep( 200 );
            HRobot.set_module_input_simulation( device_id, 0, true );
            Thread.Sleep( 200 );
            HRobot.set_module_input_value( device_id, 0, true );
            Thread.Sleep( 200 );
            HRobot.set_module_output_value( device_id, 0, false );
            Thread.Sleep( 200 );
            HRobot.set_pr_type( device_id, 2, 0 );
            Thread.Sleep( 200 );
            HRobot.set_digital_output( device_id, 1, false );
            Thread.Sleep( 200 );
            HRobot.set_DI_simulation_Enable( device_id, 1, false );
            Thread.Sleep( 200 );
            HRobot.set_DI_simulation( device_id, 1, false );
            Thread.Sleep( 2000 );
            Console.WriteLine();

            // alarm notify
            double[] p1 = { 0, 0, 0, 0, 0, 10 };
            double[] p2 = { 0, 0, 0, 0, 0, 10};
            int count = 0;
            ulong[] alarm_code = new ulong[20];

            HRobot.circ_axis( device_id, 0, p1, p2 );
            Thread.Sleep( 200 );
            int alarm_count = HRobot.get_alarm_code( device_id, ref count, alarm_code );
            if ( count > 0 ) {
                HRobot.clear_alarm( device_id );
            }
            Console.WriteLine();

            // send and download file
            Thread.Sleep( 1000 );
            HRobot.send_file( device_id, "../../../test_LR.hrb", "test_LR.hrb" );
            Thread.Sleep( 1000 );
            HRobot.download_file( device_id, "tesat_LR.hrb", "test_LR.hrb" );
            Thread.Sleep( 1000 );
            Console.WriteLine();

            // task_start motion exist.
            double[] p3 = { 40, 0, 0, 0, 0, 0 };
            HRobot.ptp_axis( device_id, 0, p3 );
            Thread.Sleep( 500 );
            HRobot.task_start( device_id, "test_LR.hrb" );
            Thread.Sleep( 200 );
            HRobot.motion_abort( device_id );
            Thread.Sleep( 2000 );
            Console.WriteLine();

            // task_start exist.
            HRobot.task_start( device_id, "test_LR.hrb" );
            Thread.Sleep( 2000 );
            HRobot.task_start( device_id, "test_LR.hrb" );
            Thread.Sleep( 200 );
            HRobot.task_abort( device_id );

            Console.WriteLine( " \n Please press enter key to end." );
            Console.ReadLine();
        }
    }
}