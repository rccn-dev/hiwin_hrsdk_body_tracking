// 10.TaskStart.cpp : 此檔案包含 'main' 函式。程式會於該處開始執行及結束執行。
//
#define _CRT_SECURE_NO_WARNINGS
#include "pch.h"
#include "iostream"
#include "string"
#include "vector"
#include "windows.h"
#include "random"
#include "../../../../include/HRSDK.h"
#include <thread>

#ifdef x64
#pragma comment(lib, "../../../../lib/x64/HRSDK.lib")
#else
#pragma comment(lib, "../../../../lib/x86/HRSDK.lib")
#endif

std::vector<std::string> info;
using namespace std;
bool show_notify = false;
bool show_command_msg = false;

int rand(int min, int max) {
	std::random_device rd;
	std::default_random_engine gen = std::default_random_engine(rd());
	std::uniform_int_distribution<int> dis(min, max);
	return dis(gen);
}

int Disconnect(HROBOT device_id) {
	if (device_id >= 0) {
		disconnect(device_id);
	}
	return 0;
}

void ShowPRNotification(std::vector<std::string> info_vec) {
	int pr_len = stoi(info_vec[0]);
	int pr_type = -1, pr_num = -1;

	for (int i = 0; i < pr_len; i++) {
		pr_num = stoi(info[1 + 11 * i]);
		pr_type = stoi(info[2 + 11 * i]);
		printf("[Notify] PR %d: %d \n \
Pos: %s, %s, %s, %s, %s, %s Ext: %s, %s, %s \n", pr_num, pr_type, // Type  1:Degree  2:Cartesian
		       info[3 + 11 * i].c_str(), info[4 + 11 * i].c_str(), info[5 + 11 * i].c_str(), info[6 + 11 * i].c_str(), info[7 + 11 * i].c_str(), info[8 + 11 * i].c_str(),
		       info[9 + 11 * i].c_str(), info[10 + 11 * i].c_str(), info[11 + 11 * i].c_str());
	}
}

void __stdcall callBack(uint16_t cmd, uint16_t rlt, uint16_t* Msg, int len) {
	char* recv = new char[len];
	for (int i = 0; i < len; i++) {
		recv[i] = (char)Msg[i];
	}
	std::string info_p(recv);
	if (show_command_msg) {
		printf("Command: %d  Rlt: %d  Msg: %s \n", cmd, rlt, info_p.c_str());
	}

	std::string delimiter = ",";
	size_t pos = 0;
	std::string token;
	info.clear();
	size_t x = 0;
	while ((pos = info_p.find(",", x)) <= len) {
		token = info_p.substr(x, pos - x);
		info.push_back(token);
		x = pos + 1;
	}
	if (cmd == 0) {
		switch (rlt) {
		case 4030:
			cout << "[Notify] HRSS alarm notify: " << info_p << endl;
			break;
		case 4145:
			cout << "[Notify] System Output" << info[0] << " : " << info[1] << endl;
			break;
		case 4702:
			if (show_notify) {
				printf("[Notify] Robot Information \n");
				cout << "[Notify] HRSS mode: " << info[0] << endl;
				cout << "[Notify] Operation Mode: " << info[1] << endl;
				cout << "[Notify] Override Ratio: " << info[2] << endl;
				cout << "[Notify] Motor State: " << info[3] << endl;
				cout << "[Notify] Exe File Name: " << info[4] << endl;
				cout << "[Notify] Function Output: " << info[5] << endl;
				cout << "[Notify] Alarm Count: " << info[6] << endl;
				cout << "[Notify] Keep Alive: " << info[7] << endl;
				cout << "[Notify] Motion Status: " << info[8] << endl;
				cout << "[Notify] Payload: " << info[9] << endl;
				cout << "[Notify] Speed: " << info[10] << endl; // safe: 0   normal: 1
				cout << "[Notify] Position: " << info[11] << endl;
				printf("[Notify] Coor: %s, %s, %s, %s, %s, %s \n", info[12].c_str(), info[13].c_str(), info[14].c_str(), info[15].c_str(), info[16].c_str(), info[17].c_str());
				printf("[Notify] Joint: %s, %s, %s, %s, %s, %s \n", info[18].c_str(), info[19].c_str(), info[20].c_str(), info[21].c_str(), info[22].c_str(), info[23].c_str());
				printf("\n");
			}
			break;
		case 4703:
			printf("[Notify] Timer %s: %s \n", info[0].c_str(), info[1].c_str());
			break;
		case 4704:
			printf("[Notify] Counter %s: %s \n", info[0].c_str(), info[1].c_str());
			break;
		case 4705:
			printf("[Notify] MI %d: %s \n", stoi(info[0]) + 1, info[1].c_str());
			break;
		case 4706:
			printf("[Notify] MO %d: %s \n", stoi(info[0]) + 1, info[1].c_str());
			break;
		case 4707:
			printf("[Notify] SI %d: %s \n", stoi(info[0]) + 1, info[1].c_str());
			break;
		case 4708:
			printf("[Notify] SO %d: %s \n", stoi(info[0]) + 1, info[1].c_str());
			break;
		case 4710:
			ShowPRNotification(info);
			printf("[Notify] PR %s: %s \n", info[1].c_str(), info[2].c_str()); //info[2] 0 coor, 1 degree
			printf("%s, %s, %s, %s, %s, %s \n", info[3].c_str(), info[4].c_str(), info[5].c_str(), info[6].c_str(), info[7].c_str(), info[8].c_str());
			break;
		case 4711:
			printf("[Notify] DI %d: %s \n", stoi(info[0]), info[1].c_str());
			break;
		case 4712:
			printf("[Notify] DO %d: %s \n", stoi(info[0]), info[1].c_str());
			break;
		case 4714:
			cout << "[Notify] Utilization start notify: " << info_p << endl;
			break;
		case 4715:
			cout << "[Notify] Utilization end notify: " << info_p << endl;
			break;
		}
	} else if (cmd == 1450) {
		switch (rlt) {
		case 4028:
			cout << "[Notify] HRSS start clear alarm" << endl;
			break;
		case 4029:
			cout << "[Notify] HRSS finish clear alarm" << endl;
			break;
		}
	} else if (cmd == 1456) {
		cout << "[Notify] SET_SPEED_LIMIT: " << endl;
	} else if (cmd == 2161) {
		switch (rlt) {
		case 0:
			cout << "[Notify] DOWNLOAD_LOG_FILE: " << endl;
			break;
		case 201:
			cout << "[Notify] FILE_IS_NOT_EXIST: " << endl;
			break;
		}
	} else if (cmd == 4000) {
		switch (rlt) {
		case 0:
			cout << "[Notify] Run EXT task start cmd: " << endl;
			break;
		case 201:
			cout << "[Notify] EXT task already exist." << endl;
			break;
		}
	} else if (cmd == 4001) {
		switch (rlt) {
		case 2006:
			cout << "[Notify] task start motion already exist." << endl;
			break;
		case 4012:
			cout << "[Notify] task start file name error." << endl;
			break;
		case 4013:
			cout << "[Notify] task start already exist." << endl;
			break;
		case 4014:
			cout << "[Notify] task start Run." << endl;
			break;
		}

	} else if (cmd == 4004) {
		switch (rlt) {
		case 4018:
			cout << "[Notify] task abort finish." << endl;
			break;
		}
	} else if (cmd == 4009) {
		switch (rlt) {
		case 0:
			cout << "[Notify] Download file." << endl;
			break;
		case 201:
			cout << "[Notify] File is not exist." << endl;
			break;
		}
	} else if (cmd == 4010) {
		cout << "[Notify] Send file." << endl;
	} else if (cmd == 4018) {
		cout << "[Notify] SAVE_DATABASE" << endl;
	} else if (cmd == 4019) {
		cout << "[Notify] LOAD_DATABASE" << endl;
	} else if (cmd == 4709) {
		cout << "[Notify] Save module IO." << endl;
	}
}

int CallbackNotify(HROBOT device_id, callback_function callback) {
	device_id = open_connection("127.0.0.1", 1, callback);
	if (device_id >= 0) {
		char* v = new char[256];
		double pos[6] = { 0 };
		get_hrsdk_version(v);
		std::cout << "HRSDK Version:" << v << std::endl;
		set_motor_state(device_id, 1);
		show_notify = true;
		show_command_msg = false;
		if (show_notify) {
			double pos[6] = { 0 };
			get_current_position(device_id, pos);   // 必須有這一行
		}
		Sleep(2000);
		show_notify = false;

		//// IO and register notify
		set_timer(device_id, 1, rand(1, 1000));
		Sleep(200);
		set_counter(device_id, 1, rand(1, 1000));
		Sleep(200);
		set_module_input_simulation(device_id, 0, true);
		Sleep(200);
		set_module_input_value(device_id, 0, true);
		Sleep(200);
		set_module_output_value(device_id, 0, false);
		Sleep(200);
		set_pr_type(device_id, 2, 0);
		Sleep(200);
		set_digital_output(device_id, 1, false);
		Sleep(200);
		set_DI_simulation_Enable(device_id, 1, false);
		Sleep(200);
		set_DI_simulation(device_id, 1, false);
		Sleep(2000);
		printf("\n");

		// alarm notify
		double p1[6] = { 0, 0, 0, 0, 0, 10 };
		double p2[6] = { 0, 0, 0, 0, 0, 10 };
		int count = -1;
		uint64_t alarm_code[20];
		circ_axis(device_id, 0, p1, p2);
		Sleep(200);
		get_alarm_code(device_id, count, alarm_code);
		if (count > 0) {
			clear_alarm(device_id);
		}
		printf("\n");

		// send and download file
		Sleep(1000);
		send_file(device_id, "../../../test_LR.hrb", "test_LR.hrb");
		Sleep(1000);
		download_file(device_id, "tesat_LR.hrb", "test_LR.hrb");
		Sleep(1000);
		printf("\n");

		// task_start motion exist.
		double p3[6] = { 40, 0, 0, 0, 0, 0 };
		ptp_axis(device_id, 0, p3);
		Sleep(500);
		task_start(device_id, "test_LR.hrb");
		Sleep(200);
		motion_abort(device_id);
		Sleep(2000);
		printf("\n");

		// task_start exist.
		task_start(device_id, "test_LR.hrb");
		Sleep(2000);
		task_start(device_id, "test_LR.hrb");
		Sleep(200);
		task_abort(device_id);

		std::cin.get();
	}
	return 0;
}

int main() {
	HROBOT device_id = 1;
	CallbackNotify(device_id, callBack);
	Disconnect(device_id);

}
