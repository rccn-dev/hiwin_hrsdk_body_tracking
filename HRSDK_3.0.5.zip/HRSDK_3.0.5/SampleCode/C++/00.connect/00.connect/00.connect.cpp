#include "stdafx.h"
#include "iostream"
#include "windows.h"
#include "../../../../include/HRSDK.h"

#ifdef x64
#pragma comment(lib, "../../../../lib/x64/HRSDK.lib")
#else
#pragma comment(lib, "../../../../lib/x86/HRSDK.lib")
#endif

int Connect(HROBOT device_id) {
	int level = get_connection_level(device_id);
	std::cout << "level:" << level << std::endl;

	set_connection_level(device_id, 1);
	level = get_connection_level(device_id);
	std::cout << "level:" << level << std::endl;
	return 0;
}

int Disconnect(HROBOT device_id) {
	if (device_id >= 0) {
		disconnect(device_id);
	}
	return 0;
}

void __stdcall callBack(uint16_t, uint16_t, uint16_t*, int) {

}

int main() {
	HROBOT device_id = 1;
	char sdk_ver[50];
	char hrss_ver[50];
	int client_L = -1, client_s = -1, client_rev = -1;
	int server_L = -1, server_s = -1, server_rev = -1;
	get_hrsdk_version(sdk_ver);
	std::cout << "SDK Release version: " << sdk_ver << std::endl;
	device_id = open_connection("127.0.0.1", 1, callBack);
	if (device_id >= 0) {
		get_hrss_version(device_id, hrss_ver);
		std::cout << "HRSS version: " << hrss_ver << std::endl;
		std::cout << "connect successful." << std::endl;

		get_hrsdk_sdkver(client_L, client_s, client_rev);
		get_hrss_sdkver(device_id, server_L, server_s, server_rev);
		printf("HRSDK(Local) Connection Ver: %d.%d.%d \n", client_L, client_s, client_rev);
		printf("HRSS Connection Ver: %d.%d.%d \n", server_L, server_s, server_rev);
		if (client_L != server_L) {
			printf("Please update software. \n");
		} else if (client_s != server_s) {
			printf("Some APIs not support. \n");
		}

		Connect(device_id);

		std::cout << "\n Press \"Enter\" key to quit the program." << std::endl;
		std::cin.get();
		Disconnect(device_id);
	} else {
		std::cout << "connect failure." << std::endl;
	}
}

