#include "stdafx.h"
#include "iostream"
#include "windows.h"
#include "../../../../include/HRSDK.h"

#ifdef x64
#pragma comment(lib, "../../../../lib/x64/HRSDK.lib")
#else
#pragma comment(lib, "../../../../lib/x86/HRSDK.lib")
#endif

void __stdcall callBack(uint16_t, uint16_t, uint16_t*, int) {

}

void SetParameterExample(HROBOT device_id) {
	int rlt; // return 0 if succeed
	rlt = set_operation_mode(device_id, 1); // switch mode to running mode ,cuz acc can only be changed in runing mode.
	Sleep(50);      // delay is needed when you want to change mode
	std::string ro_id = "timer_name";
	char* c_robot_id = new char[ro_id.length() + 1];
	strcpy_s(c_robot_id, ro_id.length() + 1, ro_id.c_str());
	rlt = set_robot_id(device_id, c_robot_id);
	rlt = set_acc_dec_ratio(device_id, 50);	// set acc ratio(%)
	rlt = set_acc_time(device_id, 250);
	rlt = set_operation_mode(device_id, 0); // switch mode to safety mode ,cuz ptp speed can only be changed in safety mode.
	rlt = set_override_ratio(device_id, 50);	// override ratio(%)
	rlt = set_ptp_speed(device_id, 50);	// PTP speed ratio(%)
	rlt = set_lin_speed(device_id, 800);	// LIN speed (mm/s)
	rlt = set_command_id(device_id, 10);
	rlt = remove_command(device_id, 10);
	rlt = set_digital_output(device_id, 5, true);
	rlt = set_robot_output(device_id, 5, true);
	rlt = set_valve_output(device_id, 1, true);

	/*Module I/O*/
	rlt = set_module_input_value(device_id, 5, true);
	rlt = set_module_input_start(device_id, 5, 1);
	rlt = set_module_input_end(device_id, 5, 5);
	wchar_t c_mi_comment[20];
	wcscpy_s(c_mi_comment, L"mi_comment");
	rlt = set_module_input_comment(device_id, 5, c_mi_comment);
	rlt = set_module_output_value(device_id, 5, true);
	rlt = set_module_output_start(device_id, 5, 1);
	rlt = set_module_output_end(device_id, 5, 5);
	wchar_t c_mo_comment[20];
	wcscpy_s(c_mo_comment, L"mo_comment");
	set_module_output_comment(device_id, 5, c_mo_comment);

	rlt = set_base_number(device_id, 5);
	rlt = set_tool_number(device_id, 5);
	rlt = set_timer(device_id, 5, 1000);
	rlt = set_timer_start(device_id, 5);
	rlt = set_timer_stop(device_id, 5);
	wchar_t timer_name[20];
	wcscpy_s(timer_name, L"timer comment");
	rlt = set_timer_name(device_id, 5, timer_name);
	rlt = set_counter(device_id, 5, 1000);
	rlt = set_pr_type(device_id, 5, 1000);
	double coor[6] = { 0, 0, 0, 0, -90, 0 };
	double ext_pos[3] = { 0, 0, 0};
	rlt = set_pr_coordinate(device_id, 5, coor);
	double tool_base[6] = { 5, 5 };
	rlt = set_pr_coordinate(device_id, 5, tool_base);
	rlt = set_pr_tool_base(device_id, 5, 2, 2);
	wchar_t pr_comment[20];
	wcscpy_s(pr_comment, L"PR comment");
	rlt = set_pr_comment(device_id, 5, pr_comment);
	rlt = define_base(device_id, 5, coor);
	rlt = define_tool(device_id, 5, coor);
	rlt = set_pr(device_id, 5, 1, coor, ext_pos, 5, 5);
	rlt = remove_pr(device_id, 5);
	rlt = set_smooth_length(device_id, 200);
	std::string file_name = "set_rsr.hrb";
	char* c_file_name = new char[file_name.length() + 1];
	strcpy_s(c_file_name, file_name.length() + 1, file_name.c_str());
	rlt = set_rsr(device_id, c_file_name, 1);
	rlt = remove_rsr(device_id, 1);
	rlt = set_motor_state(device_id, 1);

	// new 2020.03.19
	bool ON = true;
	wchar_t DIO_comment[20];
	wcscpy_s(DIO_comment, L"DIO comment");
	rlt = set_DI_simulation_Enable(device_id, 5, ON);
	rlt = set_DI_simulation(device_id, 5, ON);
	rlt = set_digital_input_comment(device_id, 5, DIO_comment);
	rlt = set_digital_output_comment(device_id, 5, DIO_comment);
	double joint[6] = { 0, 0, 0, 0, 0, 0 };
	rlt = set_home_point(device_id, joint);
	rlt = set_module_input_type(device_id, 5, 0);
	rlt = set_module_output_type(device_id, 5, 1);
	wchar_t counter_name[20];
	wcscpy_s(counter_name, L"counter comment");
	rlt = set_counter_name(device_id, 5, counter_name);
	int DIO = 0;
	int SIO = 1;
	int data[18] = { DIO, 34, DIO, 35, SIO, 36, SIO, 37, DIO, 38, SIO, 39, DIO, 40, DIO, 41, DIO, 42 };
	char* str = "test comment";
	rlt = set_digital_setting(device_id, data, str);
	rlt = set_user_alarm_setting_message(device_id, 5, str);
	rlt = set_language(device_id, 0);
	rlt = save_module_io_setting(device_id);

	// payload
	int index = 4;
	double mass = 2;
	double Xcc = 2.1;
	double Ycc = 2.2;
	double Zcc = 2.3;
	double Ixx = 2.4;
	double Iyy = 2.5;
	double Izz = 2.6;
	double value[7] = { mass, Xcc, Ycc, Zcc, Ixx, Iyy, Izz };
	char* payload_comment = "payload comment";
	rlt = set_payload_config(device_id, index, value, payload_comment);
	rlt = set_payload_active(device_id, index);
}

int _tmain(int argc, _TCHAR* argv[]) {
	// set robot parameter
	char sdk_ver[50];
	char hrss_ver[50];
	get_hrsdk_version(sdk_ver);
	std::cout << "SDK version: " << sdk_ver << std::endl;
	HROBOT device_id = open_connection("127.0.0.1", 1, callBack);
	if (device_id >= 0) {
		get_hrss_version(device_id, hrss_ver);
		std::cout << "HRSS version: " << hrss_ver << std::endl;
		std::cout << "connect successful." << std::endl;
		SetParameterExample(device_id);

		std::cout << "\n Press \"Enter\" key to quit the program." << std::endl;
		std::cin.get();
		disconnect(device_id);
	} else {
		std::cout << "connect failure." << std::endl;
	}
}

