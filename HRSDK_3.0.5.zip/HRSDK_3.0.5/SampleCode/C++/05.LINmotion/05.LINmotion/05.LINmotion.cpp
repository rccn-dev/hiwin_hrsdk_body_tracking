#include "stdafx.h"
#include "iostream"
#include "windows.h"
#include "../../../../include/HRSDK.h"

#ifdef x64
#pragma comment(lib, "../../../../lib/x64/HRSDK.lib")
#else
#pragma comment(lib, "../../../../lib/x86/HRSDK.lib")
#endif

void __stdcall callBack(uint16_t, uint16_t, uint16_t*, int) {

}

bool wait_for_stop_motion(HROBOT device_id) {
	while (get_motion_state(device_id) != RobotMotionStatus::kIdle) {
		if (get_connection_level(device_id) == ConnectionLevels::kDisconnection) {
			return false;  // The robot is not connected anymore
		}
		Sleep(200);
	}
	return true;
}

void run_lin_pos(HROBOT device_id, double pos[4][6], int mode, double smooth_value) {
	lin_pos(device_id, mode, smooth_value, pos[0]);
	lin_pos(device_id, mode, smooth_value, pos[1]);
	lin_pos(device_id, mode, smooth_value, pos[2]);
	lin_pos(device_id, mode, smooth_value, pos[3]);
	lin_pos(device_id, mode, smooth_value, pos[0]);
	wait_for_stop_motion(device_id);
}

void LinExample(HROBOT device_id) {
	set_override_ratio(device_id, 100);
	if (get_motor_state(device_id) == 0) {
		set_motor_state(device_id, 1);   // Servo on
		Sleep(3000);
	}

	double pos[4][6] = {
		{ -150, 450, -50, 0, 0, 0 },
		{ 150, 450, -100, 0, 0, 0 },
		{ 150, 300, -150, 0, 0, 0 },
		{ -150, 300, -200, 0, 0, 0 }
	};
	double rel_pos[7][6] = {
		{ 0, -200, 0, 0, 0, 0 },
		{ 0, 100, 0, 0, 0, 0 },
		{ -50, 0, 0, 0, 0, 0 },
		{ 0, -100, 0, 0, 0, 0 },
		{ 0, 200, 0, 0, 0, 0 },
		{ -50, 0, 0, 0, 0, 0 },
		{ 0, -200, 0, 0, 0, 0 },
	};
	jog_home(device_id);
	wait_for_stop_motion(device_id);

	// lin motion
	printf("Run line position. \n");
	run_lin_pos(device_id, pos, 0, 0);

	printf("Run line relative position \n");
	double lin_rel_home[6] = { 0, 480, -60, 0, 0, 0 };
	double ext_pos[3] = { 0 };
	lin_pos(device_id, 0, 0, lin_rel_home);
	Sleep(1000);
	for (int i = 0; i < sizeof(rel_pos) / sizeof(rel_pos[0]); i++) {
		lin_rel_pos(device_id, 0, 0, rel_pos[i]);
		wait_for_stop_motion(device_id);
	}

	// rel_pr
	printf("Run line point register \n");
	set_pr(device_id, 1, 0, lin_rel_home, ext_pos, 0, 0);
	lin_pr(device_id, 0, 0, 1);
	wait_for_stop_motion(device_id);
}

int _tmain(int argc, _TCHAR* argv[]) {
	char sdk_ver[50];
	char hrss_ver[50];
	get_hrsdk_version(sdk_ver);
	std::cout << "SDK version: " << sdk_ver << std::endl;
	HROBOT device_id = open_connection("127.0.0.1", 1, callBack);
	if (device_id >= 0) {
		get_hrss_version(device_id, hrss_ver);
		std::cout << "HRSS version: " << hrss_ver << std::endl;
		std::cout << "connect successful." << std::endl;
		LinExample(device_id);

		std::cout << "\n Press \"Enter\" key to quit the program." << std::endl;
		std::cin.get();
		disconnect(device_id);
	} else {
		std::cout << "connect failure." << std::endl;
	}
	return 0;
}

