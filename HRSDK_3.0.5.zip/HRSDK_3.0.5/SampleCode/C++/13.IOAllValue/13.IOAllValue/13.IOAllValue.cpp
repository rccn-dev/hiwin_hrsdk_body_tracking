#include "pch.h"
#include <iostream>
#include "windows.h"
#include "../../../../include/HRSDK.h"

#ifdef x64
#pragma comment(lib, "../../../../lib/x64/HRSDK.lib")
#else
#pragma comment(lib, "../../../../lib/x86/HRSDK.lib")
#endif

void __stdcall callBack(uint16_t, uint16_t, uint16_t*, int) {

}

void WcharShift(wchar_t* comment) {
	int size = comment[0];
	for (int i = 0; i < size; i++) {
		comment[i] = comment[i + 1];
	}
	comment[size] = L'\0';
}

bool ShowComment(int& idx, int* values, wchar_t* uint_16_comment, int next_comment, wchar_t* IO_name) {
	WcharShift(uint_16_comment);
	int ptr = 0;
	int next = 0;
	std::wstring str = std::wstring(uint_16_comment);

	while (next != -1) {
		next = str.find_first_of(L"\t", ptr);
		std::wstring tmp = str.substr(ptr, next - ptr);
		if (!tmp.empty()) {
			wprintf(L"%s[%d]:%d  %s \n", IO_name, idx, values[idx - 1], tmp.c_str());
		} else {
			wprintf(L"%s[%d]:%d  %s \n", IO_name, idx, values[idx - 1], "");
		}
		ptr = next + 1;
		idx++;
	}
	if (next_comment != 0) {
		idx = next_comment - 1;
	} else {
		return true;
	}
	return false;
}

void GetDIO(HROBOT device_id) {
	int di_values[48] = { 0 };
	int do_values[48] = { 0 };
	wchar_t* comment = new wchar_t[250];
	get_DI_range(device_id, 1, 48, di_values);
	get_DO_range(device_id, 1, 48, do_values);
	for (int idx = 1; idx <= 48; idx++) {
		int next_comment = 0;
		int rlt = get_DI_comment_range(device_id, idx, 48, comment, next_comment);
		if (rlt != 0) {
			continue;
		}
		bool is_end = ShowComment(idx, di_values, comment, next_comment, L"DI");
		if (is_end) {
			break;
		}
	}
	printf("\n");
}

void GetCounter(HROBOT device_id) {
	const int MAX_COUNTER_NUM = 20;
	int values[MAX_COUNTER_NUM] = { 0 };
	wchar_t* comment = new wchar_t[250];
	get_counter_value_all(device_id, values);
	for (int idx = 1; idx <= MAX_COUNTER_NUM; idx++) {
		int next_comment = 0;
		int rlt = get_counter_comment_range(device_id, idx, MAX_COUNTER_NUM, comment, next_comment);
		if (rlt != 0) {
			continue;
		}
		bool is_end = ShowComment(idx, values, comment, next_comment, L"Counter");
		if (is_end) {
			break;
		}
	}
	printf("\n");
}

void GetTimer(HROBOT device_id) {
	const int MAX_TIMER_NUM = 20;
	int values[MAX_TIMER_NUM] = { 0 };
	int status[MAX_TIMER_NUM] = { 0 };
	wchar_t* comment = new wchar_t[250];
	get_timer_value_all(device_id, values);
	get_timer_status_all(device_id, status);
	for (int idx = 1; idx <= MAX_TIMER_NUM; idx++) {
		int next_comment = 0;
		int rlt = get_timer_comment_range(device_id, idx, MAX_TIMER_NUM, comment, next_comment);
		if (rlt != 0) {
			continue;
		}
		bool is_end = ShowComment(idx, values, comment, next_comment, L"Timer");
		if (is_end) {
			break;
		}
	}
	printf("\n");
}

void GetSystemIO(HROBOT device_id) {
	const int SYSTEM_IO_MAX_NUM = 11;
	int in_value[SYSTEM_IO_MAX_NUM] = { 0 };
	int out_value[SYSTEM_IO_MAX_NUM] = { 0 };
	wchar_t* in_comment = new wchar_t[250];
	wchar_t* out_comment = new wchar_t[250];
	get_system_input_all(device_id, in_value, in_comment);
	get_system_output_all(device_id, out_value, out_comment);
	int next_comment = 0;
	for (int idx = 1; idx <= SYSTEM_IO_MAX_NUM; idx++) {
		bool is_end = ShowComment(idx, in_value, in_comment, next_comment, L"System In");
		if (is_end) {
			break;
		}
	}
	for (int idx = 1; idx <= SYSTEM_IO_MAX_NUM; idx++) {
		bool is_end = ShowComment(idx, out_value, out_comment, next_comment, L"System Out");
		if (is_end) {
			break;
		}
	}
	printf("\n");
}

void GetSIO(HROBOT device_id) {
	int si_values[128] = { 0 };
	int so_values[128] = { 0 };
	wchar_t* comment = new wchar_t[250];
	get_SI_range(device_id, 1, 128, si_values);
	get_SI_range(device_id, 129, 256, si_values);
	get_SO_range(device_id, 1, 128, so_values);
	get_SO_range(device_id, 129, 256, so_values);
	for (int idx = 1; idx <= 48; idx++) {
		int next_comment = 0;
		int rlt = get_SI_comment_range(device_id, idx, 128, comment, next_comment);
		if (rlt != 0) {
			continue;
		}
		bool is_end = ShowComment(idx, si_values, comment, next_comment, L"SI");
		if (is_end) {
			break;
		}
	}
	printf("\n");
}

void GetMIO(HROBOT device_id) {
	const int MIO_COUNT = 32;
	int sim[MIO_COUNT] = { 0 };
	int values[MIO_COUNT] = { 0 };
	int types[MIO_COUNT] = { 0 };
	int starts[MIO_COUNT] = { 0 };
	int ends[MIO_COUNT] = { 0 };
	wchar_t* comment = new wchar_t[250];
	get_MI_config_all(device_id, sim, values, types, starts, ends);
	for (int i = 0; i < MIO_COUNT; i++) {
		printf("MI[%d] sim:%d value:%d type:%d start:%d end:%d \n", i, sim[i], values[i], types[i], starts[i], ends[i]);
	}
	printf("\n");

	get_MO_config_all(device_id, values, types, starts, ends);
	for (int i = 0; i < MIO_COUNT; i++) {
		printf("MO[%d] value:%d type:%d start:%d end:%d \n", i,  values[i], types[i], starts[i], ends[i]);
	}
	printf("\n");
}

void GetPR(HROBOT device_id) {
	wchar_t* pr_comment = new wchar_t[250];
	int next_idx = 0;
	int idx_array[100] = {0};
	for (int i = 0; i < 100; i++) {
		idx_array[i] = i + 1;
	}
	for (int idx = 1; idx < 100; idx++) {
		int rlt = get_PR_comment_array(device_id, idx_array, idx, 100, pr_comment, next_idx);
		if (rlt != 0) {
			continue;
		}
		WcharShift(pr_comment);
		int ptr = 0;
		int next = 0;
		std::wstring str = std::wstring(pr_comment);

		while (next != -1) {
			next = str.find_first_of(L"\t", ptr);
			std::wstring tmp = str.substr(ptr, next - ptr);
			if (!tmp.empty()) {
				wprintf(L"PR[%d] %s \n", idx, tmp.c_str());
			} else {
				wprintf(L"PR[%d] %s \n", idx, "");
			}
			ptr = next + 1;
			idx++;
		}
		if (next_idx != 0) {
			idx = next_idx - 1;
		} else {
			break;
		}
	}
}

void SetDIO(HROBOT device_id) {
	const int len = 8;
	int indexes[len] = { 2, 14, 3, 6, 8, 11, 15, 1 };
	int values[len] = { 1, 1, 1, 1, 0, 1, 1, 0 };
	set_DI_sim_array(device_id, indexes, values, len);
	set_DI_array(device_id, indexes, values, len);
	set_DO_array(device_id, indexes, values, len);
}

void SetReg(HROBOT device_id) {
	const int len = 8;
	int indexes[len] = { 2, 14, 3, 6, 8, 11, 15, 1 };
	int values[len] =  { 111, 222, 123456, 654321, 500, 600, 700, 800 };
	set_timer_value_array(device_id, indexes, values, len);
	set_counter_array(device_id, indexes, values, len);
}

void SetFieldbus(HROBOT device_id) {
	int len = 8;
	int indexes[8] = { 2, 14, 3, 6, 8, 11, 15, 1 };
	int values1[8] = { 1, 1, 1, 1, 0, 1, 1, 0 };
	int values2[8] =  { 111, 222, -1256, 6321, -500, 600, 700, -800 };
	set_SI_sim_array(device_id, indexes, values1, len);
	set_SI_array(device_id, indexes, values1, len);
	set_SO_array(device_id, indexes, values1, len);
	set_fieldbus_srw_array(device_id, indexes, values2, len);
}

void SetIO(HROBOT device_id) {
	int len = 5;
	int indexes1[5] = { 1, 2, 3, 4, 5 };
	int values1[5] = { 1, 1, 0, 1, 1 };
	int vo_idx[3] = { 1, 2, 3 };
	int vo_val[3] = { 1, 0, 1 };
	int get_val[8] = {0};
	set_MO_array(device_id, indexes1, values1, len);
	set_RO_array(device_id, indexes1, values1, len);
	set_VO_array(device_id, vo_idx, vo_val, 3);
	get_RO_all(device_id, get_val);
	printf("RO: ");
	for (int i = 0; i < 8; i++) {
		printf("%d ", get_val[i]);
	}
	printf("\nVO: ");
	get_VO_all(device_id, get_val);
	for (int i = 0; i < 3; i++) {
		printf("%d ", get_val[i]);
	}
	printf("\n");
}

int main() {
	char sdk_ver[50];
	char hrss_ver[50];
	get_hrsdk_version(sdk_ver);
	std::cout << "SDK version: " << sdk_ver << std::endl;
	HROBOT device_id = open_connection("127.0.0.1", 1, callBack);
	if (device_id >= 0) {
		get_hrss_version(device_id, hrss_ver);
		std::cout << "HRSS version: " << hrss_ver << std::endl;
		std::cout << "connect successful." << std::endl;
		GetDIO(device_id);
		GetCounter(device_id);
		GetTimer(device_id);
		GetSystemIO(device_id);
		GetSIO(device_id);
		GetMIO(device_id);
		GetPR(device_id);

		SetDIO(device_id);
		SetReg(device_id);
		SetFieldbus(device_id);
		SetIO(device_id);
		std::cout << "\n Press \"Enter\" key to quit the program." << std::endl;
		std::cin.get();
		disconnect(device_id);
	} else {
		std::cout << "connect failure." << std::endl;
	}
	return 0;
}

