

#include "pch.h"
#include <iostream>
#include "../../../../include/HRSDK.h"
#include <windows.h>

#ifdef x64
#pragma comment(lib, "../../../../lib/x64/HRSDK.lib")
#else
#pragma comment(lib, "../../../../lib/x86/HRSDK.lib")
#endif

void SyncOutputFunc(int);
void __stdcall callBack(uint16_t, uint16_t, uint16_t*, int) {

}
int main()
{
	char sdk_ver[50];
	char hrss_ver[50];
	get_hrsdk_version(sdk_ver);
	std::cout << "SDK version: " << sdk_ver << std::endl;

	HROBOT device_id = open_connection("127.0.0.1", 1, callBack);
	if (device_id >= 0) {
		set_motor_state(device_id, 1);
		get_hrss_version(device_id, hrss_ver);
		std::cout << "HRSS version: " << hrss_ver << std::endl;
		std::cout << "connect successful." << std::endl;
		SyncOutputFunc(device_id);

		std::cout << "\n Press \"Enter\" key to quit the program." << std::endl;
		std::cin.get();
		disconnect(device_id);
	}
	else {
		std::cout << "connect failure. " << std::endl;
	}
	return 0;
}

bool wait_for_stop_motion(HROBOT device_id) {
	while (get_motion_state(device_id) != RobotMotionStatus::kIdle) {
		if (get_connection_level(device_id) == ConnectionLevels::kDisconnection) {
			return false;  // The robot is not connected anymore
		}
		Sleep(200);
	}
	return true;
}

void SyncOutputFunc(int device_id) {
	int type = 0;  //DO
	int id = 1;
	int ON = 1;
	int OFF = 0;
	int delay = 1000;
	int distance = 50;
	int Start = 0;
	int End = 1;
	int Path = 2;
	bool is_on[8];

	for (int i = 1; i <= 8; i++) {
		set_digital_output(device_id, i, false);
	}
	set_override_ratio(device_id, 100);
	printf("jog home \n");
	jog_home(device_id);
	wait_for_stop_motion(device_id);
	set_override_ratio(device_id, 10);

	double p1[6] = { -10, -200, -90, 0, 0, 0 };
	double p2[6] = { 10, 150, -90, 0, 0, 0 };
	printf("Syncoutput test \n");
	lin_rel_pos(device_id, 0, 0, p1);
	SyncOutput(device_id, type, id, ON, Start, delay, distance);
	SyncOutput(device_id, type, 2, ON, Path, -1000, distance);
	SyncOutput(device_id, type, 3, ON, Path, 0, distance);
	SyncOutput(device_id, type, 4, ON, Path, delay, distance);
	SyncOutput(device_id, type, 5, ON, Path, -1000, -50);
	SyncOutput(device_id, type, 6, ON, Path, 0, -50);
	SyncOutput(device_id, type, 7, ON, Path, 1000, -50);
	SyncOutput(device_id, type, 8, ON, End, -1000, distance);
	lin_rel_pos(device_id, 0, 0, p2);

	while (true) {
		if (get_motion_state(device_id) == RobotMotionStatus::kIdle) {
			break;
		}
		for (int i = 1; i <= 8; i++) {
			if (get_digital_output(device_id, i) == 1 && is_on[i - 1] != true) {
				printf("Digital output [%d] is ON \n", i);
				is_on[i - 1] = true;
			}
		}
		Sleep(200);
	}

}
