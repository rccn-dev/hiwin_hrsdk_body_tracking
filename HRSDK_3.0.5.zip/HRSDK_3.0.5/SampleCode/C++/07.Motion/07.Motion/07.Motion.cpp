#include "stdafx.h"
#include "iostream"
#include "windows.h"
#include "../../../../include/HRSDK.h"

#ifdef x64
#pragma comment(lib, "../../../../lib/x64/HRSDK.lib")
#else
#pragma comment(lib, "../../../../lib/x86/HRSDK.lib")
#endif

void __stdcall callBack(uint16_t, uint16_t, uint16_t*, int) {

}

bool wait_for_stop_motion(HROBOT device_id) {
	while (get_motion_state(device_id) != RobotMotionStatus::kIdle) {
		if (get_connection_level(device_id) == ConnectionLevels::kDisconnection) {
			return false;  // The robot is not connected anymore
		}
		Sleep(200);
	}
	return true;
}

void MotionExample(HROBOT device_id) {
	double cp1[6] = { -90, 400, -90, 0, 0, 0 };
	double cp2[6] = { -60, 350, -90, 0, 0, 0 };
	double cp3[6] = { 30, 300, -90, 0, 0, 0 };
	double cp4[6] = { -75, 350, -90, 0, 0, 0 };
	double cp5[6] = { 26, -80, -90, 0, 0, 0 };
	double cp6[6] = { 32, -70, -90, 0, 0, 0 };
	double cp7[6] = { 41, -70, -90, 0, 0, 0 };
	double cp8[6] = { 37, -83, -90, 0, 0, 0 };
	double Home[6] = { 0, 0, 0, 0, 0, 0 };
	set_override_ratio(device_id, 60);	//override

	if (get_motor_state(device_id) == 0) {
		set_motor_state(device_id, 1);   // Servo on
		Sleep(3000);
	}

	ptp_pos(device_id, 0, cp1);
	wait_for_stop_motion(device_id);

	circ_pos(device_id, 0, cp2, cp3); //circ motion
	Sleep(1000);
	printf("motion hold \n");
	motion_hold(device_id);
	Sleep(2000);
	printf("motion continue \n");
	motion_continue(device_id);
	circ_pos(device_id, 0, cp4, cp1);
	Sleep(1000);
	printf("motion abort \n");
	motion_abort(device_id);
	Sleep(1000);
	printf("motion delay 2 senconds. \n");

	motion_delay(device_id, 2000);
	circ_axis(device_id, 1, cp5, cp6);
	circ_axis(device_id, 1, cp7, cp8);
	printf("waiting 2 senconds. \n");
	Sleep(5000);
}

int _tmain(int argc, _TCHAR* argv[]) {
	char sdk_ver[50];
	char hrss_ver[50];
	get_hrsdk_version(sdk_ver);
	std::cout << "SDK version: " << sdk_ver << std::endl;
	HROBOT device_id = open_connection("127.0.0.1", 1, callBack);
	if (device_id >= 0) {
		get_hrss_version(device_id, hrss_ver);
		std::cout << "HRSS version: " << hrss_ver << std::endl;
		std::cout << "connect successful." << std::endl;
		MotionExample(device_id);

		std::cout << "\n Press \"Enter\" key to quit the program." << std::endl;
		std::cin.get();
		disconnect(device_id);
	} else {
		std::cout << "connect failure." << std::endl;
	}
	return 0;
}
