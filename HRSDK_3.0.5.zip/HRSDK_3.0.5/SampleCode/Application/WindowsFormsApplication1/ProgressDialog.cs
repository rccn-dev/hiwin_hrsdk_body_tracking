﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows.Forms;
using System.Resources; 
namespace WindowsFormsApplication1
{
    public partial class ConnectingBox : Form
    {
        public ConnectingBox()
        {
       
            InitializeComponent();
            this.OK.Visible = false;
            Image img =WindowsFormsApplication1.Properties.Resources.waitting;
            pictureBox1.Image = img;
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;

        }
        public void  StrShow(String t){
        }

        private void OK_Click(object sender, EventArgs e)
        {
            this.OK.Visible = false;
            this.Close();
        }

        private void ConnectingBox_Load(object sender, EventArgs e)
        {

        }
       
    }
}
