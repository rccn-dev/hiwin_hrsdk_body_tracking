﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class SetToolBaseControl : UserControl
    {
        public int type=-1;
        public int handle = -1;
        public int CoorIndex=-1;
        public SetToolBaseControl()
        {
            InitializeComponent();
        }
        public SetToolBaseControl(double [] coor,int t,int h,int ci)
        {
            InitializeComponent();

            TextBox_X.Text = Convert.ToString(coor[0]);
            TextBox_Y.Text = Convert.ToString(coor[1]);
            TextBox_Z.Text = Convert.ToString(coor[2]);
            TextBox_A.Text = Convert.ToString(coor[3]);
            TextBox_B.Text = Convert.ToString(coor[4]);
            TextBox_C.Text = Convert.ToString(coor[5]);
            type=t;
            handle=h;   
            CoorIndex=ci;
        }

        private void Bnt_OK_Click(object sender, EventArgs e)
        {
            double [] co=new double[6];
            co[0]=Convert.ToDouble(TextBox_X.Text);
            co[1]=Convert.ToDouble(TextBox_Y.Text);
            co[2]=Convert.ToDouble(TextBox_Z.Text);
            co[3]=Convert.ToDouble(TextBox_A.Text);
            co[4]=Convert.ToDouble(TextBox_B.Text);
            co[5]=Convert.ToDouble(TextBox_C.Text);

            switch (type) { 
                case 0:
                    HRobot.define_tool(handle, CoorIndex, co);

                    break;
                case 1:
                    HRobot.define_base(handle, CoorIndex, co);
                    break;
                default:
                    break;            
            }
        }

        private void Bnt_Cancel_Click(object sender, EventArgs e)
        {
            ((Form)this.TopLevelControl).Close();
        }
    }
}
