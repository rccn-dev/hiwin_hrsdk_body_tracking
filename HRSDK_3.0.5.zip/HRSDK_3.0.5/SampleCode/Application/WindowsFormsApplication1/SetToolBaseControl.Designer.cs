﻿namespace WindowsFormsApplication1
{
    partial class SetToolBaseControl
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.Bnt_Cancel = new System.Windows.Forms.Button();
            this.Bnt_OK = new System.Windows.Forms.Button();
            this.TextBox_C = new System.Windows.Forms.TextBox();
            this.TextBox_B = new System.Windows.Forms.TextBox();
            this.TextBox_A = new System.Windows.Forms.TextBox();
            this.TextBox_Z = new System.Windows.Forms.TextBox();
            this.TextBox_Y = new System.Windows.Forms.TextBox();
            this.TextBox_X = new System.Windows.Forms.TextBox();
            this.Label_C = new System.Windows.Forms.Label();
            this.Label_B = new System.Windows.Forms.Label();
            this.Label_A = new System.Windows.Forms.Label();
            this.Label_Z = new System.Windows.Forms.Label();
            this.Label_Y = new System.Windows.Forms.Label();
            this.Label_X = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.Bnt_Cancel);
            this.panel1.Controls.Add(this.Bnt_OK);
            this.panel1.Controls.Add(this.TextBox_C);
            this.panel1.Controls.Add(this.TextBox_B);
            this.panel1.Controls.Add(this.TextBox_A);
            this.panel1.Controls.Add(this.TextBox_Z);
            this.panel1.Controls.Add(this.TextBox_Y);
            this.panel1.Controls.Add(this.TextBox_X);
            this.panel1.Controls.Add(this.Label_C);
            this.panel1.Controls.Add(this.Label_B);
            this.panel1.Controls.Add(this.Label_A);
            this.panel1.Controls.Add(this.Label_Z);
            this.panel1.Controls.Add(this.Label_Y);
            this.panel1.Controls.Add(this.Label_X);
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(183, 287);
            this.panel1.TabIndex = 12;
            // 
            // Bnt_Cancel
            // 
            this.Bnt_Cancel.Location = new System.Drawing.Point(103, 221);
            this.Bnt_Cancel.Name = "Bnt_Cancel";
            this.Bnt_Cancel.Size = new System.Drawing.Size(65, 37);
            this.Bnt_Cancel.TabIndex = 25;
            this.Bnt_Cancel.Text = "EXIT";
            this.Bnt_Cancel.UseVisualStyleBackColor = true;
            this.Bnt_Cancel.Click += new System.EventHandler(this.Bnt_Cancel_Click);
            // 
            // Bnt_OK
            // 
            this.Bnt_OK.Location = new System.Drawing.Point(16, 221);
            this.Bnt_OK.Name = "Bnt_OK";
            this.Bnt_OK.Size = new System.Drawing.Size(65, 37);
            this.Bnt_OK.TabIndex = 24;
            this.Bnt_OK.Text = "SAVE";
            this.Bnt_OK.UseVisualStyleBackColor = true;
            this.Bnt_OK.Click += new System.EventHandler(this.Bnt_OK_Click);
            // 
            // TextBox_C
            // 
            this.TextBox_C.Location = new System.Drawing.Point(68, 193);
            this.TextBox_C.Name = "TextBox_C";
            this.TextBox_C.Size = new System.Drawing.Size(100, 22);
            this.TextBox_C.TabIndex = 23;
            // 
            // TextBox_B
            // 
            this.TextBox_B.Location = new System.Drawing.Point(68, 159);
            this.TextBox_B.Name = "TextBox_B";
            this.TextBox_B.Size = new System.Drawing.Size(100, 22);
            this.TextBox_B.TabIndex = 22;
            // 
            // TextBox_A
            // 
            this.TextBox_A.Location = new System.Drawing.Point(68, 124);
            this.TextBox_A.Name = "TextBox_A";
            this.TextBox_A.Size = new System.Drawing.Size(100, 22);
            this.TextBox_A.TabIndex = 21;
            // 
            // TextBox_Z
            // 
            this.TextBox_Z.Location = new System.Drawing.Point(68, 89);
            this.TextBox_Z.Name = "TextBox_Z";
            this.TextBox_Z.Size = new System.Drawing.Size(100, 22);
            this.TextBox_Z.TabIndex = 20;
            // 
            // TextBox_Y
            // 
            this.TextBox_Y.Location = new System.Drawing.Point(68, 50);
            this.TextBox_Y.Name = "TextBox_Y";
            this.TextBox_Y.Size = new System.Drawing.Size(100, 22);
            this.TextBox_Y.TabIndex = 19;
            // 
            // TextBox_X
            // 
            this.TextBox_X.Location = new System.Drawing.Point(68, 11);
            this.TextBox_X.Name = "TextBox_X";
            this.TextBox_X.Size = new System.Drawing.Size(100, 22);
            this.TextBox_X.TabIndex = 18;
            // 
            // Label_C
            // 
            this.Label_C.AutoSize = true;
            this.Label_C.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Label_C.Location = new System.Drawing.Point(12, 194);
            this.Label_C.Name = "Label_C";
            this.Label_C.Size = new System.Drawing.Size(23, 21);
            this.Label_C.TabIndex = 17;
            this.Label_C.Text = "C";
            // 
            // Label_B
            // 
            this.Label_B.AutoSize = true;
            this.Label_B.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Label_B.Location = new System.Drawing.Point(12, 160);
            this.Label_B.Name = "Label_B";
            this.Label_B.Size = new System.Drawing.Size(23, 21);
            this.Label_B.TabIndex = 16;
            this.Label_B.Text = "B";
            // 
            // Label_A
            // 
            this.Label_A.AutoSize = true;
            this.Label_A.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Label_A.Location = new System.Drawing.Point(12, 125);
            this.Label_A.Name = "Label_A";
            this.Label_A.Size = new System.Drawing.Size(24, 21);
            this.Label_A.TabIndex = 15;
            this.Label_A.Text = "A";
            // 
            // Label_Z
            // 
            this.Label_Z.AutoSize = true;
            this.Label_Z.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Label_Z.Location = new System.Drawing.Point(12, 90);
            this.Label_Z.Name = "Label_Z";
            this.Label_Z.Size = new System.Drawing.Size(22, 21);
            this.Label_Z.TabIndex = 14;
            this.Label_Z.Text = "Z";
            // 
            // Label_Y
            // 
            this.Label_Y.AutoSize = true;
            this.Label_Y.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Label_Y.Location = new System.Drawing.Point(12, 51);
            this.Label_Y.Name = "Label_Y";
            this.Label_Y.Size = new System.Drawing.Size(24, 21);
            this.Label_Y.TabIndex = 13;
            this.Label_Y.Text = "Y";
            // 
            // Label_X
            // 
            this.Label_X.AutoSize = true;
            this.Label_X.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Label_X.Location = new System.Drawing.Point(12, 12);
            this.Label_X.Name = "Label_X";
            this.Label_X.Size = new System.Drawing.Size(24, 21);
            this.Label_X.TabIndex = 12;
            this.Label_X.Text = "X";
            // 
            // SetToolBaseControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel1);
            this.Name = "SetToolBaseControl";
            this.Size = new System.Drawing.Size(193, 294);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button Bnt_Cancel;
        private System.Windows.Forms.Button Bnt_OK;
        private System.Windows.Forms.TextBox TextBox_C;
        private System.Windows.Forms.TextBox TextBox_B;
        private System.Windows.Forms.TextBox TextBox_A;
        private System.Windows.Forms.TextBox TextBox_Z;
        private System.Windows.Forms.TextBox TextBox_Y;
        private System.Windows.Forms.TextBox TextBox_X;
        private System.Windows.Forms.Label Label_C;
        private System.Windows.Forms.Label Label_B;
        private System.Windows.Forms.Label Label_A;
        private System.Windows.Forms.Label Label_Z;
        private System.Windows.Forms.Label Label_Y;
        private System.Windows.Forms.Label Label_X;
    }
}
