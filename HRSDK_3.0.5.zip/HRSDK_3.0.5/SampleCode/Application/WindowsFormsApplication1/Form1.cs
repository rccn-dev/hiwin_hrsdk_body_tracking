﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Net;
using SharpGL;
using System.Security;
using Microsoft.Win32;
using System.Threading;
namespace WindowsFormsApplication1 {
    public partial class Form1 : Form {
        public Form1() {
            CreateConsole();
            ConsoleColor oriColor = Console.ForegroundColor;
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine( "* Don't close this console window or the application will also close." );
            Console.WriteLine();
            Console.ForegroundColor = oriColor;
            InitializeComponent();
            TimeBeginPeriod( 1 );
            TabControll_DeviceList.SizeMode = TabSizeMode.Fixed;
            Global.Instance.TabControll_DeviceList = TabControll_DeviceList;
            TabControll_DeviceList.SelectedIndex = -1;
            Radio_Manual.Select();

            Global.Instance.Remote_Mode = 1;
            Global.Instance.SelectedDevice = 0;
            Global.Instance.CureHandle = Global.Instance.SelectedDevice;
            CurSelJogType = Convert.ToInt16( SpaceOperationTypes.kJoint );


            StringBuilder HRSDK_str = new StringBuilder();
            HRobot.get_hrsdk_version( HRSDK_str );
            Label_HRSDK_version.Text = "HRSDK VERSION: " + HRSDK_str.ToString();


            //
            // openGLControl
            //

            Global.Instance.openGLControl = new SharpGL.OpenGLControl();
            Global.Instance.openGLControl.Dock = System.Windows.Forms.DockStyle.Fill;
            Global.Instance.openGLControl.DrawFPS = true;
            Global.Instance.openGLControl.FrameRate = 20;
            Global.Instance.openGLControl.Location = new System.Drawing.Point( 0, 0 );
            Global.Instance.openGLControl.Name = "openGLControl";
            Global.Instance.openGLControl.RenderContextType = SharpGL.RenderContextType.FBO;
            Global.Instance.openGLControl.TabIndex = 0;
            Global.Instance.openGLControl.OpenGLInitialized += new System.EventHandler( this.openGLControl_OpenGLInitialized );
            Global.Instance.openGLControl.OpenGLDraw += new SharpGL.RenderEventHandler( this.openGLControl_OpenGLDraw );
            Global.Instance.openGLControl.Resized += new System.EventHandler( this.openGLControl_Resized );


            this.Panel_OpenGl.Controls.Add( Global.Instance.openGLControl );
            ( ( System.ComponentModel.ISupportInitialize )( Global.Instance.openGLControl ) ).EndInit();
            this.Panel_OpenGl.ResumeLayout( false );
            RobotGl.BuildList();
        }

        // Black Console --------------------------------------------------------------
        private const UInt32 StdOutputHandle = 0xFFFFFFF5;
        [DllImport( "kernel32.dll" )]
        private static extern IntPtr GetStdHandle( UInt32 nStdHandle );
        [DllImport( "kernel32.dll" )]
        private static extern void SetStdHandle( UInt32 nStdHandle, IntPtr handle );
        [DllImport( "kernel32" )]
        static extern bool AllocConsole();
        public static void CreateConsole() {
            AllocConsole();
            // stdout's handle seems to always be equal to 7
            IntPtr defaultStdout = new IntPtr( 7 );
            IntPtr currentStdout = GetStdHandle( StdOutputHandle );
            if ( currentStdout != defaultStdout )
                // reset stdout
                SetStdHandle( StdOutputHandle, defaultStdout );
        }
        // END Black Console ----------------------------------------------------------
        [System.Diagnostics.CodeAnalysis.SuppressMessage( "Microsoft.Interoperability", "CA1401:PInvokesShouldNotBeVisible" ), System.Diagnostics.CodeAnalysis.SuppressMessage( "Microsoft.Security", "CA2118:ReviewSuppressUnmanagedCodeSecurityUsage" ), SuppressUnmanagedCodeSecurity]
        [DllImport( "winmm.dll", EntryPoint = "timeBeginPeriod", SetLastError = true )]

        public static extern uint TimeBeginPeriod( uint uMilliseconds );

        /// <summary>TimeEndPeriod(). See the Windows API documentation for details.</summary>

        [System.Diagnostics.CodeAnalysis.SuppressMessage( "Microsoft.Interoperability", "CA1401:PInvokesShouldNotBeVisible" ), System.Diagnostics.CodeAnalysis.SuppressMessage( "Microsoft.Security", "CA2118:ReviewSuppressUnmanagedCodeSecurityUsage" ), SuppressUnmanagedCodeSecurity]
        [DllImport( "winmm.dll", EntryPoint = "timeEndPeriod", SetLastError = true )]

        public static extern uint TimeEndPeriod( uint uMilliseconds );
        // Call back function ---------------------------------------------------------
        public static void EventFun( UInt16 cmd, UInt16 rlt, ref UInt16 Msg, int len ) {
            Console.WriteLine( "Command: " + cmd + " Resault: " + rlt );

            switch ( cmd ) {
                case 4011:
                    if ( rlt != 0 ) {
                        MessageBox.Show( "Update fail. " + rlt, "HRSS update callback", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly );
                    }
                    break;
            }
        }
        private static HRobot.CallBackFun callback;

        // Connect button
        private void button1_Click( object sender, EventArgs e ) {
            createThreadAnimation( "Dialog Message", Thread_function );
        }
        // END Call back function-------------------------------------------------------

        public void createThreadAnimation( String StrMsg, ParameterizedThreadStart fun ) {
            //執行多執行序和顯示等待動畫
            ConnectingBox d = new ConnectingBox();
            Thread t = new Thread( fun );
            t.Start( d );
            d.StartPosition = FormStartPosition.CenterParent;
            d.ShowDialog();
        }

        public void Thread_function( object arg ) {
            //執行序
            ConnectingBox d = ( ConnectingBox )arg;
            IPAddress ipAddress;
            if ( IPAddress.TryParse( TextBox_DeviceIP.Text, out ipAddress ) ) {
                int DeviceId = FindUnusedDeviceId();
                if ( DeviceId == -1 ) {
                    d.Invoke( ( MethodInvoker )delegate {
                        d.OK.Visible = true;
                    } );
                    d.Invoke( ( MethodInvoker )delegate {
                        d.pictureBox1.Image = WindowsFormsApplication1.Properties.Resources.error;
                    } );
                    return;
                }
                int h;
                callback = new HRobot.CallBackFun( EventFun );
                if ( ( h = HRobot.open_connection( ipAddress.ToString(), Global.Instance.Remote_Mode, callback ) ) >= 0 ) {
                    // get the inital length
                    int tabLength = HeaderW;
                    if ( ipAddress.ToString() == "192.168.15.3" ) {
                        Global.Instance.CameraHandle = h;
                    }
                    // measure the text in each tab and make adjustment to the size
                    TabPage currentPage = new TabPage();

                    Global.Instance.HiwinDevice[DeviceId] = h;
                    DeviceTabControll newTab = new DeviceTabControll( h );
                    newTab.Dock = DockStyle.Fill;
                    currentPage.Text = "Device" + ( DeviceId + 1 );
                    int currentTabLength = TextRenderer.MeasureText( currentPage.Text, currentPage.Font ).Width;
                    // adjust the length for what text is written
                    currentTabLength += LEADING_SPACE + CLOSE_SPACE + CLOSE_AREA;
                    if ( currentTabLength > tabLength ) {
                        tabLength = currentTabLength;
                    }

                    // create the new size
                    Size newTabSize = new Size( tabLength, HeaderH );

                    TabControll_DeviceList.Invoke( ( MethodInvoker )delegate {
                        TabControll_DeviceList.ItemSize = newTabSize;
                    } );
                    currentPage.Controls.Add( newTab );
                    TabControll_DeviceList.Invoke( ( MethodInvoker )delegate {
                        TabControll_DeviceList.TabPages.Add( currentPage );
                    } );

                    Global.Instance.UserControl_List[DeviceId] = newTab;
                    Global.Instance.UserControl_List[DeviceId].handle = h;
                    Global.Instance.UserControl_List[DeviceId].DeviceIndex = DeviceId;


                    Global.Instance.UserControl_List[DeviceId].Invoke( ( MethodInvoker )delegate {
                        Global.Instance.UserControl_List[DeviceId].Joint_Timer.Start();
                        Global.Instance.UserControl_List[DeviceId].PosTimer.Start();
                        Global.Instance.UserControl_List[DeviceId].IO_Timer.Start();
                        Global.Instance.UserControl_List[DeviceId].ToolBase_Timer.Start();
                        Global.Instance.UserControl_List[DeviceId].ConnectionLevel_timer.Start();
                        Global.Instance.UserControl_List[DeviceId].Register_Timer.Start();

                        for ( int a = 0; a < DeviceId; a++ ) {
                            Global.Instance.UserControl_List[a].Joint_Timer.Stop();
                            Global.Instance.UserControl_List[a].PosTimer.Stop();
                            Global.Instance.UserControl_List[a].IO_Timer.Stop();
                            Global.Instance.UserControl_List[a].ToolBase_Timer.Stop();
                            Global.Instance.UserControl_List[a].ConnectionLevel_timer.Stop();
                            Global.Instance.UserControl_List[a].Register_Timer.Stop();
                        }

                    } );

                    d.Invoke( ( MethodInvoker )delegate {
                        d.pictureBox1.Image = WindowsFormsApplication1.Properties.Resources.succeed;
                    } );

                    TabControll_DeviceList.Invoke( ( MethodInvoker )delegate {
                        TabControll_DeviceList.SelectedIndex = TabControll_DeviceList.TabCount - 1;
                    } );
                    StringBuilder RType = new StringBuilder( "" );
                    HRobot.get_robot_type( Global.Instance.CureHandle, RType );
                    Thread.Sleep( 1000 );

                } else {

                    d.Invoke( ( MethodInvoker )delegate {
                        d.OK.Visible = true;
                    } );
                    d.Invoke( ( MethodInvoker )delegate {
                        d.pictureBox1.Image = WindowsFormsApplication1.Properties.Resources.error;
                    } );
                    return;
                }
            } else {
                d.Invoke( ( MethodInvoker )delegate {
                    d.OK.Visible = true;
                } );
                d.Invoke( ( MethodInvoker )delegate {
                    d.pictureBox1.Image = WindowsFormsApplication1.Properties.Resources.error;
                } );
                return;
            }
            d.Invoke( new Action( d.Close ) );
        }

        public int HeaderW {
            get {
                int text = 0;
                TabControll_DeviceList.BeginInvoke( new MethodInvoker( delegate {
                    text = TabControll_DeviceList.ItemSize.Width;
                } ) );
                return text;
            }
        }

        public int HeaderH {
            get {
                int text = 0;
                TabControll_DeviceList.BeginInvoke( new MethodInvoker( delegate {
                    text = TabControll_DeviceList.ItemSize.Height;
                } ) );
                return text;
            }
        }

        static public int CurSelJogType;

        private int FindUnusedDeviceId() {
            for ( int a = 0; a < 10; a++ ) {
                if ( Global.Instance.HiwinDevice[a] == -1 ) {
                    return a;
                }
            }
            return -1;
        }

        private void Radio_Expert_CheckedChanged( object sender, EventArgs e ) {
            Global.Instance.Remote_Mode = 1;
        }

        private void Radio_Operator_CheckedChanged( object sender, EventArgs e ) {
            Global.Instance.Remote_Mode = 0;
        }

        private void Form_Closing( object sender, FormClosingEventArgs e ) {
            TimeEndPeriod( 1 );
            Properties.Settings.Default.IP = TextBox_DeviceIP.Text;
            Properties.Settings.Default.Save();

        }

        private void Form_loing( object sender, EventArgs e ) {
            TextBox_DeviceIP.Text = Properties.Settings.Default.IP;
        }

        private void TabIndex_Changed( object sender, EventArgs e ) {
            try {
                TabPage currentPage = TabControll_DeviceList.SelectedTab;
                String TabIndex = currentPage.Text.Replace( "Device", "" );


                Global.Instance.SelectedDevice = Convert.ToInt16( TabIndex ) - 1;


                Global.Instance.UserControl_List[Global.Instance.SelectedDevice].Joint_Timer.Start();
                Global.Instance.UserControl_List[Global.Instance.SelectedDevice].PosTimer.Start();
                Global.Instance.UserControl_List[Global.Instance.SelectedDevice].IO_Timer.Start();
                Global.Instance.UserControl_List[Global.Instance.SelectedDevice].ToolBase_Timer.Start();
                Global.Instance.UserControl_List[Global.Instance.SelectedDevice].ConnectionLevel_timer.Start();
                Global.Instance.UserControl_List[Global.Instance.SelectedDevice].Register_Timer.Start();
            } catch {

            }
        }

        const int LEADING_SPACE = 12;
        const int CLOSE_SPACE = 15;
        const int CLOSE_AREA = 15;
        private void DrawTab( object sender, DrawItemEventArgs e ) {
            e.Graphics.FillRectangle( new SolidBrush( Color.Wheat ), e.Bounds );
            e.Graphics.DrawString( "x", e.Font, Brushes.Black, e.Bounds.Right - CLOSE_AREA, e.Bounds.Top + 4 );
            e.Graphics.DrawString( this.TabControll_DeviceList.TabPages[e.Index].Text, e.Font, Brushes.Black, e.Bounds.Left + LEADING_SPACE, e.Bounds.Top + 4 );
            e.DrawFocusRectangle();
        }

        private void Mouse_Down( object sender, MouseEventArgs e ) {
            for ( int i = 0; i < this.TabControll_DeviceList.TabPages.Count; i++ ) {
                Rectangle r = TabControll_DeviceList.GetTabRect( i );
                //Getting the position of the "x" mark.
                Rectangle closeButton = new Rectangle( r.Right - 15, r.Top + 4, 9, 7 );
                if ( closeButton.Contains( e.Location ) ) {
                    if ( MessageBox.Show( "Would you like to Close this Tab?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question ) == DialogResult.Yes ) {
                        DeviceTabControll uc1 = TabControll_DeviceList.TabPages[i].Controls[0] as DeviceTabControll;
                        if ( uc1 != null ) {
                            uc1.Joint_Timer.Stop();
                            uc1.PosTimer.Stop();
                            uc1.IO_Timer.Stop();
                            uc1.Register_Timer.Stop();
                            uc1.ConnectionLevel_timer.Stop();
                            HRobot.disconnect( uc1.handle );
                            Global.Instance.HiwinDevice[uc1.DeviceIndex] = -1;
                            this.TabControll_DeviceList.TabPages.RemoveAt( i );
                        }
                        break;
                    }
                }
            }
        }

        /// <summary>
        /// Handles the OpenGLDraw event of the openGLControl control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="RenderEventArgs"/> instance containing the event data.</param>
        private void openGLControl_OpenGLDraw( object sender, RenderEventArgs e ) {

            if ( TabControll_DeviceList.TabPages.Count == 0 ) {
                return;
            }
            StringBuilder robotName = new StringBuilder();
            HRobot.get_robot_type( Global.Instance.UserControl_List[Global.Instance.SelectedDevice].handle, robotName );
            switch ( robotName.ToString() ) {
                case "RD401":
                case "RD401-700":
                case "RA605-GC":
                case "RA605-710-GC":
                case "RA605-909-GC":
                    break;
                default:
                    return;
            }

            //  Get the OpenGL object.
            OpenGL gl = Global.Instance.openGLControl.OpenGL;
            //  Clear the color and depth buffer.=
            gl.Clear( OpenGL.GL_COLOR_BUFFER_BIT | OpenGL.GL_DEPTH_BUFFER_BIT );

            //取得目前位置
            double[] CurJointDegree = new double[6];
            for ( int a = 0; a < 6; a++ ) {
                CurJointDegree[a] = Global.Instance.UserControl_List[Global.Instance.SelectedDevice].JointDegree[a];
            }


            int width = Panel_OpenGl.Size.Width;
            int height = Panel_OpenGl.Size.Height;

            //  Load the identity matrix.
            gl.LoadIdentity();
            gl.Viewport( 0, 0, width, height );

            //設定光線亮度照射
            RobotGl.light();
            //設定地板縮放大小
            RobotGl.floor();
            //???
            gl.Enable( OpenGL.GL_COLOR_MATERIAL );

            String whichRobot = robotName.ToString();
            switch ( whichRobot ) {
                case "RA605-710-GC":
                case "RA605-909-GC":
                case "RA605-GC": {
                    float[] DH_Table = new float[5] { 30.0f, 340.0f, 40.0f, 338.0f, 86.5f };
                    RobotGl.RA605( CurJointDegree, DH_Table );
                }
                break;
                case "RD401-700":
                case "RD401": {
                    float[] DH_Table = new float[4] { 100.0f, 55.0f, 600.0f, 301.496f };
                    RobotGl.RD401_long( CurJointDegree, DH_Table );
                }
                break;
            }
        }



        /// <summary>
        /// Handles the OpenGLInitialized event of the openGLControl control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void openGLControl_OpenGLInitialized( object sender, EventArgs e ) {
            //  TODO: Initialise OpenGL here.

            //  Get the OpenGL object.
            OpenGL gl = Global.Instance.openGLControl.OpenGL;

            //  Set the clear color.


            gl.ClearColor( 82.0f / 255.0f, 142.0f / 255.0f, 203.0f / 255.0f, 1.0f );
            gl.PolygonMode( OpenGL.GL_FRONT, OpenGL.GL_FILL );
            gl.PolygonMode( OpenGL.GL_BACK, OpenGL.GL_FILL );
            gl.ShadeModel( OpenGL.GL_SMOOTH );

        }

        /// <summary>
        /// Handles the Resized event of the openGLControl control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void openGLControl_Resized( object sender, EventArgs e ) {
            //  TODO: Set the projection matrix here.

            //  Get the OpenGL object.
            OpenGL gl = Global.Instance.openGLControl.OpenGL;

            //  Set the projection matrix.
            gl.MatrixMode( OpenGL.GL_PROJECTION );

            //  Load the identity.
            gl.LoadIdentity();

            //  Create a perspective transformation.
            //  gl.Viewport(0, 0, Panel_OpenGl.Size.Width,Panel_OpenGl.Size.Height);
            //Parameter(ZOOM,,,)
            gl.Perspective( 45.0, ( double )Panel_OpenGl.Size.Width / ( double )Panel_OpenGl.Size.Height, 0.1, 1000.0 );

            //  Use the 'look at' helper function to position and aim the camera.
            gl.LookAt( 0.8, 0.8, 0.3, 0, 0, 0.0, 0, 0, 1 );
            gl.DrawBuffer( OpenGL.GL_BACK );
            gl.Enable( OpenGL.GL_DEPTH_TEST );
            gl.LightModel( OpenGL.GL_LIGHT_MODEL_TWO_SIDE, 1 );

            //  Set the modelview matrix.
            gl.MatrixMode( OpenGL.GL_MODELVIEW );
        }

        private void Radio_Auto_CheckedChanged( object sender, EventArgs e ) {
            if( HRobot.get_connection_level( Global.Instance.CureHandle ) == 1 && HRobot.get_operation_mode( Global.Instance.CureHandle ) == 0 ) {
                HRobot.set_operation_mode( Global.Instance.CureHandle, 1 );
            }
        }

        private void Radio_Manual_CheckedChanged( object sender, EventArgs e ) {
            if ( HRobot.get_connection_level( Global.Instance.CureHandle ) == 1 && HRobot.get_operation_mode( Global.Instance.CureHandle ) == 1 ) {
                HRobot.set_operation_mode( Global.Instance.CureHandle, 0 );
            }
        }

        private void radioButton2_CheckedChanged( object sender, EventArgs e ) {
            HRobot.set_connection_level( Global.Instance.CureHandle, 0 );
        }

        private void radioButton1_CheckedChanged( object sender, EventArgs e ) {
            HRobot.set_connection_level( Global.Instance.CureHandle, 1 );
        }
    }
}
