﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.Threading;

namespace WindowsFormsApplication1 {

    public partial class DeviceTabControll : UserControl {
        public int CurSelJogType;
        public int selIndex = 0;
        enum JogType {
            Cart = 0,
            Joint = 1,
            Tool = 2
        };
        public Int32[] Enc = new Int32[6];
        public double[] JointDegree = new double[6];
        public double[] CartTxBxDegree = new double[6];
        public double[] CartT0B0Degree = new double[6];
        public int PtpRatio;
        public int AccRatio;
        public int OverrideRatio;
        public double LinSpeed;
        public int UtilRatio;
        public int MotionType;
        public double[] JointRpm = new double[6];
        public int handle;
        public int DeviceIndex;
        public System.Timers.Timer Register_Timer;
        public System.Timers.Timer IO_Timer;
        private int[] Robot_Timer = new int[20];
        private int[] Robot_Counter = new int[20];
        private int[] Robot_Pr_type = new int[100];
        private double[,] Robot_Pr_coor = new double[100, 6];
        private int[] Robot_Pr_tool = new int[100];
        private int[] Robot_Pr_base = new int[100];
        private int[] Robot_DI = new int[48];
        private int[] Robot_DO = new int[48];
        private int[] Robot_RI = new int[8];
        private int[] Robot_RO = new int[8];
        private int[] Robot_VO = new int[3];


        public DeviceTabControll() {

            InitializeComponent();

        }

        public DeviceTabControll( int v ) {
            handle = v;
            InitializeComponent();
            Register_Timer = new System.Timers.Timer();
            Register_Timer.Enabled = false;
            Register_Timer.Interval = 1000;
            Register_Timer.Elapsed += new System.Timers.ElapsedEventHandler( RegisterTimer_Tick );


            IO_Timer = new System.Timers.Timer();
            IO_Timer.Enabled = false;
            IO_Timer.Interval = 1000;
            IO_Timer.Elapsed += new System.Timers.ElapsedEventHandler( IO_Timer_Tick );


            Grid_AddColumns( DataGrid_Pos );
            Grid_AddTimerColumns( DataGrid_Timer );
            Grid_AddCounterColumns( DataGrid_Counter );
            Grid_AddPRColumns( DataGrid_PR );
            Grid_AddIOColumns( DataGrid_DI, 48 );
            Grid_AddIOColumns( DataGrid_DO, 48 );
            Grid_AddIOColumns( DataGrid_FI, 8 );
            Grid_AddIOColumns( DataGrid_FO, 8 );
            Grid_AddIOColumns( DataGrid_RI, 8 );
            Grid_AddIOColumns( DataGrid_RO, 8 );
            Grid_AddIOColumns( DataGrid_VO, 3 );

            CurSelJogType = ( int )JogType.Joint;
            ComboBox_JogType.Items.Add( "Cart" );
            ComboBox_JogType.Items.Add( "Joint" );
            ComboBox_JogType.Items.Add( "Tool" );
            ComboBox_JogType.SelectedIndex = 1;
            if ( HRobot.get_operation_mode( handle ) == 0 ) {
                Bnt_SafetyState.BackColor = System.Drawing.Color.DarkBlue;
                Bnt_SafetyState.ForeColor = System.Drawing.Color.White;
            } else if ( HRobot.get_operation_mode( handle ) == 1 ) {
                Bnt_SafetyState.BackColor = System.Drawing.Color.Red;
                Bnt_SafetyState.ForeColor = System.Drawing.Color.White;
            }

            StringBuilder HRSSverStr = new StringBuilder();
            HRobot.get_hrss_version( handle, HRSSverStr );
            Label_HRSS_version.Text = "HRSS VERSION: " + HRSSverStr;

            StringBuilder RobotTypeStr = new StringBuilder();
            HRobot.get_robot_type( handle, RobotTypeStr );
            Global.Instance.RobotType = RobotTypeStr;
            Label_RobotType.Text = "ROBOT TYPE: " + RobotTypeStr;

            int[] birth = new int[3];
            HRobot.get_device_born_date( handle, birth );
            Label_Birthday.Text = "BIRTHDAY: " + birth[0] + "/" + birth[1] + "/" + birth[2];

            StringBuilder RobotID = new StringBuilder();
            HRobot.get_robot_id( handle, RobotID );
            Global.Instance.RobotID = RobotID;
            TextBox_RobotID.Text = RobotID.ToString();

            SetFirstColReadOnly( DataGrid_Pos );
            SetFirstColReadOnly( DataGrid_Counter );
            SetFirstColReadOnly( DataGrid_Timer );
            SetFirstColReadOnly( DataGrid_PR );


            for ( int a = 0; a < 16; a++ ) {
                ComboboxItem toolItem = new ComboboxItem();
                toolItem.Text = a.ToString();
                toolItem.Value = a;
                Combo_Tool.Items.Add( toolItem );
            }


            for ( int a = 0; a < 32; a++ ) {
                ComboboxItem baseItem = new ComboboxItem();
                baseItem.Text = a.ToString();
                baseItem.Value = a;
                Combo_Base.Items.Add( baseItem );
            }
            TextBox_ConnectionLevel.ForeColor = Color.White;
            Bnt_SafetyState.ForeColor = Color.White;

            for ( int a = 1; a <= 4; a++ ) {
                ComboboxItem rsrItem = new ComboboxItem();
                rsrItem.Text = a.ToString();
                rsrItem.Value = a;
                Combo_RSR.Items.Add( rsrItem );
            }
            for ( int a = 1; a <= 2047; a++ ) {
                ComboboxItem pnsItem = new ComboboxItem();
                pnsItem.Text = a.ToString();
                pnsItem.Value = a;
                Combo_PNS.Items.Add( pnsItem );
            }

        }



        private void SetFirstColReadOnly( DataGridView dataGridIn ) {
            foreach ( DataGridViewColumn dc in dataGridIn.Columns ) {
                if ( dc.Index.Equals( 0 ) ) {
                    dc.ReadOnly = true;
                } else {
                    dc.ReadOnly = false;
                }
            }
        }


        //Acc Group
        private void TextBox_Acc_KeyPress( object sender, KeyPressEventArgs e ) {
            if ( e.KeyChar == ( char )13 ) {
                HRobot.set_acc_dec_ratio( handle, Convert.ToInt16( TextBox_Acc.Text ) );
                Bar_Acc.Focus();
            }
        }
        private void Bnt_AccUp_Click( object sender, EventArgs e ) {
            if ( AccRatio + 10 > 100 ) {
                HRobot.set_acc_dec_ratio( handle, 100 );
            } else {
                HRobot.set_acc_dec_ratio( handle, AccRatio + 10 );
            }
        }

        private void Bnt_AccDown_Click( object sender, EventArgs e ) {
            if ( AccRatio - 10 < 1 ) {
                HRobot.set_acc_dec_ratio( handle, 1 );
            } else {
                HRobot.set_acc_dec_ratio( handle, AccRatio - 10 );
            }
        }


        // Ptp Group
        private void TextBox_Ptp_KeyPress( object sender, KeyPressEventArgs e ) {
            if ( e.KeyChar == ( char )13 ) {
                HRobot.set_ptp_speed( handle, Convert.ToInt16( TextBox_Ptp.Text ) );
                Bar_Ptp.Focus();
            }
        }

        private void Bnt_PtpUp_Click( object sender, EventArgs e ) {
            if ( PtpRatio + 10 > 100 ) {
                HRobot.set_ptp_speed( handle, 100 );
            } else {
                HRobot.set_ptp_speed( handle, PtpRatio + 10 );
            }
        }

        private void Bnt_PtpDown_Click( object sender, EventArgs e ) {
            if ( PtpRatio - 10 < 1 ) {
                HRobot.set_ptp_speed( handle, 1 );
            } else {
                HRobot.set_ptp_speed( handle, PtpRatio - 10 );
            }
        }
        //Line Group
        private void TextBox_Lin_KeyPress( object sender, KeyPressEventArgs e ) {
            if ( e.KeyChar == ( char )13 ) {
                HRobot.set_lin_speed( handle, Convert.ToInt16( TextBox_Lin.Text ) );
                Bar_Lin.Focus();
            }
        }

        private void Bnt_LinUp_Click( object sender, EventArgs e ) {
            if ( LinSpeed + 100 > 3500 ) {
                HRobot.set_lin_speed( handle, 3500 );
            } else {
                HRobot.set_lin_speed( handle, LinSpeed + 100 );
            }
        }

        private void Bnt_LinDown_Click( object sender, EventArgs e ) {
            if ( LinSpeed - 100 < 1 ) {
                HRobot.set_lin_speed( handle, 1 );
            } else {
                HRobot.set_lin_speed( handle, LinSpeed - 100 );
            }
        }
        //Override Group
        private void TextBox_Override_KeyPress( object sender, KeyPressEventArgs e ) {
            if ( e.KeyChar == ( char )13 ) {
                HRobot.set_override_ratio( handle, Convert.ToInt16( TextBox_Override.Text ) );
                Bar_Override.Focus();
            }
        }

        private void Btn_OverrideUp_Click( object sender, EventArgs e ) {
            if ( OverrideRatio + 10 > 100 ) {
                HRobot.set_override_ratio( handle, 100 );
            } else {
                HRobot.set_override_ratio( handle, OverrideRatio + 10 );
            }
        }

        private void Btn_OverrideDown_Click( object sender, EventArgs e ) {
            if ( OverrideRatio - 10 < 1 ) {
                HRobot.set_override_ratio( handle, 1 );
            } else {
                HRobot.set_override_ratio( handle, OverrideRatio - 10 );
            }
        }

        // Safety button
        private void Bnt_SafetyState_Click( object sender, EventArgs e ) {
            //if ( HRobot.get_operation_mode( handle ) == 0 ) {
            //    if ( HRobot.set_operation_mode( handle, 0 ) == 0 ) {
            //        //  Bnt_SafetyState.BackColor = System.Drawing.Color.Red;
            //    }

            //} else {
            //    if ( HRobot.set_operation_mode( handle, 1 ) == 0 ) {
            //        //  Bnt_SafetyState.BackColor = System.Drawing.Color.DarkBlue;
            //    }
            //}
        }

        // Program Button - Start
        private void Bnt_Go_Click( object sender, EventArgs e ) {
            if ( HRobot.get_function_output( handle, 0 ) == 1 && HRobot.get_function_output( handle, 1 ) == 1 ) {
                HRobot.task_continue( handle );
            } else {
                HRobot.task_start( handle, TextBox_ProgramName.Text );
            }
        }

        private void Bnt_Pause_Click( object sender, EventArgs e ) {
            HRobot.task_hold( handle );
        }

        private void But_Stop_Click( object sender, EventArgs e ) {
            HRobot.task_abort( handle );
        }



        private void Bnt_Home_KeyUp( object sender, KeyPressEventArgs e ) {
            HRobot.motion_abort( handle );
        }

        private void PosTimer_Tick( object sender, EventArgs e ) {

            try {

                if ( HRobot.get_operation_mode( handle ) == 0 ) {
                    Bnt_SafetyState.BackColor = System.Drawing.Color.DarkBlue;
                    Bnt_SafetyState.Text = "Running";
                } else {
                    Bnt_SafetyState.BackColor = System.Drawing.Color.Green;
                    Bnt_SafetyState.Text = "Safety";
                }

                int[] OperationTimeStr = new int[5];
                HRobot.get_operation_time( handle, OperationTimeStr );
                this.Label_OperationTime.Text = "OPERATION TIME: " + OperationTimeStr[0] + "年" + OperationTimeStr[1] + "月" + OperationTimeStr[2] + "天 " + OperationTimeStr[3] + ":" + OperationTimeStr[4];

                int[] Utilization_Time = new int[6];
                HRobot.get_utilization( handle, Utilization_Time );


                this.Label_Utilization.Text = "UTILIZATION TIME: " + Utilization_Time[0] + "年" + Utilization_Time[1] + "月" + Utilization_Time[2] + "天 " + Utilization_Time[3] + "時" + Utilization_Time[4] + "分" + Utilization_Time[5] + "秒";
                Double ratio =  -1;
                UtilRatio = HRobot.get_utilization_ratio( handle, ref ratio );
                this.Label_UtilizationRatio.Text = "UTILIZATION RATIO: " + Convert.ToString( ratio ) + "%";

                UInt64[] alarm_code = new UInt64[100];
                int count = 0;
                HRobot.get_alarm_code( handle, ref count, alarm_code );
                String tmp = "";
                for ( int a = 0; a < count; a++ ) {
                    tmp = tmp + String.Format( "{0:x16}\n", alarm_code[a] );

                }
                this.TextBox_ErrorInfo.Text = tmp;

                HRobot.get_encoder_count( handle, Enc );
                for ( int a = 0; a < 6; a++ ) {
                    this.DataGrid_Pos.Rows[a].Cells["value"].Value = Enc[a];
                }


                HRobot.get_current_position( handle, CartTxBxDegree );
                for ( int a = 12; a < 12 + 6; a++ ) {
                    this.DataGrid_Pos.Rows[a].Cells["value"].Value = CartTxBxDegree[a - 12];
                }

                if ( !TextBox_Ptp.Focused ) {
                    PtpRatio = HRobot.get_ptp_speed( handle );
                    this.DataGrid_Pos.Rows[24].Cells["value"].Value = PtpRatio;
                    this.Bar_Ptp.Value = PtpRatio;
                    this.TextBox_Ptp.Text = Convert.ToString( Bar_Ptp.Value );
                }

                if ( !TextBox_Lin.Focused ) {
                    LinSpeed = HRobot.get_lin_speed( handle );
                    this.DataGrid_Pos.Rows[25].Cells["value"].Value = LinSpeed;
                    this.Bar_Lin.Value = Convert.ToInt16( LinSpeed / 3500 * 100 );
                    this.TextBox_Lin.Text = Convert.ToString( LinSpeed );
                }

                if ( !TextBox_Override.Focused ) {
                    OverrideRatio = HRobot.get_override_ratio( handle );
                    this.DataGrid_Pos.Rows[26].Cells["value"].Value = OverrideRatio;
                    this.Bar_Override.Value = OverrideRatio;
                    this.TextBox_Override.Text = Convert.ToString( Bar_Override.Value );
                }

                if ( !TextBox_Acc.Focused ) {
                    AccRatio = HRobot.get_acc_dec_ratio( handle );
                    this.DataGrid_Pos.Rows[27].Cells["value"].Value = AccRatio;
                    this.Bar_Acc.Value = AccRatio;
                    this.TextBox_Acc.Text = Convert.ToString( Bar_Acc.Value );
                }
                MotionType = HRobot.get_motion_state( handle );
                switch ( MotionType ) {
                    case 1:
                        this.DataGrid_Pos.Rows[28].Cells["value"].Value = "IDLE";
                        break;
                    case 2:
                        this.DataGrid_Pos.Rows[28].Cells["value"].Value = "RUNNING";
                        break;
                    case 3:
                        this.DataGrid_Pos.Rows[28].Cells["value"].Value = "HOLD";
                        break;
                    case 4:
                        this.DataGrid_Pos.Rows[28].Cells["value"].Value = "DELAY";
                        break;
                    case 5:
                        this.DataGrid_Pos.Rows[28].Cells["value"].Value = "WAIT COMMAND";
                        break;
                }

                HRobot.get_current_rpm( handle, JointRpm );
                for ( int a = 29; a < 29 + 6; a++ ) {
                    this.DataGrid_Pos.Rows[a].Cells["value"].Value = CartTxBxDegree[a - 29];
                }

                double[] mil = new double[6];
                HRobot.get_mileage( handle, mil );
                for ( int a = 35; a < 35 + 6; a++ ) {
                    this.DataGrid_Pos.Rows[a].Cells["value"].Value = mil[a - 35];
                }

                double[] tomil = new double[6];
                HRobot.get_total_mileage( handle, tomil );
                for ( int a = 41; a < 41 + 6; a++ ) {
                    this.DataGrid_Pos.Rows[a].Cells["value"].Value = tomil[a - 41];
                }

                double[] torq = new double[6];
                HRobot.get_motor_torque( handle, torq );
                for ( int a = 47; a < 47 + 6; a++ ) {
                    this.DataGrid_Pos.Rows[a].Cells["value"].Value = torq[a - 47];
                }



            } catch {

            }
        }

        private void JogNeg1_MouseDown( object sender, MouseEventArgs e ) {
            HRobot.jog( handle, CurSelJogType, 0, -1 );

        }

        private void JogNeg1_MouseUp( object sender, MouseEventArgs e ) {
            HRobot.jog_stop( handle );
        }

        private void JogNeg2_MouseDown( object sender, MouseEventArgs e ) {
            HRobot.jog( handle, CurSelJogType, 1, -1 );
        }

        private void JogNeg2_MouseUp( object sender, MouseEventArgs e ) {
            HRobot.jog_stop( handle );
        }

        private void JogNeg3_MouseDown( object sender, MouseEventArgs e ) {
            HRobot.jog( handle, CurSelJogType, 2, -1 );
        }

        private void JogNeg3_MouseUp( object sender, MouseEventArgs e ) {
            HRobot.jog_stop( handle );
        }

        private void JogNeg4_MouseDown( object sender, MouseEventArgs e ) {
            HRobot.jog( handle, CurSelJogType, 3, -1 );
        }

        private void JogNeg4_MouseUp( object sender, MouseEventArgs e ) {
            HRobot.jog_stop( handle );
        }

        private void JogNeg5_MouseDown( object sender, MouseEventArgs e ) {
            HRobot.jog( handle, CurSelJogType, 4, -1 );
        }

        private void JogNeg5_MouseUp( object sender, MouseEventArgs e ) {
            HRobot.jog_stop( handle );
        }

        private void JogNeg6_MouseDown( object sender, MouseEventArgs e ) {
            HRobot.jog( handle, CurSelJogType, 5, -1 );
        }

        private void JogNeg6_MouseUp( object sender, MouseEventArgs e ) {
            HRobot.jog_stop( handle );
        }

        private void JogPositive1_MouseDown( object sender, MouseEventArgs e ) {
            int rlt = HRobot.jog( handle, CurSelJogType, 0, 1 );
        }

        private void JogPositive1_MouseUp( object sender, MouseEventArgs e ) {
            HRobot.jog_stop( handle );
        }

        private void JogPositive2_MouseDown( object sender, MouseEventArgs e ) {
            HRobot.jog( handle, CurSelJogType, 1, 1 );
        }

        private void JogPositive2_MouseUp( object sender, MouseEventArgs e ) {
            HRobot.jog_stop( handle );
        }

        private void JogPositive3_MouseDown( object sender, MouseEventArgs e ) {
            HRobot.jog( handle, CurSelJogType, 2, 1 );
        }

        private void JogPositive3_MouseUp( object sender, MouseEventArgs e ) {
            HRobot.jog_stop( handle );
        }

        private void JogPositive4_MouseDown( object sender, MouseEventArgs e ) {
            HRobot.jog( handle, CurSelJogType, 3, 1 );
        }

        private void JogPositive4_MouseUp( object sender, MouseEventArgs e ) {
            HRobot.jog_stop( handle );
        }

        private void JogPositive5_MouseDown( object sender, MouseEventArgs e ) {
            HRobot.jog( handle, CurSelJogType, 4, 1 );
        }

        private void JogPositive5_MouseUp( object sender, MouseEventArgs e ) {
            HRobot.jog_stop( handle );
        }

        private void JogPositive6_MouseDown( object sender, MouseEventArgs e ) {
            HRobot.jog( handle, CurSelJogType, 5, 1 );
        }

        private void JogPositive6_MouseUp( object sender, MouseEventArgs e ) {
            HRobot.jog_stop( handle );
        }

        private void Bnt_Servo_Click( object sender, EventArgs e ) {

            if ( HRobot.get_motor_state( handle ) == 0 ) {
                HRobot.set_motor_state( handle, 1 );
            } else {
                HRobot.set_motor_state( handle, 0 );
            }
        }

        public static void EventFun( UInt16 cmd, UInt16 rlt, ref UInt16 Msg, int len ) {
        }
        private void Grid_AddColumns( DataGridView InGrid ) {
            InGrid.BackgroundColor = Color.White;
            InGrid.RowHeadersVisible = false;
            DataGridViewTextBoxCell tbCell = new DataGridViewTextBoxCell();
            DataGridViewColumn tbCol = new DataGridViewColumn();
            tbCol.Name = "Parameter";
            tbCol.HeaderText = "Parameter";
            tbCol.CellTemplate = tbCell;
            tbCol.Width = Convert.ToInt16( DataGrid_Pos.Width / 3.5 );
            InGrid.Columns.Add( tbCol );

            tbCell = new DataGridViewTextBoxCell();
            tbCol = new DataGridViewColumn();
            tbCol.Name = "Value";
            tbCol.HeaderText = "Value";
            tbCol.CellTemplate = tbCell;
            tbCol.Width = Convert.ToInt16( DataGrid_Pos.Width / 2.5 );
            InGrid.Columns.Add( tbCol );

            tbCell = new DataGridViewTextBoxCell();
            tbCol = new DataGridViewColumn();
            tbCol.Name = "Unit";
            tbCol.HeaderText = "Unit";
            tbCol.CellTemplate = tbCell;
            tbCol.Width = DataGrid_Pos.Width / 5;
            InGrid.Columns.Add( tbCol );

            DataGridViewRowCollection rows = InGrid.Rows;
            rows.Add( new Object[] { "Motor1", 0, "Unit" } );
            rows.Add( new Object[] { "Motor2", 0, "Unit" } );
            rows.Add( new Object[] { "Motor3", 0, "Unit" } );
            rows.Add( new Object[] { "Motor4", 0, "Unit" } );
            rows.Add( new Object[] { "Motor5", 0, "Unit" } );
            rows.Add( new Object[] { "Motor6", 0, "Unit" } );
            rows.Add( new Object[] { "A1", 0, "degree" } );
            rows.Add( new Object[] { "A2", 0, "degree" } );
            rows.Add( new Object[] { "A3", 0, "degree" } );
            rows.Add( new Object[] { "A4", 0, "degree" } );
            rows.Add( new Object[] { "A5", 0, "degree" } );
            rows.Add( new Object[] { "A6", 0, "degree" } );

            rows.Add( new Object[] { "X", 0, "mm" } );
            rows.Add( new Object[] { "Y", 0, "mm" } );
            rows.Add( new Object[] { "Z", 0, "mm" } );
            rows.Add( new Object[] { "A", 0, "mm" } );
            rows.Add( new Object[] { "B", 0, "mm" } );
            rows.Add( new Object[] { "C", 0, "mm" } );

            rows.Add( new Object[] { "X0", 0, "mm" } );
            rows.Add( new Object[] { "Y0", 0, "mm" } );
            rows.Add( new Object[] { "Z0", 0, "mm" } );
            rows.Add( new Object[] { "A", 0, "mm" } );
            rows.Add( new Object[] { "B", 0, "mm" } );
            rows.Add( new Object[] { "C", 0, "mm" } );

            rows.Add( new Object[] { "PTP", 0, "%" } );
            rows.Add( new Object[] { "FEED", 0, "mm/s" } );
            rows.Add( new Object[] { "OVERRIDE", 0, "%" } );
            rows.Add( new Object[] { "ACC", 0, "%" } );
            rows.Add( new Object[] { "Motion", 0, "Type" } );

            rows.Add( new Object[] { "A1", 0, "rpm" } );
            rows.Add( new Object[] { "A2", 0, "rpm" } );
            rows.Add( new Object[] { "A3", 0, "rpm" } );
            rows.Add( new Object[] { "A4", 0, "rpm" } );
            rows.Add( new Object[] { "A5", 0, "rpm" } );
            rows.Add( new Object[] { "A6", 0, "rpm" } );

            rows.Add( new Object[] { "M_A1", 0, "Unit" } );
            rows.Add( new Object[] { "M_A2", 0, "Unit" } );
            rows.Add( new Object[] { "M_A3", 0, "Unit" } );
            rows.Add( new Object[] { "M_A4", 0, "Unit" } );
            rows.Add( new Object[] { "M_A5", 0, "Unit" } );
            rows.Add( new Object[] { "M_A6", 0, "Unit" } );

            rows.Add( new Object[] { "TM_A1", 0, "Unit" } );
            rows.Add( new Object[] { "TM_A2", 0, "Unit" } );
            rows.Add( new Object[] { "TM_A3", 0, "Unit" } );
            rows.Add( new Object[] { "TM_A4", 0, "Unit" } );
            rows.Add( new Object[] { "TM_A5", 0, "Unit" } );
            rows.Add( new Object[] { "TM_A6", 0, "Unit" } );


            rows.Add( new Object[] { "T_A1", 0, "%" } );
            rows.Add( new Object[] { "T_A2", 0, "%" } );
            rows.Add( new Object[] { "T_A3", 0, "%" } );
            rows.Add( new Object[] { "T_A4", 0, "%" } );
            rows.Add( new Object[] { "T_A5", 0, "%" } );
            rows.Add( new Object[] { "T_A6", 0, "%" } );
        }

        private void Grid_AddCounterColumns( DataGridView InGrid ) {
            InGrid.BackgroundColor = Color.White;
            InGrid.RowHeadersVisible = false;
            DataGridViewTextBoxCell tbCell = new DataGridViewTextBoxCell();
            DataGridViewColumn tbCol = new DataGridViewColumn();
            tbCol.Name = "Counter";
            tbCol.HeaderText = "Counter";
            tbCol.CellTemplate = tbCell;
            tbCol.Width = Convert.ToInt16( InGrid.Width / 2.5 );
            InGrid.Columns.Add( tbCol );

            tbCell = new DataGridViewTextBoxCell();
            tbCol = new DataGridViewColumn();
            tbCol.Name = "Value";
            tbCol.HeaderText = "Value";
            tbCol.CellTemplate = tbCell;
            tbCol.Width = Convert.ToInt16( InGrid.Width / 2 );
            InGrid.Columns.Add( tbCol );

            DataGridViewRowCollection rows = InGrid.Rows;
            for ( int a = 1; a <= 20; a++ ) {
                rows.Add( new Object[] { a, 0 } );
            }
        }

        private void Grid_AddTimerColumns( DataGridView InGrid ) {
            InGrid.BackgroundColor = Color.White;
            InGrid.RowHeadersVisible = false;
            DataGridViewTextBoxCell tbCell = new DataGridViewTextBoxCell();
            DataGridViewColumn tbCol = new DataGridViewColumn();
            tbCol.Name = "Timer";
            tbCol.HeaderText = "Timer";
            tbCol.CellTemplate = tbCell;
            tbCol.Width = Convert.ToInt16( InGrid.Width / 2.5 );
            InGrid.Columns.Add( tbCol );

            tbCell = new DataGridViewTextBoxCell();
            tbCol = new DataGridViewColumn();
            tbCol.Name = "Value";
            tbCol.HeaderText = "Value";
            tbCol.CellTemplate = tbCell;
            tbCol.Width = Convert.ToInt16( InGrid.Width / 2 );
            InGrid.Columns.Add( tbCol );

            DataGridViewRowCollection rows = InGrid.Rows;
            for ( int a = 1; a <= 20; a++ ) {
                rows.Add( new Object[] { a, 0 } );
            }
        }


        private void Grid_AddPRColumns( DataGridView InGrid ) {
            InGrid.BackgroundColor = Color.White;
            InGrid.RowHeadersVisible = false;
            DataGridViewTextBoxCell tbCell = new DataGridViewTextBoxCell();
            DataGridViewColumn tbCol = new DataGridViewColumn();
            tbCol.Name = "PR";
            tbCol.HeaderText = "PR";
            tbCol.CellTemplate = tbCell;
            tbCol.Width = Convert.ToInt16( InGrid.Width / 10 );
            InGrid.Columns.Add( tbCol );


            //tbCell = new DataGridViewTextBoxCell();
            //tbCol = new DataGridViewColumn();
            //tbCol.Name = "TYPE";
            //tbCol.HeaderText = "TYPE";
            //tbCol.CellTemplate = tbCell;
            //tbCol.Width = Convert.ToInt16(InGrid.Width / 6);
            //InGrid.Columns.Add(tbCol);


            tbCell = new DataGridViewTextBoxCell();
            tbCol = new DataGridViewColumn();
            tbCol.Name = "data";
            tbCol.HeaderText = "data";
            tbCol.CellTemplate = tbCell;
            tbCol.Width = Convert.ToInt16( InGrid.Width / 2.3 );
            InGrid.Columns.Add( tbCol );

            tbCell = new DataGridViewTextBoxCell();
            tbCol = new DataGridViewColumn();
            tbCol.Name = "tool";
            tbCol.HeaderText = "tool";
            tbCol.CellTemplate = tbCell;
            tbCol.Width = Convert.ToInt16( InGrid.Width / 10 );
            InGrid.Columns.Add( tbCol );

            tbCell = new DataGridViewTextBoxCell();
            tbCol = new DataGridViewColumn();
            tbCol.Name = "base";
            tbCol.HeaderText = "base";
            tbCol.CellTemplate = tbCell;
            tbCol.Width = Convert.ToInt16( InGrid.Width / 10 );
            InGrid.Columns.Add( tbCol );

            DataGridViewRowCollection rows = InGrid.Rows;
            for ( int a = 1; a <= 100; a++ ) {
                rows.Add( new Object[] { a, 0 } );
            }
            DataGridViewComboBoxColumn comboboxColumn = new DataGridViewComboBoxColumn();
            //tbCol.Name = "TYPE";
            //tbCol.HeaderText = "TYPE";
            //tbCol.CellTemplate = tbCell;
            //
            //InGrid.Columns.Add(tbCol);
            comboboxColumn.Name = "TYPE";
            comboboxColumn.ValueMember = "Value";
            comboboxColumn.DisplayMember = "Text";
            comboboxColumn.HeaderText = "TYPE";
            comboboxColumn.MaxDropDownItems = 3;
            ComboboxItem itemN = new ComboboxItem();
            itemN.Text = "NULL";
            itemN.Value = 2;
            ComboboxItem item = new ComboboxItem();
            item.Text = "CART";
            item.Value = 0;
            ComboboxItem itemJ = new ComboboxItem();
            itemJ.Text = "JOINT";
            itemJ.Value = 1;
            comboboxColumn.Items.Add( itemN );
            comboboxColumn.Items.Add( item );
            comboboxColumn.Items.Add( itemJ );
            comboboxColumn.Width = Convert.ToInt16( InGrid.Width / 5 );
            InGrid.Columns.Insert( 1, comboboxColumn );

        }

        private void Grid_AddIOColumns( DataGridView InGrid, int count ) {
            InGrid.BackgroundColor = Color.White;
            InGrid.RowHeadersVisible = false;
            DataGridViewTextBoxCell tbCell = new DataGridViewTextBoxCell();
            DataGridViewColumn tbCol = new DataGridViewColumn();
            tbCol.Name = "NO.";
            tbCol.HeaderText = "NO.";
            tbCol.CellTemplate = tbCell;
            tbCol.Width = Convert.ToInt16( DataGrid_Pos.Width / 2.5 );
            InGrid.Columns.Add( tbCol );

            tbCell = new DataGridViewTextBoxCell();
            tbCol = new DataGridViewColumn();
            tbCol.Name = "Value";
            tbCol.HeaderText = "Value";
            tbCol.CellTemplate = tbCell;
            tbCol.Width = Convert.ToInt16( DataGrid_Pos.Width / 2.5 );
            InGrid.Columns.Add( tbCol );
            DataGridViewRowCollection rows = InGrid.Rows;
            for ( int a = 1; a <= count; a++ ) {
                rows.Add( new Object[] { a, "0" } );
            }



        }

        private void Bnt_Close_Click( object sender, EventArgs e ) {

        }

        private void ComboBox_JogType_SelectedIndexChanged( object sender, EventArgs e ) {
            CurSelJogType = ComboBox_JogType.SelectedIndex;
            JogType t = ( JogType )CurSelJogType;
            switch ( t ) {
                case JogType.Joint:
                    Label_Jog1.Text = "A1";
                    Label_Jog2.Text = "A2";
                    Label_Jog3.Text = "A3";
                    Label_Jog4.Text = "A4";
                    Label_Jog5.Text = "A5";
                    Label_Jog6.Text = "A6";
                    break;
                case JogType.Cart:
                    Label_Jog1.Text = "X";
                    Label_Jog2.Text = "Y";
                    Label_Jog3.Text = "Z";
                    Label_Jog4.Text = "A";
                    Label_Jog5.Text = "B";
                    Label_Jog6.Text = "C";
                    break;
                case JogType.Tool:
                    Label_Jog1.Text = "Tx";
                    Label_Jog2.Text = "Ty";
                    Label_Jog3.Text = "Tz";
                    Label_Jog4.Text = "Ta";
                    Label_Jog5.Text = "Tb";
                    Label_Jog6.Text = "Tc";
                    break;

            }
        }

        private void Bnt_Clean_Click( object sender, EventArgs e ) {
            HRobot.clear_alarm( handle );
        }

        private void TextBox_ErrorInfo_TextChanged( object sender, EventArgs e ) {

        }

        delegate void DelegateSetDataGridText( DataGridView c, int row, string col, string text );

        private void SetDataGridText( DataGridView c, int row, string col, string text ) {
            c.Rows[row].Cells[col].Value = text;
        }

        delegate void DelegateSetDataGridValue( DataGridView c, int row, string col, int v );
        private void SetDataGridValue( DataGridView c, int row, string col, int v ) {
            c.Rows[row].Cells[col].Value = v;
        }

        delegate void DelegateSetDataGridString( DataGridView c, int row, string col, string v );
        private void SetDataGridString( DataGridView c, int row, string col, string v ) {
            c.Rows[row].Cells[col].Value = v;
        }

        private void RegisterTimer_Tick( object sender, EventArgs e ) {

            for ( int a = 1; a <= 20; a++ ) {
                DelegateSetDataGridValue d = new DelegateSetDataGridValue( SetDataGridValue );
                this.Invoke( d, new object[] { DataGrid_Timer, a - 1, "Value", HRobot.get_timer( handle, a ) } );
            }

            for ( int a = 1; a <= 20; a++ ) {
                DelegateSetDataGridValue d = new DelegateSetDataGridValue( SetDataGridValue );
                this.Invoke( d, new object[] { DataGrid_Counter, a - 1, "Value", HRobot.get_counter( handle, a ) } );
            }
            try {
                for ( int a = 1; a <= 5; a++ ) {
                    if ( HRobot.get_pr_type( handle, a ) != -1 ) {
                        DelegateSetDataGridValue d = new DelegateSetDataGridValue( SetDataGridValue );
                        this.Invoke( d, new object[] { DataGrid_PR, a - 1, "TYPE", HRobot.get_pr_type( handle, a ) } );

                        int[] tb = new int[2];
                        HRobot.get_pr_tool_base( handle, a, tb );
                        this.Invoke( d, new object[] { DataGrid_PR, a - 1, "tool", tb[0] } );
                        this.Invoke( d, new object[] { DataGrid_PR, a - 1, "base", tb[1] } );

                        double[] coor = new double[6];
                        HRobot.get_pr_coordinate( handle, a, coor );
                        DelegateSetDataGridText dt = new DelegateSetDataGridText( SetDataGridText );
                        this.Invoke( dt, new object[] { DataGrid_PR, a - 1, "data", "{" + coor[0] + "," + coor[1] + "," + coor[2] + "," + coor[3] + "," + coor[4] + "," + coor[5] + "}" } );
                    } else {
                        DataGrid_PR.Rows[a - 1].Cells["data"].Value = "";
                        DataGrid_PR.Rows[a - 1].Cells["tool"].Value = "";
                        DataGrid_PR.Rows[a - 1].Cells["base"].Value = "";
                    }

                }
            } catch ( Exception ex ) {
                Console.WriteLine( ex.ToString() );
            }
        }

        private bool ValidaCell( DataGridView dv, DataGridViewCell cell ) {
            cell.ErrorText = "";
            if ( dv.Rows[cell.RowIndex].Cells[0].Value == null || dv.Rows[cell.RowIndex].Cells[0].Value.ToString() == "" ) {
                return true;
            }

            if ( cell.Value == null || cell.Value.ToString() == "" ) {
                cell.ErrorText = "input invalid.";
                return false;
            }

            System.Text.RegularExpressions.Regex regul = new System.Text.RegularExpressions.Regex( @"[0-9]" );
            if ( !regul.IsMatch( cell.Value.ToString() ) ) {
                cell.ErrorText = "input invalid.";
                return false;
            }
            return true;
        }
        private void Timer_CellEndEdit( object sender, DataGridViewCellEventArgs e ) {
            DataGridViewCell DataGridCell_Timer = DataGrid_Timer.CurrentCell;
            if ( ValidaCell( DataGrid_Timer, DataGridCell_Timer ) ) {
                HRobot.set_timer( handle, DataGrid_Timer.CurrentRow.Index + 1, Convert.ToInt32( DataGrid_Timer.CurrentCell.Value ) );

            }
            DataGrid_Timer.Refresh();
        }

        private void Counter_CellEndEdit( object sender, DataGridViewCellEventArgs e ) {
            DataGridViewCell DataGridCell_Counter = DataGrid_Counter.CurrentCell;
            if ( ValidaCell( DataGrid_Counter, DataGridCell_Counter ) ) {
                HRobot.set_counter( handle, DataGrid_Counter.CurrentRow.Index + 1, Convert.ToInt32( DataGrid_Counter.CurrentCell.Value ) );

            }
            DataGrid_Counter.Refresh();
        }

        private void DataGrid_PR_EditingControlShowing( object sender, DataGridViewEditingControlShowingEventArgs e ) {
            if ( DataGrid_PR.CurrentCell.ColumnIndex == 1 && e.Control is ComboBox ) {
                ComboBox comboBox = e.Control as ComboBox;
                comboBox.SelectedValueChanged += LastColumnComboSelectionChanged;
                //comboBox.SelectedIndexChanged += LastColumnComboSelectionChanged;
            }
        }
        private void LastColumnComboSelectionChanged( object sender, EventArgs e ) {
            var currentcell = DataGrid_PR.CurrentCellAddress;
            var sendingCB = sender as DataGridViewComboBoxEditingControl;
            DataGridViewComboBoxCell cel = ( DataGridViewComboBoxCell )DataGrid_PR.Rows[currentcell.Y].Cells[1];
            cel.Value = sendingCB.EditingControlFormattedValue.ToString();
            if ( cel.Value.ToString() == "JOINT" ) {
                HRobot.set_pr_type( handle, currentcell.Y + 1, 1 );
            } else if ( cel.Value.ToString() == "CART" ) {
                HRobot.set_pr_type( handle, currentcell.Y + 1, 0 );
            }
        }

        private void PR_CellEndEdit( object sender, DataGridViewCellEventArgs e ) {
            DataGridViewCell DataGridCell_PR = DataGrid_PR.CurrentCell;
            int[] tb = new int[2] { 0, 0 };
            HRobot.get_pr_tool_base( handle, DataGrid_PR.CurrentCellAddress.Y + 1, tb );


            if ( ValidaCell( DataGrid_PR, DataGridCell_PR ) ) {
                switch ( DataGrid_PR.CurrentCellAddress.X ) {
                    case 2: {
                        try {
                            List<double> coor = new List<double>();
                            coor = Extension.Numbers( DataGrid_PR.CurrentCell.Value.ToString() );
                            double[] c = new double[6] { coor[0], coor[1], coor[2], coor[3], coor[4], coor[5] };
                            HRobot.set_pr_coordinate( handle, DataGrid_PR.CurrentRow.Index + 1, c );
                        } catch {

                        }

                    }
                    break;
                    case 3: {
                        if ( Convert.ToInt32( DataGrid_PR.CurrentCell.Value ) < 0 || Convert.ToInt32( DataGrid_PR.CurrentCell.Value ) > 15 ) {
                            return;
                        }
                        HRobot.set_pr_tool_base( handle, DataGrid_PR.CurrentRow.Index + 1, Convert.ToInt32( DataGrid_PR.CurrentCell.Value ), tb[1] );
                    }
                    break;
                    case 4: {
                        if ( Convert.ToInt32( DataGrid_PR.CurrentCell.Value ) < 0 || Convert.ToInt32( DataGrid_PR.CurrentCell.Value ) > 31 ) {
                            return;
                        }
                        HRobot.set_pr_tool_base( handle, DataGrid_PR.CurrentRow.Index + 1, tb[0], Convert.ToInt32( DataGrid_PR.CurrentCell.Value ) );
                    }
                    break;
                    default:
                        break;
                }


            }
            DataGrid_Counter.Refresh();
        }



        private void Tool_SelectedValueChanged( object sender, EventArgs e ) {
            HRobot.set_tool_number( handle, Combo_Tool.SelectedIndex );
        }

        private void Base_SelectedValueChanged( object sender, EventArgs e ) {
            HRobot.set_base_number( handle, Combo_Base.SelectedIndex );
        }

        private void ToolBase_Timer_Tick( object sender, EventArgs e ) {
            Combo_Tool.SelectedIndex = HRobot.get_tool_number( handle );
            Combo_Base.SelectedIndex = HRobot.get_base_number( handle );
        }

        private void Tool_DropDown( object sender, EventArgs e ) {
            ToolBase_Timer.Stop();
        }

        private void Tool_DropDownClosed( object sender, EventArgs e ) {
            // ToolBase_Timer.Start();
        }

        private void Base_DropDown( object sender, EventArgs e ) {
            ToolBase_Timer.Stop();
        }

        private void Base_DropDownClosed( object sender, EventArgs e ) {
            // ToolBase_Timer.Start();
        }

        private SetTool ToolForm = null;
        private void Bnt_SetTool_Click( object sender, EventArgs e ) {
            double[] coor = new double[6] { 0, 0, 0, 0, 0, 0 };
            HRobot.get_tool_data( handle, Combo_Tool.SelectedIndex, coor );

            if ( ToolForm != null ) {
                ToolForm.Close();
            } else {
                ToolForm = new SetTool( coor, 0, handle, Combo_Tool.SelectedIndex );

                ToolForm.FormClosing += fManage_FormOneClosing;
                ToolForm.Show();
            }
        }
        public void fManage_FormOneClosing( object sender, FormClosingEventArgs e ) {
            ToolForm = null;
        }

        public void fManage_Form2OneClosing( object sender, FormClosingEventArgs e ) {
        }
        private SetTool BaseForm = null;
        private void Bnt_SetBase_Click( object sender, EventArgs e ) {
            double[] coor = new double[6] { 0, 0, 0, 0, 0, 0 };
            HRobot.get_base_data( handle, Combo_Base.SelectedIndex, coor );

            if ( BaseForm != null ) {
                BaseForm.Close();
            } else {
                BaseForm = new SetTool( coor, 1, handle, Combo_Base.SelectedIndex );
                BaseForm.FormClosing += BaseForm_FormOneClosing;
                BaseForm.Show();
            }
        }
        public void BaseForm_FormOneClosing( object sender, FormClosingEventArgs e ) {
            BaseForm = null;
        }

        private void ConnectionLevel_timer_Tick( object sender, EventArgs e ) {
            if ( HRobot.get_connection_level( handle ) == 0 && TextBox_ConnectionLevel.BackColor != Color.Green ) {
                TextBox_ConnectionLevel.BackColor = Color.Green;
                TextBox_ConnectionLevel.Text = "CONNECTION LEVEL \r\n OPERATOR";
                Radio_monitor.Select();
            } else if ( HRobot.get_connection_level( handle ) == 1 && TextBox_ConnectionLevel.BackColor != Color.Red ) {
                TextBox_ConnectionLevel.BackColor = Color.Red;
                TextBox_ConnectionLevel.Text = "CONNECTION LEVEL \r\n EXPERT";
                Radio_controller.Select();

            } else if ( HRobot.get_connection_level( handle ) == -1 && TextBox_ConnectionLevel.BackColor != Color.Gray ) {
                TextBox_ConnectionLevel.BackColor = Color.Gray;
                TextBox_ConnectionLevel.Text = "CONNECTION LEVEL \r\n DISCONNECTED";
            }
        }

        private void comboBox1_SelectedIndexChanged( object sender, EventArgs e ) {

        }

        private void Bnt_RsrGo_Click( object sender, EventArgs e ) {
            if ( Combo_RSR.SelectedIndex + 1 > 4 || Combo_RSR.SelectedIndex + 1 < 1 ) {
                return;
            }
            HRobot.ext_task_start( handle, 0, Combo_RSR.SelectedIndex + 1 );
        }

        private void button1_Click( object sender, EventArgs e ) {
            if ( Combo_PNS.SelectedIndex + 1 > 2047 || Combo_PNS.SelectedIndex + 1 < 1 ) {
                return;
            }
            HRobot.ext_task_start( handle, 1, Combo_PNS.SelectedIndex + 1 );
        }

        private void DataGrid_PR_CellContentClick( object sender, DataGridViewCellEventArgs e ) {

        }

        private void IO_Timer_Tick( object sender, EventArgs e ) {
            for ( int a = 1; a <= 48; a++ ) {
                if ( !this.DataGrid_DI.Rows[a - 1].Cells["Value"].Selected ) {
                    DelegateSetDataGridValue d = new DelegateSetDataGridValue( SetDataGridValue );
                    this.Invoke( d, new object[] { DataGrid_DI, a - 1, "Value", HRobot.get_digital_input( handle, a ) } );
                }
            }

            for ( int a = 1; a <= 48; a++ ) {
                if ( !this.DataGrid_DO.Rows[a - 1].Cells["Value"].Selected ) {
                    DelegateSetDataGridValue d = new DelegateSetDataGridValue( SetDataGridValue );
                    this.Invoke( d, new object[] { DataGrid_DO, a - 1, "Value", HRobot.get_digital_output( handle, a ) } );
                }
            }

            for ( int a = 1; a <= 8; a++ ) {
                if ( !this.DataGrid_FI.Rows[a - 1].Cells["Value"].Selected ) {
                    DelegateSetDataGridValue d = new DelegateSetDataGridValue( SetDataGridValue );
                    this.Invoke( d, new object[] { DataGrid_FI, a - 1, "Value", HRobot.get_function_input( handle, a ) } );
                }
            }

            for ( int a = 1; a <= 8; a++ ) {
                if ( !this.DataGrid_FO.Rows[a - 1].Cells["Value"].Selected ) {
                    DelegateSetDataGridValue d = new DelegateSetDataGridValue( SetDataGridValue );
                    this.Invoke( d, new object[] { DataGrid_FO, a - 1, "Value", HRobot.get_function_output( handle, a ) } );
                }
            }

            for ( int a = 1; a <= 8; a++ ) {
                if ( !this.DataGrid_RI.Rows[a - 1].Cells["Value"].Selected ) {
                    DelegateSetDataGridValue d = new DelegateSetDataGridValue( SetDataGridValue );
                    this.Invoke( d, new object[] { DataGrid_RI, a - 1, "Value", HRobot.get_robot_input( handle, a ) } );
                }
            }

            for ( int a = 1; a <= 8; a++ ) {
                if ( !this.DataGrid_RO.Rows[a - 1].Cells["Value"].Selected ) {
                    DelegateSetDataGridValue d = new DelegateSetDataGridValue( SetDataGridValue );
                    this.Invoke( d, new object[] { DataGrid_RO, a - 1, "Value", HRobot.get_robot_output( handle, a ) } );
                }
            }
            for ( int a = 1; a <= 3; a++ ) {
                if ( !this.DataGrid_VO.Rows[a - 1].Cells["Value"].Selected ) {
                    DelegateSetDataGridValue d = new DelegateSetDataGridValue( SetDataGridValue );
                    this.Invoke( d, new object[] { DataGrid_VO, a - 1, "Value", HRobot.get_valve_output( handle, a ) } );
                }
            }
        }

        private void DO_CellValueChanged( object sender, DataGridViewCellEventArgs e ) {
            if ( DataGrid_DO.CurrentCell == null )
                return;
            DataGridViewCell DataGridCell_DO = DataGrid_DO.CurrentCell;
            if ( ValidaCell( DataGrid_DO, DataGridCell_DO ) ) {

                HRobot.set_digital_output( handle, DataGrid_DO.CurrentRow.Index + 1, Convert.ToBoolean( Convert.ToInt16( DataGrid_DO.CurrentCell.Value ) ) );

            }
            DataGrid_DO.Refresh();
        }

        private void RO_CellValueChanged( object sender, DataGridViewCellEventArgs e ) {
            if ( DataGrid_RO.CurrentCell == null )
                return;
            DataGridViewCell DataGridCell_RO = DataGrid_RO.CurrentCell;
            if ( ValidaCell( DataGrid_RO, DataGridCell_RO ) ) {
                HRobot.set_robot_output( handle, DataGrid_RO.CurrentRow.Index + 1, Convert.ToBoolean( Convert.ToInt16( DataGrid_RO.CurrentCell.Value ) ) );

            }
            DataGrid_RO.Refresh();
        }

        private void VO_CellValueChanged( object sender, DataGridViewCellEventArgs e ) {
            if ( DataGrid_VO.CurrentCell == null )
                return;
            DataGridViewCell DataGridCell_VO = DataGrid_VO.CurrentCell;
            if ( ValidaCell( DataGrid_VO, DataGridCell_VO ) ) {
                HRobot.set_valve_output( handle, DataGrid_VO.CurrentRow.Index + 1, Convert.ToBoolean( Convert.ToInt16( DataGrid_VO.CurrentCell.Value ) ) );

            }
            DataGrid_VO.Refresh();
        }

        private void Bnt_Home_KeyDown( object sender, MouseEventArgs e ) {
            if ( HRobot.get_operation_mode( handle ) == 0 && HRobot.get_connection_level( handle ) == 0 ) {
                return;
            }

            double[] home = new double[6] { 0, 0, 0, 0, -90, 0 };
            HRobot.ptp_axis( handle, 0, home );
        }

        private void Bnt_Home_KeyUp( object sender, MouseEventArgs e ) {
            HRobot.motion_abort( handle );
        }

        private void Joint_Timer_Tick( object sender, EventArgs e ) {
            HRobot.get_current_joint( handle, JointDegree );
            for ( int a = 6; a < 6 + 6; a++ ) {
                this.DataGrid_Pos.Rows[a].Cells["value"].Value = JointDegree[a - 6];
            }
        }

        private void UI_infoUpdate_Tick( object sender, EventArgs e ) {
            for ( int a = 1; a <= 20; a++ ) {

                this.DataGrid_Timer.Rows[a - 1].Cells["value"].Value = Robot_Timer[a - 1];
            }

            for ( int a = 1; a <= 20; a++ ) {
                this.DataGrid_Counter.Rows[a - 1].Cells["value"].Value = Robot_Counter[a - 1];
            }
            for ( int a = 1; a <= 100; a++ ) {
                this.DataGrid_PR.Rows[a - 1].Cells["TYPE"].Value = Robot_Pr_type[a - 1];
                this.DataGrid_PR.Rows[a - 1].Cells["tool"].Value = Robot_Pr_tool[a - 1];
                this.DataGrid_PR.Rows[a - 1].Cells["base"].Value = Robot_Pr_base[a - 1];
                this.DataGrid_PR.Rows[a - 1].Cells["data"].Value = "{" + Robot_Pr_coor[a - 1, 0] + "," + Robot_Pr_coor[a - 1, 1] + "," + Robot_Pr_coor[a - 1, 2] + "," + Robot_Pr_coor[a - 1, 3] + "," + Robot_Pr_coor[a - 1, 4] + "," + Robot_Pr_coor[a - 1, 5] + "}";
            }
        }

        private void Bar_Lin_Click( object sender, EventArgs e ) {

        }

        private void JogPositive1_Click( object sender, EventArgs e ) {

        }

        private void Bnt_SetRobotId_Click( object sender, EventArgs e ) {
            StringBuilder RobotID = new StringBuilder( TextBox_RobotID.Text );
            HRobot.set_robot_id( handle, RobotID );
        }

        private void Btn_UpdateHRSS_Click( object sender, EventArgs e ) {
            if ( openFileDialogUpdateFile.ShowDialog() == System.Windows.Forms.DialogResult.OK ) {
                if ( MessageBox.Show( "Update " + TextBox_RobotID.Text, "",
                                      MessageBoxButtons.YesNo, MessageBoxIcon.Question,
                                      MessageBoxDefaultButton.Button1 ) == System.Windows.Forms.DialogResult.Yes ) {
                    StringBuilder sb = new StringBuilder( openFileDialogUpdateFile.FileName );
                    int result = HRobot.update_hrss( handle, sb );
                    if ( result != 0 ) {
                        MessageBox.Show( "Update fail. " + result );
                    }

                }
            }
        }

        private void Radio_monitor_CheckedChanged( object sender, EventArgs e ) {
            HRobot.set_connection_level( handle, 0 );
        }

        private void Radio_controller_CheckedChanged( object sender, EventArgs e ) {
            HRobot.set_connection_level( handle, 1 );
        }
    }

    public static class Extension {
        public static List<double> Numbers( this string str ) {
            var nums = new List<double>();
            var start = -1;
            for ( int i = 0; i < str.Length; i++ ) {
                if ( start < 0 && Char.IsDigit( str[i] ) || str[i] == '-' ) {
                    start = i;
                } else if ( start >= 0 && !Char.IsNumber( str[i] ) ) {
                    nums.Add( double.Parse( str.Substring( start, i - start ) ) );
                    start = -1;
                }
            }
            if ( start >= 0 )
                nums.Add( double.Parse( str.Substring( start, str.Length - start ) ) );
            return nums;
        }
    }
    public class ComboboxItem {
        public string Text {
            get;
            set;
        }
        public object Value {
            get;
            set;
        }

        public override string ToString() {
            return Text;
        }
    }
}
