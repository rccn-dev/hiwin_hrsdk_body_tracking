﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SharpGL;
using System.IO;
namespace WindowsFormsApplication1 {


    class RobotGl {
        enum stl_No {
            RA605_1 = 1,
            RA605_2 = 2,
            RA605_3 = 3,
            RA605_4 = 4,
            RA605_5 = 5,
            RA605_6 = 6,
            RA605_7 = 7,

            RD401_1 = 8,
            RD401_2 = 9,
            RD401_3 = 10,
            RD401_4 = 11,

        }
        public struct STriangle {
            public float[] n;
            public float[] a;
            public float[] b;
            public float[] c;
        }

        public static void BuildList() {
            FileStream sr = new FileStream( @"stl/RA605_0.stl", FileMode.Open, FileAccess.Read );
            DrawObj( 0.0f, 0.0f, 0.0f, ( int )stl_No.RA605_1, sr );
            sr = new FileStream( @"stl/RA605_1.stl", FileMode.Open, FileAccess.Read );
            DrawObj( 0.0f, 0.0f, 0.0f, ( int )stl_No.RA605_2, sr );
            sr = new FileStream( @"stl/RA605_2.stl", FileMode.Open, FileAccess.Read );
            DrawObj( 0.0f, 0.0f, 0.0f, ( int )stl_No.RA605_3, sr );
            sr = new FileStream( @"stl/RA605_3.stl", FileMode.Open, FileAccess.Read );
            DrawObj( 0.0f, 0.0f, 0.0f, ( int )stl_No.RA605_4, sr );
            sr = new FileStream( @"stl/RA605_4.stl", FileMode.Open, FileAccess.Read );
            DrawObj( 0.0f, 0.0f, 0.0f, ( int )stl_No.RA605_5, sr );
            sr = new FileStream( @"stl/RA605_5.stl", FileMode.Open, FileAccess.Read );
            DrawObj( 0.0f, 0.0f, 0.0f, ( int )stl_No.RA605_6, sr );
            sr = new FileStream( @"stl/RA605_6.stl", FileMode.Open, FileAccess.Read );
            DrawObj( 0.0f, 0.0f, 0.0f, ( int )stl_No.RA605_7, sr );
            sr = new FileStream( @"stl/rd401_long_1.stl", FileMode.Open, FileAccess.Read );
            DrawObj( 0.0f, 0.0f, 0.0f, ( int )stl_No.RD401_1, sr );
            sr = new FileStream( @"stl/rd401_long_2.stl", FileMode.Open, FileAccess.Read );
            DrawObj( 0.0f, 0.0f, 0.0f, ( int )stl_No.RD401_2, sr );
            sr = new FileStream( @"stl/rd401_long_3.stl", FileMode.Open, FileAccess.Read );
            DrawObj( 0.0f, 0.0f, 0.0f, ( int )stl_No.RD401_3, sr );
            sr = new FileStream( @"stl/rd401_long_4.stl", FileMode.Open, FileAccess.Read );
            DrawObj( 0.0f, 0.0f, 0.0f, ( int )stl_No.RD401_4, sr );
        }

        private static void DrawObj( float xPos, float yPos, float zPos, int idx, FileStream fileName ) {

            OpenGL gl = Global.Instance.openGLControl.OpenGL;

            gl.NewList( Convert.ToUInt32( idx ), OpenGL.GL_COMPILE_AND_EXECUTE );
            gl.PushMatrix();
            gl.Translate( xPos, yPos, zPos );
            int nTriangle = 0;
            STriangle[] triArray;
            triArray = LoadStlBinary( fileName, ref nTriangle );
            if ( nTriangle > 0 ) {
                gl.Begin( OpenGL.GL_TRIANGLES );
                for ( int i = 0; i < nTriangle; i++ ) {
                    gl.Normal( triArray[i].n[0], triArray[i].n[1], triArray[i].n[2] );
                    gl.Vertex( triArray[i].a[0], triArray[i].a[1], triArray[i].a[2] );
                    gl.Vertex( triArray[i].b[0], triArray[i].b[1], triArray[i].b[2] );
                    gl.Vertex( triArray[i].c[0], triArray[i].c[1], triArray[i].c[2] );
                }
                gl.End();
            }
            gl.PopMatrix();
            gl.EndList();

        }

        public static void light() {
            OpenGL gl = Global.Instance.openGLControl.OpenGL;
            // setup lighting
            //===================================================

            float[] gAmbient = new float[4] {0.5f, 0.5f, 0.5f, 0.0f};
            gl.LightModel( OpenGL.GL_LIGHT_MODEL_AMBIENT, gAmbient );

            float[] glfLightDiffuse = new float[4] { 0.0007f, 0.0007f, 0.0007f, 0.0f };
            float[] glfLightPosition = new float[4] {100, 20, 100, 0.0f };

            gl.PushMatrix();
            // Add a light to the scene.   //
            //gl.Light(OpenGL.GL_LIGHT0,OpenGL.GL_AMBIENT,glfLightAmbient);
            gl.Light( OpenGL.GL_LIGHT0, OpenGL.GL_DIFFUSE, glfLightDiffuse );
            gl.Light( OpenGL.GL_LIGHT0, OpenGL.GL_POSITION, glfLightPosition );
            gl.Enable( OpenGL.GL_LIGHTING );
            gl.Enable( OpenGL.GL_LIGHT0 );

            float[] glfLightDiffuse1 = new float[4] { 0.0007f, 0.0007f, 0.0007f, 0.0f };
            float[] glfLightPosition1 = new float[4] { -100, 80, 100, 0.0f };

            // Add a light to the scene.   //
            gl.Light( OpenGL.GL_LIGHT1, OpenGL.GL_DIFFUSE, glfLightDiffuse1 );
            gl.Light( OpenGL.GL_LIGHT1, OpenGL.GL_POSITION, glfLightPosition1 );
            gl.Enable( OpenGL.GL_LIGHTING );
            gl.Enable( OpenGL.GL_LIGHT1 );
            //
            // // light3
            float[] glfLightDiffuse2 = new float[4] { 0.0007f, 0.0007f, 0.0007f, 0.0f };
            float[] glfLightPosition2 = new float[4] { 0, 0, -500, 0.0f };

            // Add a light to the scene.   //
            gl.Light( OpenGL.GL_LIGHT2, OpenGL.GL_DIFFUSE, glfLightDiffuse2 );
            gl.Light( OpenGL.GL_LIGHT2, OpenGL.GL_POSITION, glfLightPosition2 );
            //gl.Enable(OpenGL.GL_LIGHTING);
            //gl.Enable(OpenGL.GL_LIGHT2);
            gl.PopMatrix();
        }

        public static void floor() {
            OpenGL gl = Global.Instance.openGLControl.OpenGL;
            //-- 地板
            //
            //if (m_xRotate >= -10 && m_xRotate <= 180)
            //{

            //畫面縮放大小
            gl.Scale( 0.7, 0.7, 0.7 );

            //製作地板
            gl.PushMatrix();
            gl.Color( 90.0f / 255.0f, 90.0f / 255.0f, 90.0f / 255.0f );
            gl.Begin( OpenGL.GL_QUADS );

            //gl.TexCoord( 0.0f, 0.0f );
            gl.Vertex( -10.0f, 10.0f, -0.5f );

            //gl.TexCoord( 0.0f, 0.0f );
            gl.Vertex( 10.0f, 10.0f, -0.5f );

            //gl.TexCoord( 1.0f, 1.0f );
            gl.Vertex( 10.0f, -10.0f, -0.5f );

            //gl.TexCoord( 0.0f, 1.0f );
            gl.Vertex( -10.0f, -10.0f, -0.5f );
            gl.End();
            gl.PopMatrix();

            //畫線條
            gl.PushMatrix();
            {
                // NOLINT
                //線條顏色
                gl.Color( 0.7, 0.7, 0.7 );
                //線寬度
                gl.LineWidth( 0.01f );

                //垂直線
                gl.Begin( OpenGL.GL_LINES );
                for ( int i = 0; i < 80; i++ ) {
                    gl.Vertex( -10.0f, 10.0f - 0.25 * i, -0.5f );
                    gl.Vertex( 10.0f, 10.0f - 0.25 * i, -0.5f );
                }
                gl.End();

                //水平線
                gl.Begin( OpenGL.GL_LINES );
                for ( int i = 0; i < 80; i++ ) {
                    gl.Vertex( -10.0f + 0.25 * i, 10.0f, -0.5f );
                    gl.Vertex( -10.0f + 0.25 * i, -10.0f, -0.5f );
                }
                gl.End();
            }
            gl.PopMatrix();

            //}
        }

        public static void RA605( double[] CurJointDegree, float[] DH_table ) {
            OpenGL gl = Global.Instance.openGLControl.OpenGL;

            gl.Scale( 0.001, 0.001, 0.001 );

            // Joint 1
            gl.PushMatrix();
            gl.CallList( ( int )stl_No.RA605_1 );
            gl.PopMatrix();

            // Joint 2
            gl.Color( 0.5f, 0.5f, 0.5f );
            gl.Rotate( CurJointDegree[0], 0.0f, 0.0f, 1.0f );
            gl.PushMatrix();

            gl.CallList( ( int )stl_No.RA605_2 );
            gl.PopMatrix();

            // Joint 2
            gl.Translate( -DH_table[0], 0.0f, 0.0f );
            gl.Rotate( CurJointDegree[1], 1.0f, 0.0f, 0.0f );
            gl.Translate( DH_table[0], 0.0f, 0.0f );
            gl.PushMatrix();
            gl.CallList( ( int )stl_No.RA605_3 );
            gl.PopMatrix();

            // Joint 3
            gl.Translate( DH_table[0], 0, DH_table[1] );
            gl.Rotate( CurJointDegree[2], 1.0f, 0.0f, 0.0f );
            gl.Translate( -DH_table[0], 0, -DH_table[1] );
            gl.PushMatrix();
            gl.CallList( ( int )stl_No.RA605_4 );
            gl.PopMatrix();

            // Joint 4
            gl.Translate( 0.0f, DH_table[0], ( DH_table[1] + DH_table[2] ) );
            gl.Rotate( CurJointDegree[3], 0.0f, 1.0f, 0.0f );
            gl.Translate( 0.0f, -DH_table[0], -( DH_table[1] + DH_table[2] ) );
            gl.Color( 0.5, 0.5, 0.5 );
            gl.PushMatrix();
            gl.CallList( ( int )stl_No.RA605_5 );
            gl.PopMatrix();

            // Joint 5
            gl.Translate( 0.0f, ( DH_table[0] + DH_table[3] ), ( DH_table[1] + DH_table[2] ) );
            gl.Rotate( CurJointDegree[4], 1.0f, 0.0f, 0.0f );
            gl.Translate( 0.0f, -( DH_table[0] + DH_table[3] ), -( DH_table[1] + DH_table[2] ) );
            gl.PushMatrix();
            gl.CallList( ( int )stl_No.RA605_6 );
            gl.PopMatrix();

            // Joint 6
            gl.Translate( 0, ( DH_table[0] + DH_table[4] ), ( DH_table[1] + DH_table[2] ) );
            gl.Rotate( CurJointDegree[5], 0.0f, 1.0f, 0.0f );
            gl.Translate( 0.0f, -( DH_table[0] + DH_table[4] ), -( DH_table[1] + DH_table[2] ) );
            gl.PushMatrix();
            gl.CallList( ( int )stl_No.RA605_7 );
            gl.PopMatrix();
        }
        const double PI = 3.1415926535897932384626433;
        const double R2D = 180.0 / PI;
        const double D2R = PI / 180.0;
        public static void RD401_long( double[] CurJointDegree, float[] DH_table ) {
            double R = DH_table[0];
            double r = DH_table[1];
            double Lb = DH_table[2];
            double La = DH_table[3];
            double t1;
            double t2;
            double x1, x2, x3, y2, y3, w1, w2, w3, a1, b1, a2, b2, a, b, c, X, Y, Z, z1, z2, z3;
            double ux, uy, vx, vy;
            x1 = R - r + La * Math.Cos( CurJointDegree[0] * D2R );
            x2 = ( R - r + La * Math.Cos( CurJointDegree[1] * D2R ) ) * Math.Cos( 120.0 * D2R );
            x3 = ( R - r + La * Math.Cos( CurJointDegree[2] * D2R ) ) * Math.Cos( 240.0 * D2R );

            y2 = ( R - r + La * Math.Cos( CurJointDegree[1] * D2R ) ) * Math.Sin( 120.0 * D2R );
            y3 = ( R - r + La * Math.Cos( CurJointDegree[2] * D2R ) ) * Math.Sin( 240.0 * D2R );

            z1 = -La * Math.Sin( CurJointDegree[0] * D2R );
            z2 = -La * Math.Sin( CurJointDegree[1] * D2R );
            z3 = -La * Math.Sin( CurJointDegree[2] * D2R );

            w1 = x1 * x1 + z1 * z1;
            w2 = x2 * x2 + y2 * y2 + z2 * z2;
            w3 = x3 * x3 + y3 * y3 + z3 * z3;

            a1 = ( ( z3 - z1 ) * ( x2 - x1 ) - ( z2 - z1 ) * ( x3 - x1 ) ) / ( ( x3 - x1 ) * y2 - ( x2 - x1 ) * y3 );
            b1 = ( ( w2 - w1 ) * ( x3 - x1 ) - ( w3 - w1 ) * ( x2 - x1 ) ) / ( 2.0 * ( ( x3 - x1 ) * y2 - ( x2 - x1 ) * y3 ) );

            a2 = ( ( z3 - z1 ) * y2 - ( z2 - z1 ) * y3 ) / ( ( x2 - x1 ) * y3 - ( x3 - x1 ) * y2 );
            b2 = ( ( w2 - w1 ) * y3 - ( w3 - w1 ) * y2 ) / ( 2.0 * ( ( x2 - x1 ) * y3 - ( x3 - x1 ) * y2 ) );

            a = a1 * a1 + a2 * a2 + 1;
            b = 2.0 * a2 * ( b2 - x1 ) + 2.0 * a1 * b1 - 2.0 * z1;
            c = ( b2 - x1 ) * ( b2 - x1 ) + b1 * b1 + z1 * z1 - Lb * Lb;

            Z = ( -b - Math.Sqrt( b * b - 4.0 * a * c ) ) / ( 2.0 * a ); //+ -
            X = a2 * Z + b2;
            Y = a1 * Z + b1;

            ux = Math.Cos( CurJointDegree[3] * D2R );
            uy = Math.Sin( CurJointDegree[3] * D2R );
            vx = -Math.Sin( CurJointDegree[3] * D2R );
            vy = Math.Cos( CurJointDegree[3] * D2R );

            double globalX = X * Math.Cos( 30.0 * D2R ) + Y * Math.Sin( 30.0 * D2R );
            double globalY = X * ( -Math.Sin( 30.0 * D2R ) ) + Y * Math.Cos( 30.0 * D2R );
            double globalZ = Z;



            OpenGL gl = Global.Instance.openGLControl.OpenGL;
            gl.Rotate( 145, 0, 0, 1 );

            gl.Scale( 0.001, 0.001, 0.001 );
            gl.Translate( 0.0f, 0.0, 400.0 );
            // Delta Base
            gl.Color( 0.5f, 0.5f, 0.5f );
            gl.Rotate( 90, 1, 0, 0 );

            gl.PushMatrix();
            {

                // --0400 d1
                //--------------------------------------------------------------
                gl.PushMatrix();
                {

                    gl.Translate( 0.0f, -550.0f, 0.0f );
                    gl.Rotate( -90, 1, 0, 0 );
                    gl.Rotate( 330, 0, 0, 1 );

                    gl.CallList( ( int )stl_No.RD401_1 );
                }
                gl.PopMatrix();



                gl.PushMatrix();
                {

                    gl.Rotate( -30, 0, 1, 0 );
                    gl.Translate( R, 0.0, 0.0 );
                    gl.Rotate( -CurJointDegree[0] + Math.Atan( 31.0 / 300.0 )*R2D, 0, 0, 1 );
                    gl.Translate( 408.0, -124.0, 540.0 );
                    gl.Rotate( 90, 0, 0, 1 );
                    gl.Rotate( 180, 0, 1, 0 );

                    gl.CallList( ( int )stl_No.RD401_2 );
                }
                gl.PopMatrix();

                gl.PushMatrix();
                {

                    gl.Rotate( -30, 0, 1, 0 );
                    gl.Translate( ( R + La * Math.Cos( CurJointDegree[0] * D2R ) ), ( -La * Math.Sin( CurJointDegree[0] * D2R ) ), -50.0 );
                    gl.Rotate( -Math.Atan( ( x1 - X - r + 45 ) / ( z1 - Z ) )*R2D, 0, 0, 1 );
                    gl.Rotate( Math.Sin( ( Y ) / ( Lb ) )*R2D, 1, 0, 0 );
                    gl.Rotate( 180, 0, 0, 1 );

                    gl.CallList( ( int )stl_No.RD401_3 );
                }
                gl.PopMatrix();

                gl.PushMatrix();
                {

                    gl.Rotate( -30, 0, 1, 0 );
                    gl.Translate( ( R + La * Math.Cos( CurJointDegree[0] * D2R ) ), ( -La * Math.Sin( CurJointDegree[0] * D2R ) ), 50.0 );
                    //gl.Rotate(-Math.Atan((x1 - X - 55.0 ) / (z1 - Z))*R2D, 0, 0, 1);
                    gl.Rotate( -Math.Atan( ( x1 - X - 10.0 ) / ( z1 - Z ) ) * R2D, 0, 0, 1 );
                    gl.Rotate( Math.Sin( ( Y ) / ( Lb ) )*R2D, 1, 0, 0 );
                    gl.Rotate( 180, 0, 1, 0 );
                    gl.Rotate( 180, 0, 0, 1 );

                    gl.CallList( ( int )stl_No.RD401_3 );
                }
                gl.PopMatrix();
                // --1200 d2

                gl.PushMatrix();
                {

                    gl.Rotate( 120, 0, 1, 0 );
                    gl.Rotate( -30, 0, 1, 0 );
                    gl.Translate( R, 0.0, 0.0 );
                    gl.Rotate( -CurJointDegree[1] + Math.Atan( 31.0 / 300.0 )*R2D, 0, 0, 1 );
                    gl.Translate( 408.0, -124.0, 540.0 );
                    gl.Rotate( 90, 0, 0, 1 );
                    gl.Rotate( 180, 0, 1, 0 );

                    gl.CallList( ( int )stl_No.RD401_2 );
                }
                gl.PopMatrix();

                gl.PushMatrix();
                {

                    gl.Rotate( 120, 0, 1, 0 );
                    gl.Rotate( -30, 0, 1, 0 );
                    gl.Translate( ( R + La * Math.Cos( CurJointDegree[1] * D2R ) ), ( -La * Math.Sin( CurJointDegree[1] * D2R ) ), -50.0 );
                    t1 = X - x2;
                    t2 = Y - y2;

                    gl.Rotate( -Math.Atan( ( t1 * Math.Cos( 60.0 * D2R ) - t2 * Math.Sin( 60.0 * D2R ) ) / ( z2 - Z ) )*R2D, 0, 0, 1 );
                    gl.Rotate( Math.Sin( ( -t1 * Math.Cos( 30.0 * D2R ) - t2 * Math.Cos( 60.0 * D2R ) ) / Lb )*R2D, 1, 0, 0 );
                    gl.Rotate( 180, 0, 0, 1 );

                    gl.CallList( ( int )stl_No.RD401_3 );
                }
                gl.PopMatrix();

                gl.PushMatrix();
                {

                    gl.Rotate( 120, 0, 1, 0 );
                    gl.Rotate( -30, 0, 1, 0 );
                    gl.Translate( ( R + La * Math.Cos( CurJointDegree[1] * D2R ) ), ( -La * Math.Sin( CurJointDegree[1] * D2R ) ), 50.0 );
                    t1 = X - x2;
                    t2 = Y - y2;
                    gl.Rotate( -Math.Atan( ( t1 * Math.Cos( 60.0 * D2R ) - t2 * Math.Sin( 60.0 * D2R ) ) / ( z2 - Z ) )*R2D, 0, 0, 1 );

                    gl.Rotate( Math.Sin( ( -t1 * Math.Cos( 30.0 * D2R ) - t2 * Math.Cos( 60.0 * D2R ) ) / Lb )*R2D, 1, 0, 0 );
                    gl.Rotate( 180, 0, 1, 0 );
                    gl.Rotate( 180, 0, 0, 1 );

                    gl.CallList( ( int )stl_No.RD401_3 );
                }
                gl.PopMatrix();
                // --0800 d3

                gl.PushMatrix();
                {

                    gl.Rotate( 240, 0, 1, 0 );
                    gl.Rotate( -30, 0, 1, 0 );
                    gl.Translate( R, 0.0, 0.0 );
                    gl.Rotate( -CurJointDegree[2] + Math.Atan( 31.0 / 300.0 ) * R2D, 0, 0, 1 );
                    gl.Translate( 408.0, -124.0, 540.0 );
                    gl.Rotate( 90, 0, 0, 1 );
                    gl.Rotate( 180, 0, 1, 0 );

                    gl.CallList( ( int )stl_No.RD401_2 );
                }
                gl.PopMatrix();

                gl.PushMatrix();
                {

                    gl.Rotate( 240, 0, 1, 0 );
                    gl.Rotate( -30, 0, 1, 0 );
                    gl.Translate( ( R + La * Math.Cos( CurJointDegree[2] * D2R ) ), ( -La * Math.Sin( CurJointDegree[2] * D2R ) ), -50.0 );

                    t1 = x3 - X;
                    t2 = y3 - Y;
                    gl.Rotate( Math.Atan( ( t1 * Math.Cos( 60.0 * D2R ) + t2 * Math.Cos( 30.0 * D2R ) ) / ( z3 - Z ) )*R2D, 0, 0, 1 );
                    gl.Rotate( Math.Sin( ( -t1 * Math.Sin( 60.0 * D2R ) + t2 * Math.Cos( 60.0 * D2R ) ) / Lb )*R2D, 1, 0, 0 );
                    gl.Rotate( 180, 0, 0, 1 );

                    gl.CallList( ( int )stl_No.RD401_3 );
                }
                gl.PopMatrix();

                gl.PushMatrix();
                {

                    gl.Rotate( 240, 0, 1, 0 );
                    gl.Rotate( -30, 0, 1, 0 );
                    gl.Translate( ( R + La * Math.Cos( CurJointDegree[2] * D2R ) ), ( -La * Math.Sin( CurJointDegree[2] * D2R ) ), 50.0 );
                    t1 = x3 - X;
                    t2 = y3 - Y;
                    gl.Rotate( Math.Atan( ( t1 * Math.Cos( 60.0 * D2R ) + t2 * Math.Cos( 30.0 * D2R ) ) / ( z3 - Z ) )*R2D, 0, 0, 1 );
                    gl.Rotate( Math.Sin( ( -t1 * Math.Sin( 60.0 * D2R ) + t2 * Math.Cos( 60.0 * D2R ) ) / Lb )*R2D, 1, 0, 0 );

                    gl.Rotate( 180, 0, 1, 0 );
                    gl.Rotate( 180, 0, 0, 1 );

                    gl.CallList( ( int )stl_No.RD401_3 );
                }
                gl.PopMatrix();
                //// --motor
                ////---------------------------------------------------------------------------
                gl.PushMatrix();
                {
                    gl.Translate( globalX, ( globalZ - 40.0 ), -1.0 * globalY ); // 正向運動學X Y Z
                    gl.Rotate( 60.0, 0, 1, 0 );
                    gl.Rotate( -90, 0, 1, 0 );
                    gl.Rotate( -90, 1, 0, 0 );
                    gl.CallList( ( int )stl_No.RD401_4 );
                }
                gl.PopMatrix();

            }
        }

        private static STriangle[] LoadStlBinary( FileStream fileName, ref int nTriangles ) {
            STriangle[] triArray;

            try {

                byte[] tmpBuff = new byte[80];
                // read Header
                if ( fileName.Read( tmpBuff, 0, 80 ) == 0 ) {
                    throw new Exception( "header 錯誤" );
                }

                // how many triangles ?
                byte[] triangleS = new byte[4];
                //int rlt=fileName.Read(triangleS, 0, 4); // unsigned long, must be 4 bytes
                if ( fileName.Read( triangleS, 0, 4 ) == 0 ) {
                    throw new Exception( "格式不合(三角網格數錯誤)" );
                }
                byte[] btmp = new  byte[4];
                for( int a = 0; a < 4; a++ ) {
                    btmp[a] = Convert.ToByte( triangleS[a] );
                }
                nTriangles = BitConverter.ToInt32( btmp, 0 );


                // allocate array memory
                if ( nTriangles > 0 ) {
                    triArray = new STriangle[nTriangles];
                    for ( int a = 0; a < nTriangles; a++ ) {
                        triArray[a].a = new float[3];
                        triArray[a].b = new float[3];
                        triArray[a].c = new float[3];
                        triArray[a].n = new float[3];
                    }
                    for ( int i = 0; i < nTriangles; i++ ) {
                        char[] triBuffer = new char[80];
                        byte[] tri4 = new byte[50];
                        fileName.Read( tri4, 0, 50 );

                        triArray[i].a[0] = BitConverter.ToSingle( tri4, 12 );
                        triArray[i].a[1] = BitConverter.ToSingle( tri4, 16 );
                        triArray[i].a[2] = BitConverter.ToSingle( tri4, 20 );

                        triArray[i].b[0] = BitConverter.ToSingle( tri4, 24 );
                        triArray[i].b[1] = BitConverter.ToSingle( tri4, 28 );
                        triArray[i].b[2] = BitConverter.ToSingle( tri4, 32 );

                        triArray[i].c[0] = BitConverter.ToSingle( tri4, 36 );
                        triArray[i].c[1] = BitConverter.ToSingle( tri4, 40 );
                        triArray[i].c[2] = BitConverter.ToSingle( tri4, 44 );

                        // re-compute normal
                        float[] vb = new float[3] { triArray[i].b[0] - triArray[i].a[0], triArray[i].b[1] - triArray[i].a[1], triArray[i].b[2] - triArray[i].a[2] };
                        float[] vc = new float[3] { triArray[i].c[0] - triArray[i].a[0], triArray[i].c[1] - triArray[i].a[1], triArray[i].c[2] - triArray[i].a[2] };
                        float[] normal = new float[3] { vb[1] * vc[2] - vb[2] * vc[1], vb[2] * vc[0] - vb[0] * vc[2], vb[0] * vc[1] - vb[1] * vc[0] };
                        double len = Math.Sqrt( normal[0] * normal[0] + normal[1] * normal[1] + normal[2] * normal[2] );
                        if ( len > 0 ) {
                            normal[0] /= ( float )len;
                            normal[1] /= ( float )len;
                            normal[2] /= ( float )len;
                        }
                        triArray[i].n[0] = normal[0];
                        triArray[i].n[1] = normal[1];
                        triArray[i].n[2] = normal[2];

                    }
                    fileName.Close();
                    return triArray;
                }
            } catch ( Exception e ) {
                Console.WriteLine( e.Message.ToString() );
                nTriangles = 0;
                STriangle tmp = new STriangle();
                STriangle[] tmpList = new STriangle[1];
                tmpList[0] = tmp;
                return tmpList;
            }
            STriangle t = new STriangle();
            STriangle[] tList = new STriangle[1];
            tList[0] = t;
            return tList;
        }
    }
}