﻿namespace WindowsFormsApplication1 {
    partial class DeviceTabControll {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose( bool disposing ) {
            if ( disposing && ( components != null ) ) {
                components.Dispose();
            }
            base.Dispose( disposing );
        }

        #region 元件設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            this.Bnt_SafetyState = new System.Windows.Forms.Button();
            this.Bnt_Clean = new System.Windows.Forms.Button();
            this.Panel_ErrorInfo = new System.Windows.Forms.Panel();
            this.TextBox_ErrorInfo = new System.Windows.Forms.TextBox();
            this.Tab_RobotInfo = new System.Windows.Forms.TabControl();
            this.Tab_Pos = new System.Windows.Forms.TabPage();
            this.DataGrid_Pos = new System.Windows.Forms.DataGridView();
            this.Tab_Timer = new System.Windows.Forms.TabPage();
            this.DataGrid_Timer = new System.Windows.Forms.DataGridView();
            this.Tab_Counter = new System.Windows.Forms.TabPage();
            this.DataGrid_Counter = new System.Windows.Forms.DataGridView();
            this.Tab_PR = new System.Windows.Forms.TabPage();
            this.DataGrid_PR = new System.Windows.Forms.DataGridView();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.Bar_Acc = new System.Windows.Forms.ProgressBar();
            this.TextBox_Acc = new System.Windows.Forms.TextBox();
            this.Bnt_AccDown = new System.Windows.Forms.Button();
            this.Bnt_AccUp = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Bar_Ptp = new System.Windows.Forms.ProgressBar();
            this.TextBox_Ptp = new System.Windows.Forms.TextBox();
            this.Bnt_PtpUp = new System.Windows.Forms.Button();
            this.Bnt_PtpDown = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Bar_Lin = new System.Windows.Forms.ProgressBar();
            this.TextBox_Lin = new System.Windows.Forms.TextBox();
            this.Bnt_LinUp = new System.Windows.Forms.Button();
            this.Bnt_LinDown = new System.Windows.Forms.Button();
            this.groupBox_Override = new System.Windows.Forms.GroupBox();
            this.Bar_Override = new System.Windows.Forms.ProgressBar();
            this.TextBox_Override = new System.Windows.Forms.TextBox();
            this.Btn_OverrideUp = new System.Windows.Forms.Button();
            this.Btn_OverrideDown = new System.Windows.Forms.Button();
            this.Bnt_Home = new System.Windows.Forms.Button();
            this.But_Stop = new System.Windows.Forms.Button();
            this.Bnt_Pause = new System.Windows.Forms.Button();
            this.Bnt_Go = new System.Windows.Forms.Button();
            this.Panel_DeviceInfo = new System.Windows.Forms.Panel();
            this.Label_Utilization = new System.Windows.Forms.Label();
            this.Label_UtilizationRatio = new System.Windows.Forms.Label();
            this.Label_Birthday = new System.Windows.Forms.Label();
            this.Label_RobotType = new System.Windows.Forms.Label();
            this.Label_OperationTime = new System.Windows.Forms.Label();
            this.Label_HRSS_version = new System.Windows.Forms.Label();
            this.JogPanel = new System.Windows.Forms.Panel();
            this.JogPositive6 = new System.Windows.Forms.Button();
            this.JogNeg1 = new System.Windows.Forms.Button();
            this.JogNeg5 = new System.Windows.Forms.Button();
            this.JogPositive3 = new System.Windows.Forms.Button();
            this.JogNeg2 = new System.Windows.Forms.Button();
            this.JogPositive2 = new System.Windows.Forms.Button();
            this.JogNeg4 = new System.Windows.Forms.Button();
            this.JogPositive5 = new System.Windows.Forms.Button();
            this.JogNeg6 = new System.Windows.Forms.Button();
            this.JogPositive4 = new System.Windows.Forms.Button();
            this.JogNeg3 = new System.Windows.Forms.Button();
            this.JogPositive1 = new System.Windows.Forms.Button();
            this.Bnt_Servo = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Radio_controller = new System.Windows.Forms.RadioButton();
            this.Btn_UpdateHRSS = new System.Windows.Forms.Button();
            this.Radio_monitor = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.Bnt_RsrGo = new System.Windows.Forms.Button();
            this.Label_RobotID = new System.Windows.Forms.Label();
            this.Bnt_SetRobotId = new System.Windows.Forms.Button();
            this.TextBox_RobotID = new System.Windows.Forms.TextBox();
            this.TextBox_ProgramName = new System.Windows.Forms.TextBox();
            this.Tab_IO = new System.Windows.Forms.TabControl();
            this.TabPage_DI = new System.Windows.Forms.TabPage();
            this.DataGrid_DI = new System.Windows.Forms.DataGridView();
            this.TabPage_DO = new System.Windows.Forms.TabPage();
            this.DataGrid_DO = new System.Windows.Forms.DataGridView();
            this.TabPage_FI = new System.Windows.Forms.TabPage();
            this.DataGrid_FI = new System.Windows.Forms.DataGridView();
            this.TabPage_FO = new System.Windows.Forms.TabPage();
            this.DataGrid_FO = new System.Windows.Forms.DataGridView();
            this.TabPage_RI = new System.Windows.Forms.TabPage();
            this.DataGrid_RI = new System.Windows.Forms.DataGridView();
            this.TabPage_RO = new System.Windows.Forms.TabPage();
            this.DataGrid_RO = new System.Windows.Forms.DataGridView();
            this.TabPage_VO = new System.Windows.Forms.TabPage();
            this.DataGrid_VO = new System.Windows.Forms.DataGridView();
            this.Combo_PNS = new System.Windows.Forms.ComboBox();
            this.Combo_RSR = new System.Windows.Forms.ComboBox();
            this.TextBox_ConnectionLevel = new System.Windows.Forms.TextBox();
            this.Bnt_SetBase = new System.Windows.Forms.Button();
            this.Bnt_SetTool = new System.Windows.Forms.Button();
            this.Combo_Tool = new System.Windows.Forms.ComboBox();
            this.Combo_Base = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.ComboBox_JogType = new System.Windows.Forms.ComboBox();
            this.Label_Jog6 = new System.Windows.Forms.Label();
            this.Label_Jog5 = new System.Windows.Forms.Label();
            this.Label_Jog4 = new System.Windows.Forms.Label();
            this.Label_Jog3 = new System.Windows.Forms.Label();
            this.Label_Jog2 = new System.Windows.Forms.Label();
            this.Label_Jog1 = new System.Windows.Forms.Label();
            this.PosTimer = new System.Windows.Forms.Timer( this.components );
            this.ToolBase_Timer = new System.Windows.Forms.Timer( this.components );
            this.ConnectionLevel_timer = new System.Windows.Forms.Timer( this.components );
            this.Joint_Timer = new System.Windows.Forms.Timer( this.components );
            this.openFileDialogUpdateFile = new System.Windows.Forms.OpenFileDialog();
            this.Panel_ErrorInfo.SuspendLayout();
            this.Tab_RobotInfo.SuspendLayout();
            this.Tab_Pos.SuspendLayout();
            ( ( System.ComponentModel.ISupportInitialize )( this.DataGrid_Pos ) ).BeginInit();
            this.Tab_Timer.SuspendLayout();
            ( ( System.ComponentModel.ISupportInitialize )( this.DataGrid_Timer ) ).BeginInit();
            this.Tab_Counter.SuspendLayout();
            ( ( System.ComponentModel.ISupportInitialize )( this.DataGrid_Counter ) ).BeginInit();
            this.Tab_PR.SuspendLayout();
            ( ( System.ComponentModel.ISupportInitialize )( this.DataGrid_PR ) ).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox_Override.SuspendLayout();
            this.Panel_DeviceInfo.SuspendLayout();
            this.JogPanel.SuspendLayout();
            this.panel1.SuspendLayout();
            this.Tab_IO.SuspendLayout();
            this.TabPage_DI.SuspendLayout();
            ( ( System.ComponentModel.ISupportInitialize )( this.DataGrid_DI ) ).BeginInit();
            this.TabPage_DO.SuspendLayout();
            ( ( System.ComponentModel.ISupportInitialize )( this.DataGrid_DO ) ).BeginInit();
            this.TabPage_FI.SuspendLayout();
            ( ( System.ComponentModel.ISupportInitialize )( this.DataGrid_FI ) ).BeginInit();
            this.TabPage_FO.SuspendLayout();
            ( ( System.ComponentModel.ISupportInitialize )( this.DataGrid_FO ) ).BeginInit();
            this.TabPage_RI.SuspendLayout();
            ( ( System.ComponentModel.ISupportInitialize )( this.DataGrid_RI ) ).BeginInit();
            this.TabPage_RO.SuspendLayout();
            ( ( System.ComponentModel.ISupportInitialize )( this.DataGrid_RO ) ).BeginInit();
            this.TabPage_VO.SuspendLayout();
            ( ( System.ComponentModel.ISupportInitialize )( this.DataGrid_VO ) ).BeginInit();
            this.SuspendLayout();
            //
            // Bnt_SafetyState
            //
            this.Bnt_SafetyState.Location = new System.Drawing.Point( 660, 107 );
            this.Bnt_SafetyState.Name = "Bnt_SafetyState";
            this.Bnt_SafetyState.Size = new System.Drawing.Size( 63, 45 );
            this.Bnt_SafetyState.TabIndex = 49;
            this.Bnt_SafetyState.Text = "Mode";
            this.Bnt_SafetyState.UseVisualStyleBackColor = true;
            this.Bnt_SafetyState.Click += new System.EventHandler( this.Bnt_SafetyState_Click );
            //
            // Bnt_Clean
            //
            this.Bnt_Clean.Location = new System.Drawing.Point( 249, -1 );
            this.Bnt_Clean.Name = "Bnt_Clean";
            this.Bnt_Clean.Size = new System.Drawing.Size( 73, 91 );
            this.Bnt_Clean.TabIndex = 48;
            this.Bnt_Clean.Text = "Clean";
            this.Bnt_Clean.UseVisualStyleBackColor = true;
            this.Bnt_Clean.Click += new System.EventHandler( this.Bnt_Clean_Click );
            //
            // Panel_ErrorInfo
            //
            this.Panel_ErrorInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Panel_ErrorInfo.Controls.Add( this.TextBox_ErrorInfo );
            this.Panel_ErrorInfo.Controls.Add( this.Bnt_Clean );
            this.Panel_ErrorInfo.Location = new System.Drawing.Point( 584, 16 );
            this.Panel_ErrorInfo.Name = "Panel_ErrorInfo";
            this.Panel_ErrorInfo.Size = new System.Drawing.Size( 323, 84 );
            this.Panel_ErrorInfo.TabIndex = 37;
            //
            // TextBox_ErrorInfo
            //
            this.TextBox_ErrorInfo.Anchor = ( ( System.Windows.Forms.AnchorStyles )( ( ( System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom )
                                              | System.Windows.Forms.AnchorStyles.Left ) ) );
            this.TextBox_ErrorInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TextBox_ErrorInfo.Font = new System.Drawing.Font( "標楷體", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ( ( byte )( 136 ) ) );
            this.TextBox_ErrorInfo.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.TextBox_ErrorInfo.Location = new System.Drawing.Point( 3, -1 );
            this.TextBox_ErrorInfo.Multiline = true;
            this.TextBox_ErrorInfo.Name = "TextBox_ErrorInfo";
            this.TextBox_ErrorInfo.ReadOnly = true;
            this.TextBox_ErrorInfo.Size = new System.Drawing.Size( 249, 85 );
            this.TextBox_ErrorInfo.TabIndex = 49;
            this.TextBox_ErrorInfo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TextBox_ErrorInfo.TextChanged += new System.EventHandler( this.TextBox_ErrorInfo_TextChanged );
            //
            // Tab_RobotInfo
            //
            this.Tab_RobotInfo.Controls.Add( this.Tab_Pos );
            this.Tab_RobotInfo.Controls.Add( this.Tab_Timer );
            this.Tab_RobotInfo.Controls.Add( this.Tab_Counter );
            this.Tab_RobotInfo.Controls.Add( this.Tab_PR );
            this.Tab_RobotInfo.Location = new System.Drawing.Point( 526, 155 );
            this.Tab_RobotInfo.Name = "Tab_RobotInfo";
            this.Tab_RobotInfo.SelectedIndex = 0;
            this.Tab_RobotInfo.Size = new System.Drawing.Size( 388, 329 );
            this.Tab_RobotInfo.TabIndex = 47;
            //
            // Tab_Pos
            //
            this.Tab_Pos.Controls.Add( this.DataGrid_Pos );
            this.Tab_Pos.Location = new System.Drawing.Point( 4, 22 );
            this.Tab_Pos.Name = "Tab_Pos";
            this.Tab_Pos.Padding = new System.Windows.Forms.Padding( 3 );
            this.Tab_Pos.Size = new System.Drawing.Size( 380, 303 );
            this.Tab_Pos.TabIndex = 0;
            this.Tab_Pos.Text = "Pos";
            this.Tab_Pos.UseVisualStyleBackColor = true;
            //
            // DataGrid_Pos
            //
            this.DataGrid_Pos.AllowUserToAddRows = false;
            this.DataGrid_Pos.AllowUserToDeleteRows = false;
            this.DataGrid_Pos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGrid_Pos.Location = new System.Drawing.Point( 7, 7 );
            this.DataGrid_Pos.Name = "DataGrid_Pos";
            this.DataGrid_Pos.ReadOnly = true;
            this.DataGrid_Pos.RowTemplate.Height = 24;
            this.DataGrid_Pos.Size = new System.Drawing.Size( 367, 300 );
            this.DataGrid_Pos.TabIndex = 0;
            //
            // Tab_Timer
            //
            this.Tab_Timer.Controls.Add( this.DataGrid_Timer );
            this.Tab_Timer.Location = new System.Drawing.Point( 4, 22 );
            this.Tab_Timer.Name = "Tab_Timer";
            this.Tab_Timer.Padding = new System.Windows.Forms.Padding( 3 );
            this.Tab_Timer.Size = new System.Drawing.Size( 380, 303 );
            this.Tab_Timer.TabIndex = 1;
            this.Tab_Timer.Text = "Timer";
            this.Tab_Timer.UseVisualStyleBackColor = true;
            //
            // DataGrid_Timer
            //
            this.DataGrid_Timer.AllowUserToAddRows = false;
            this.DataGrid_Timer.AllowUserToDeleteRows = false;
            this.DataGrid_Timer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGrid_Timer.Location = new System.Drawing.Point( 8, 8 );
            this.DataGrid_Timer.Name = "DataGrid_Timer";
            this.DataGrid_Timer.RowTemplate.Height = 24;
            this.DataGrid_Timer.Size = new System.Drawing.Size( 366, 295 );
            this.DataGrid_Timer.TabIndex = 1;
            this.DataGrid_Timer.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler( this.Timer_CellEndEdit );
            //
            // Tab_Counter
            //
            this.Tab_Counter.Controls.Add( this.DataGrid_Counter );
            this.Tab_Counter.Location = new System.Drawing.Point( 4, 22 );
            this.Tab_Counter.Name = "Tab_Counter";
            this.Tab_Counter.Size = new System.Drawing.Size( 380, 303 );
            this.Tab_Counter.TabIndex = 2;
            this.Tab_Counter.Text = "Counter";
            this.Tab_Counter.UseVisualStyleBackColor = true;
            //
            // DataGrid_Counter
            //
            this.DataGrid_Counter.AllowUserToAddRows = false;
            this.DataGrid_Counter.AllowUserToDeleteRows = false;
            this.DataGrid_Counter.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGrid_Counter.Location = new System.Drawing.Point( 8, 8 );
            this.DataGrid_Counter.Name = "DataGrid_Counter";
            this.DataGrid_Counter.RowTemplate.Height = 24;
            this.DataGrid_Counter.Size = new System.Drawing.Size( 369, 292 );
            this.DataGrid_Counter.TabIndex = 2;
            this.DataGrid_Counter.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler( this.Counter_CellEndEdit );
            //
            // Tab_PR
            //
            this.Tab_PR.Controls.Add( this.DataGrid_PR );
            this.Tab_PR.Location = new System.Drawing.Point( 4, 22 );
            this.Tab_PR.Name = "Tab_PR";
            this.Tab_PR.Size = new System.Drawing.Size( 380, 303 );
            this.Tab_PR.TabIndex = 3;
            this.Tab_PR.Text = "PR";
            this.Tab_PR.UseVisualStyleBackColor = true;
            //
            // DataGrid_PR
            //
            this.DataGrid_PR.AllowUserToAddRows = false;
            this.DataGrid_PR.AllowUserToDeleteRows = false;
            this.DataGrid_PR.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGrid_PR.Location = new System.Drawing.Point( 8, 8 );
            this.DataGrid_PR.Name = "DataGrid_PR";
            this.DataGrid_PR.RowTemplate.Height = 24;
            this.DataGrid_PR.Size = new System.Drawing.Size( 369, 292 );
            this.DataGrid_PR.TabIndex = 2;
            this.DataGrid_PR.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler( this.DataGrid_PR_CellContentClick );
            this.DataGrid_PR.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler( this.PR_CellEndEdit );
            this.DataGrid_PR.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler( this.DataGrid_PR_EditingControlShowing );
            //
            // groupBox3
            //
            this.groupBox3.BackColor = System.Drawing.Color.White;
            this.groupBox3.Controls.Add( this.Bar_Acc );
            this.groupBox3.Controls.Add( this.TextBox_Acc );
            this.groupBox3.Controls.Add( this.Bnt_AccDown );
            this.groupBox3.Controls.Add( this.Bnt_AccUp );
            this.groupBox3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox3.Location = new System.Drawing.Point( 12, 106 );
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size( 99, 81 );
            this.groupBox3.TabIndex = 46;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Acc Raio (%)";
            //
            // Bar_Acc
            //
            this.Bar_Acc.Location = new System.Drawing.Point( 6, 19 );
            this.Bar_Acc.Name = "Bar_Acc";
            this.Bar_Acc.Size = new System.Drawing.Size( 51, 19 );
            this.Bar_Acc.TabIndex = 30;
            //
            // TextBox_Acc
            //
            this.TextBox_Acc.BackColor = System.Drawing.SystemColors.Info;
            this.TextBox_Acc.Location = new System.Drawing.Point( 6, 44 );
            this.TextBox_Acc.Name = "TextBox_Acc";
            this.TextBox_Acc.Size = new System.Drawing.Size( 51, 22 );
            this.TextBox_Acc.TabIndex = 26;
            this.TextBox_Acc.KeyPress += new System.Windows.Forms.KeyPressEventHandler( this.TextBox_Acc_KeyPress );
            //
            // Bnt_AccDown
            //
            this.Bnt_AccDown.Location = new System.Drawing.Point( 64, 44 );
            this.Bnt_AccDown.Name = "Bnt_AccDown";
            this.Bnt_AccDown.Size = new System.Drawing.Size( 23, 23 );
            this.Bnt_AccDown.TabIndex = 25;
            this.Bnt_AccDown.Text = "↓\r\n";
            this.Bnt_AccDown.UseVisualStyleBackColor = true;
            this.Bnt_AccDown.Click += new System.EventHandler( this.Bnt_AccDown_Click );
            //
            // Bnt_AccUp
            //
            this.Bnt_AccUp.Location = new System.Drawing.Point( 63, 16 );
            this.Bnt_AccUp.Name = "Bnt_AccUp";
            this.Bnt_AccUp.Size = new System.Drawing.Size( 24, 22 );
            this.Bnt_AccUp.TabIndex = 24;
            this.Bnt_AccUp.Text = "↑";
            this.Bnt_AccUp.UseVisualStyleBackColor = true;
            this.Bnt_AccUp.Click += new System.EventHandler( this.Bnt_AccUp_Click );
            //
            // groupBox2
            //
            this.groupBox2.BackColor = System.Drawing.Color.White;
            this.groupBox2.Controls.Add( this.Bar_Ptp );
            this.groupBox2.Controls.Add( this.TextBox_Ptp );
            this.groupBox2.Controls.Add( this.Bnt_PtpUp );
            this.groupBox2.Controls.Add( this.Bnt_PtpDown );
            this.groupBox2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox2.Location = new System.Drawing.Point( 12, 191 );
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size( 99, 81 );
            this.groupBox2.TabIndex = 45;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "PTP Speed (%)";
            //
            // Bar_Ptp
            //
            this.Bar_Ptp.Location = new System.Drawing.Point( 6, 21 );
            this.Bar_Ptp.Name = "Bar_Ptp";
            this.Bar_Ptp.Size = new System.Drawing.Size( 51, 19 );
            this.Bar_Ptp.TabIndex = 31;
            //
            // TextBox_Ptp
            //
            this.TextBox_Ptp.BackColor = System.Drawing.SystemColors.Info;
            this.TextBox_Ptp.Location = new System.Drawing.Point( 6, 46 );
            this.TextBox_Ptp.Name = "TextBox_Ptp";
            this.TextBox_Ptp.Size = new System.Drawing.Size( 51, 22 );
            this.TextBox_Ptp.TabIndex = 26;
            this.TextBox_Ptp.KeyPress += new System.Windows.Forms.KeyPressEventHandler( this.TextBox_Ptp_KeyPress );
            //
            // Bnt_PtpUp
            //
            this.Bnt_PtpUp.Location = new System.Drawing.Point( 65, 21 );
            this.Bnt_PtpUp.Name = "Bnt_PtpUp";
            this.Bnt_PtpUp.Size = new System.Drawing.Size( 25, 23 );
            this.Bnt_PtpUp.TabIndex = 24;
            this.Bnt_PtpUp.Text = "↑";
            this.Bnt_PtpUp.UseVisualStyleBackColor = true;
            this.Bnt_PtpUp.Click += new System.EventHandler( this.Bnt_PtpUp_Click );
            //
            // Bnt_PtpDown
            //
            this.Bnt_PtpDown.Location = new System.Drawing.Point( 65, 48 );
            this.Bnt_PtpDown.Name = "Bnt_PtpDown";
            this.Bnt_PtpDown.Size = new System.Drawing.Size( 25, 24 );
            this.Bnt_PtpDown.TabIndex = 25;
            this.Bnt_PtpDown.Text = "↓\r\n";
            this.Bnt_PtpDown.UseVisualStyleBackColor = true;
            this.Bnt_PtpDown.Click += new System.EventHandler( this.Bnt_PtpDown_Click );
            //
            // groupBox1
            //
            this.groupBox1.BackColor = System.Drawing.Color.White;
            this.groupBox1.Controls.Add( this.Bar_Lin );
            this.groupBox1.Controls.Add( this.TextBox_Lin );
            this.groupBox1.Controls.Add( this.Bnt_LinUp );
            this.groupBox1.Controls.Add( this.Bnt_LinDown );
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox1.Location = new System.Drawing.Point( 9, 288 );
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size( 102, 75 );
            this.groupBox1.TabIndex = 44;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Lin Speed(mm/s)";
            //
            // Bar_Lin
            //
            this.Bar_Lin.Location = new System.Drawing.Point( 6, 15 );
            this.Bar_Lin.Name = "Bar_Lin";
            this.Bar_Lin.Size = new System.Drawing.Size( 51, 19 );
            this.Bar_Lin.TabIndex = 32;
            this.Bar_Lin.Click += new System.EventHandler( this.Bar_Lin_Click );
            //
            // TextBox_Lin
            //
            this.TextBox_Lin.BackColor = System.Drawing.SystemColors.Info;
            this.TextBox_Lin.Location = new System.Drawing.Point( 6, 43 );
            this.TextBox_Lin.Name = "TextBox_Lin";
            this.TextBox_Lin.Size = new System.Drawing.Size( 51, 22 );
            this.TextBox_Lin.TabIndex = 26;
            this.TextBox_Lin.KeyPress += new System.Windows.Forms.KeyPressEventHandler( this.TextBox_Lin_KeyPress );
            //
            // Bnt_LinUp
            //
            this.Bnt_LinUp.Location = new System.Drawing.Point( 65, 11 );
            this.Bnt_LinUp.Name = "Bnt_LinUp";
            this.Bnt_LinUp.Size = new System.Drawing.Size( 24, 23 );
            this.Bnt_LinUp.TabIndex = 24;
            this.Bnt_LinUp.Text = "↑";
            this.Bnt_LinUp.UseVisualStyleBackColor = true;
            this.Bnt_LinUp.Click += new System.EventHandler( this.Bnt_LinUp_Click );
            //
            // Bnt_LinDown
            //
            this.Bnt_LinDown.Location = new System.Drawing.Point( 66, 40 );
            this.Bnt_LinDown.Name = "Bnt_LinDown";
            this.Bnt_LinDown.Size = new System.Drawing.Size( 24, 24 );
            this.Bnt_LinDown.TabIndex = 25;
            this.Bnt_LinDown.Text = "↓\r\n";
            this.Bnt_LinDown.UseVisualStyleBackColor = true;
            this.Bnt_LinDown.Click += new System.EventHandler( this.Bnt_LinDown_Click );
            //
            // groupBox_Override
            //
            this.groupBox_Override.BackColor = System.Drawing.Color.White;
            this.groupBox_Override.Controls.Add( this.Bar_Override );
            this.groupBox_Override.Controls.Add( this.TextBox_Override );
            this.groupBox_Override.Controls.Add( this.Btn_OverrideUp );
            this.groupBox_Override.Controls.Add( this.Btn_OverrideDown );
            this.groupBox_Override.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox_Override.Location = new System.Drawing.Point( 12, 398 );
            this.groupBox_Override.Name = "groupBox_Override";
            this.groupBox_Override.Size = new System.Drawing.Size( 99, 86 );
            this.groupBox_Override.TabIndex = 43;
            this.groupBox_Override.TabStop = false;
            this.groupBox_Override.Text = "Override (%)";
            //
            // Bar_Override
            //
            this.Bar_Override.Location = new System.Drawing.Point( 6, 21 );
            this.Bar_Override.Name = "Bar_Override";
            this.Bar_Override.Size = new System.Drawing.Size( 51, 19 );
            this.Bar_Override.TabIndex = 33;
            //
            // TextBox_Override
            //
            this.TextBox_Override.BackColor = System.Drawing.SystemColors.Info;
            this.TextBox_Override.Location = new System.Drawing.Point( 6, 47 );
            this.TextBox_Override.Name = "TextBox_Override";
            this.TextBox_Override.Size = new System.Drawing.Size( 51, 22 );
            this.TextBox_Override.TabIndex = 26;
            this.TextBox_Override.KeyPress += new System.Windows.Forms.KeyPressEventHandler( this.TextBox_Override_KeyPress );
            //
            // Btn_OverrideUp
            //
            this.Btn_OverrideUp.Location = new System.Drawing.Point( 66, 21 );
            this.Btn_OverrideUp.Name = "Btn_OverrideUp";
            this.Btn_OverrideUp.Size = new System.Drawing.Size( 24, 23 );
            this.Btn_OverrideUp.TabIndex = 24;
            this.Btn_OverrideUp.Text = "↑";
            this.Btn_OverrideUp.UseVisualStyleBackColor = true;
            this.Btn_OverrideUp.Click += new System.EventHandler( this.Btn_OverrideUp_Click );
            //
            // Btn_OverrideDown
            //
            this.Btn_OverrideDown.Location = new System.Drawing.Point( 65, 47 );
            this.Btn_OverrideDown.Name = "Btn_OverrideDown";
            this.Btn_OverrideDown.Size = new System.Drawing.Size( 24, 24 );
            this.Btn_OverrideDown.TabIndex = 25;
            this.Btn_OverrideDown.Text = "↓\r\n";
            this.Btn_OverrideDown.UseVisualStyleBackColor = true;
            this.Btn_OverrideDown.Click += new System.EventHandler( this.Btn_OverrideDown_Click );
            //
            // Bnt_Home
            //
            this.Bnt_Home.Location = new System.Drawing.Point( 124, 271 );
            this.Bnt_Home.Name = "Bnt_Home";
            this.Bnt_Home.Size = new System.Drawing.Size( 50, 50 );
            this.Bnt_Home.TabIndex = 41;
            this.Bnt_Home.Text = "Home";
            this.Bnt_Home.UseVisualStyleBackColor = true;
            this.Bnt_Home.MouseDown += new System.Windows.Forms.MouseEventHandler( this.Bnt_Home_KeyDown );
            this.Bnt_Home.MouseUp += new System.Windows.Forms.MouseEventHandler( this.Bnt_Home_KeyUp );
            //
            // But_Stop
            //
            this.But_Stop.Location = new System.Drawing.Point( 124, 215 );
            this.But_Stop.Name = "But_Stop";
            this.But_Stop.Size = new System.Drawing.Size( 50, 50 );
            this.But_Stop.TabIndex = 40;
            this.But_Stop.Text = "Stop";
            this.But_Stop.UseVisualStyleBackColor = true;
            this.But_Stop.Click += new System.EventHandler( this.But_Stop_Click );
            //
            // Bnt_Pause
            //
            this.Bnt_Pause.Location = new System.Drawing.Point( 124, 159 );
            this.Bnt_Pause.Name = "Bnt_Pause";
            this.Bnt_Pause.Size = new System.Drawing.Size( 50, 50 );
            this.Bnt_Pause.TabIndex = 39;
            this.Bnt_Pause.Text = "Pause";
            this.Bnt_Pause.UseVisualStyleBackColor = true;
            this.Bnt_Pause.Click += new System.EventHandler( this.Bnt_Pause_Click );
            //
            // Bnt_Go
            //
            this.Bnt_Go.Location = new System.Drawing.Point( 124, 102 );
            this.Bnt_Go.Name = "Bnt_Go";
            this.Bnt_Go.Size = new System.Drawing.Size( 50, 50 );
            this.Bnt_Go.TabIndex = 38;
            this.Bnt_Go.Text = "Go";
            this.Bnt_Go.UseVisualStyleBackColor = true;
            this.Bnt_Go.Click += new System.EventHandler( this.Bnt_Go_Click );
            //
            // Panel_DeviceInfo
            //
            this.Panel_DeviceInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Panel_DeviceInfo.Controls.Add( this.Label_Utilization );
            this.Panel_DeviceInfo.Controls.Add( this.Label_UtilizationRatio );
            this.Panel_DeviceInfo.Controls.Add( this.Label_Birthday );
            this.Panel_DeviceInfo.Controls.Add( this.Label_RobotType );
            this.Panel_DeviceInfo.Controls.Add( this.Label_OperationTime );
            this.Panel_DeviceInfo.Controls.Add( this.Label_HRSS_version );
            this.Panel_DeviceInfo.Location = new System.Drawing.Point( 12, 16 );
            this.Panel_DeviceInfo.Name = "Panel_DeviceInfo";
            this.Panel_DeviceInfo.Size = new System.Drawing.Size( 566, 84 );
            this.Panel_DeviceInfo.TabIndex = 36;
            //
            // Label_Utilization
            //
            this.Label_Utilization.AutoSize = true;
            this.Label_Utilization.Font = new System.Drawing.Font( "標楷體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ( ( byte )( 136 ) ) );
            this.Label_Utilization.Location = new System.Drawing.Point( 242, 25 );
            this.Label_Utilization.Name = "Label_Utilization";
            this.Label_Utilization.Size = new System.Drawing.Size( 112, 16 );
            this.Label_Utilization.TabIndex = 6;
            this.Label_Utilization.Text = "UTILIZATION: ";
            //
            // Label_UtilizationRatio
            //
            this.Label_UtilizationRatio.AutoSize = true;
            this.Label_UtilizationRatio.Font = new System.Drawing.Font( "標楷體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ( ( byte )( 136 ) ) );
            this.Label_UtilizationRatio.Location = new System.Drawing.Point( 242, 53 );
            this.Label_UtilizationRatio.Name = "Label_UtilizationRatio";
            this.Label_UtilizationRatio.Size = new System.Drawing.Size( 160, 16 );
            this.Label_UtilizationRatio.TabIndex = 5;
            this.Label_UtilizationRatio.Text = "UTILIZATION RATIO: ";
            //
            // Label_Birthday
            //
            this.Label_Birthday.AutoSize = true;
            this.Label_Birthday.Font = new System.Drawing.Font( "標楷體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ( ( byte )( 136 ) ) );
            this.Label_Birthday.Location = new System.Drawing.Point( 3, 53 );
            this.Label_Birthday.Name = "Label_Birthday";
            this.Label_Birthday.Size = new System.Drawing.Size( 88, 16 );
            this.Label_Birthday.TabIndex = 4;
            this.Label_Birthday.Text = "BIRTHDAY: ";
            //
            // Label_RobotType
            //
            this.Label_RobotType.AutoSize = true;
            this.Label_RobotType.Font = new System.Drawing.Font( "標楷體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ( ( byte )( 136 ) ) );
            this.Label_RobotType.Location = new System.Drawing.Point( 3, 25 );
            this.Label_RobotType.Name = "Label_RobotType";
            this.Label_RobotType.Size = new System.Drawing.Size( 104, 16 );
            this.Label_RobotType.TabIndex = 3;
            this.Label_RobotType.Text = "ROBOT TYPE: ";
            //
            // Label_OperationTime
            //
            this.Label_OperationTime.AutoSize = true;
            this.Label_OperationTime.Font = new System.Drawing.Font( "標楷體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ( ( byte )( 136 ) ) );
            this.Label_OperationTime.Location = new System.Drawing.Point( 242, 0 );
            this.Label_OperationTime.Name = "Label_OperationTime";
            this.Label_OperationTime.Size = new System.Drawing.Size( 136, 16 );
            this.Label_OperationTime.TabIndex = 2;
            this.Label_OperationTime.Text = "OPERATION TIME: ";
            //
            // Label_HRSS_version
            //
            this.Label_HRSS_version.AutoSize = true;
            this.Label_HRSS_version.Font = new System.Drawing.Font( "標楷體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ( ( byte )( 136 ) ) );
            this.Label_HRSS_version.Location = new System.Drawing.Point( 3, 0 );
            this.Label_HRSS_version.Name = "Label_HRSS_version";
            this.Label_HRSS_version.Size = new System.Drawing.Size( 120, 16 );
            this.Label_HRSS_version.TabIndex = 1;
            this.Label_HRSS_version.Text = "HRSS VERSION: ";
            //
            // JogPanel
            //
            this.JogPanel.Controls.Add( this.JogPositive6 );
            this.JogPanel.Controls.Add( this.JogNeg1 );
            this.JogPanel.Controls.Add( this.JogNeg5 );
            this.JogPanel.Controls.Add( this.JogPositive3 );
            this.JogPanel.Controls.Add( this.JogNeg2 );
            this.JogPanel.Controls.Add( this.JogPositive2 );
            this.JogPanel.Controls.Add( this.JogNeg4 );
            this.JogPanel.Controls.Add( this.JogPositive5 );
            this.JogPanel.Controls.Add( this.JogNeg6 );
            this.JogPanel.Controls.Add( this.JogPositive4 );
            this.JogPanel.Controls.Add( this.JogNeg3 );
            this.JogPanel.Controls.Add( this.JogPositive1 );
            this.JogPanel.Location = new System.Drawing.Point( 975, 156 );
            this.JogPanel.Name = "JogPanel";
            this.JogPanel.Size = new System.Drawing.Size( 101, 385 );
            this.JogPanel.TabIndex = 33;
            //
            // JogPositive6
            //
            this.JogPositive6.Location = new System.Drawing.Point( 52, 336 );
            this.JogPositive6.Name = "JogPositive6";
            this.JogPositive6.Size = new System.Drawing.Size( 43, 43 );
            this.JogPositive6.TabIndex = 12;
            this.JogPositive6.Text = ">";
            this.JogPositive6.UseVisualStyleBackColor = true;
            this.JogPositive6.MouseDown += new System.Windows.Forms.MouseEventHandler( this.JogPositive6_MouseDown );
            this.JogPositive6.MouseUp += new System.Windows.Forms.MouseEventHandler( this.JogPositive6_MouseUp );
            //
            // JogNeg1
            //
            this.JogNeg1.Location = new System.Drawing.Point( 3, 3 );
            this.JogNeg1.Name = "JogNeg1";
            this.JogNeg1.Size = new System.Drawing.Size( 43, 43 );
            this.JogNeg1.TabIndex = 1;
            this.JogNeg1.Text = "<";
            this.JogNeg1.UseVisualStyleBackColor = true;
            this.JogNeg1.MouseDown += new System.Windows.Forms.MouseEventHandler( this.JogNeg1_MouseDown );
            this.JogNeg1.MouseUp += new System.Windows.Forms.MouseEventHandler( this.JogNeg1_MouseUp );
            //
            // JogNeg5
            //
            this.JogNeg5.Location = new System.Drawing.Point( 3, 265 );
            this.JogNeg5.Name = "JogNeg5";
            this.JogNeg5.Size = new System.Drawing.Size( 43, 43 );
            this.JogNeg5.TabIndex = 5;
            this.JogNeg5.Text = "<";
            this.JogNeg5.UseVisualStyleBackColor = true;
            this.JogNeg5.MouseDown += new System.Windows.Forms.MouseEventHandler( this.JogNeg5_MouseDown );
            this.JogNeg5.MouseUp += new System.Windows.Forms.MouseEventHandler( this.JogNeg5_MouseUp );
            //
            // JogPositive3
            //
            this.JogPositive3.Location = new System.Drawing.Point( 52, 126 );
            this.JogPositive3.Name = "JogPositive3";
            this.JogPositive3.Size = new System.Drawing.Size( 43, 43 );
            this.JogPositive3.TabIndex = 9;
            this.JogPositive3.Text = ">";
            this.JogPositive3.UseVisualStyleBackColor = true;
            this.JogPositive3.MouseDown += new System.Windows.Forms.MouseEventHandler( this.JogPositive3_MouseDown );
            this.JogPositive3.MouseUp += new System.Windows.Forms.MouseEventHandler( this.JogPositive3_MouseUp );
            //
            // JogNeg2
            //
            this.JogNeg2.Location = new System.Drawing.Point( 3, 62 );
            this.JogNeg2.Name = "JogNeg2";
            this.JogNeg2.Size = new System.Drawing.Size( 43, 43 );
            this.JogNeg2.TabIndex = 2;
            this.JogNeg2.Text = "<";
            this.JogNeg2.UseVisualStyleBackColor = true;
            this.JogNeg2.MouseDown += new System.Windows.Forms.MouseEventHandler( this.JogNeg2_MouseDown );
            this.JogNeg2.MouseUp += new System.Windows.Forms.MouseEventHandler( this.JogNeg2_MouseUp );
            //
            // JogPositive2
            //
            this.JogPositive2.Location = new System.Drawing.Point( 52, 62 );
            this.JogPositive2.Name = "JogPositive2";
            this.JogPositive2.Size = new System.Drawing.Size( 43, 43 );
            this.JogPositive2.TabIndex = 8;
            this.JogPositive2.Text = ">";
            this.JogPositive2.UseVisualStyleBackColor = true;
            this.JogPositive2.MouseDown += new System.Windows.Forms.MouseEventHandler( this.JogPositive2_MouseDown );
            this.JogPositive2.MouseUp += new System.Windows.Forms.MouseEventHandler( this.JogPositive2_MouseUp );
            //
            // JogNeg4
            //
            this.JogNeg4.Location = new System.Drawing.Point( 3, 193 );
            this.JogNeg4.Name = "JogNeg4";
            this.JogNeg4.Size = new System.Drawing.Size( 43, 43 );
            this.JogNeg4.TabIndex = 4;
            this.JogNeg4.Text = "<";
            this.JogNeg4.UseVisualStyleBackColor = true;
            this.JogNeg4.MouseDown += new System.Windows.Forms.MouseEventHandler( this.JogNeg4_MouseDown );
            this.JogNeg4.MouseUp += new System.Windows.Forms.MouseEventHandler( this.JogNeg4_MouseUp );
            //
            // JogPositive5
            //
            this.JogPositive5.Location = new System.Drawing.Point( 52, 265 );
            this.JogPositive5.Name = "JogPositive5";
            this.JogPositive5.Size = new System.Drawing.Size( 43, 43 );
            this.JogPositive5.TabIndex = 11;
            this.JogPositive5.Text = ">";
            this.JogPositive5.UseVisualStyleBackColor = true;
            this.JogPositive5.MouseDown += new System.Windows.Forms.MouseEventHandler( this.JogPositive5_MouseDown );
            this.JogPositive5.MouseUp += new System.Windows.Forms.MouseEventHandler( this.JogPositive5_MouseUp );
            //
            // JogNeg6
            //
            this.JogNeg6.Location = new System.Drawing.Point( 3, 336 );
            this.JogNeg6.Name = "JogNeg6";
            this.JogNeg6.Size = new System.Drawing.Size( 43, 43 );
            this.JogNeg6.TabIndex = 6;
            this.JogNeg6.Text = "<";
            this.JogNeg6.UseVisualStyleBackColor = true;
            this.JogNeg6.MouseDown += new System.Windows.Forms.MouseEventHandler( this.JogNeg6_MouseDown );
            this.JogNeg6.MouseUp += new System.Windows.Forms.MouseEventHandler( this.JogNeg6_MouseUp );
            //
            // JogPositive4
            //
            this.JogPositive4.Location = new System.Drawing.Point( 52, 193 );
            this.JogPositive4.Name = "JogPositive4";
            this.JogPositive4.Size = new System.Drawing.Size( 43, 43 );
            this.JogPositive4.TabIndex = 10;
            this.JogPositive4.Text = ">";
            this.JogPositive4.UseVisualStyleBackColor = true;
            this.JogPositive4.MouseDown += new System.Windows.Forms.MouseEventHandler( this.JogPositive4_MouseDown );
            this.JogPositive4.MouseUp += new System.Windows.Forms.MouseEventHandler( this.JogPositive4_MouseUp );
            //
            // JogNeg3
            //
            this.JogNeg3.Location = new System.Drawing.Point( 3, 126 );
            this.JogNeg3.Name = "JogNeg3";
            this.JogNeg3.Size = new System.Drawing.Size( 43, 43 );
            this.JogNeg3.TabIndex = 3;
            this.JogNeg3.Text = "<";
            this.JogNeg3.UseVisualStyleBackColor = true;
            this.JogNeg3.MouseDown += new System.Windows.Forms.MouseEventHandler( this.JogNeg3_MouseDown );
            this.JogNeg3.MouseUp += new System.Windows.Forms.MouseEventHandler( this.JogNeg3_MouseUp );
            //
            // JogPositive1
            //
            this.JogPositive1.Location = new System.Drawing.Point( 52, 3 );
            this.JogPositive1.Name = "JogPositive1";
            this.JogPositive1.Size = new System.Drawing.Size( 43, 43 );
            this.JogPositive1.TabIndex = 7;
            this.JogPositive1.Text = ">";
            this.JogPositive1.UseVisualStyleBackColor = true;
            this.JogPositive1.Click += new System.EventHandler( this.JogPositive1_Click );
            this.JogPositive1.MouseDown += new System.Windows.Forms.MouseEventHandler( this.JogPositive1_MouseDown );
            this.JogPositive1.MouseUp += new System.Windows.Forms.MouseEventHandler( this.JogPositive1_MouseUp );
            //
            // Bnt_Servo
            //
            this.Bnt_Servo.Location = new System.Drawing.Point( 975, 118 );
            this.Bnt_Servo.Name = "Bnt_Servo";
            this.Bnt_Servo.Size = new System.Drawing.Size( 99, 34 );
            this.Bnt_Servo.TabIndex = 32;
            this.Bnt_Servo.Text = "Servo";
            this.Bnt_Servo.UseVisualStyleBackColor = true;
            this.Bnt_Servo.Click += new System.EventHandler( this.Bnt_Servo_Click );
            //
            // panel1
            //
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add( this.Radio_controller );
            this.panel1.Controls.Add( this.Btn_UpdateHRSS );
            this.panel1.Controls.Add( this.Radio_monitor );
            this.panel1.Controls.Add( this.label4 );
            this.panel1.Controls.Add( this.button1 );
            this.panel1.Controls.Add( this.Bnt_RsrGo );
            this.panel1.Controls.Add( this.Label_RobotID );
            this.panel1.Controls.Add( this.Bnt_SetRobotId );
            this.panel1.Controls.Add( this.Bnt_Go );
            this.panel1.Controls.Add( this.TextBox_RobotID );
            this.panel1.Controls.Add( this.TextBox_ProgramName );
            this.panel1.Controls.Add( this.Tab_IO );
            this.panel1.Controls.Add( this.Bnt_Servo );
            this.panel1.Controls.Add( this.Combo_PNS );
            this.panel1.Controls.Add( this.Combo_RSR );
            this.panel1.Controls.Add( this.TextBox_ConnectionLevel );
            this.panel1.Controls.Add( this.Bnt_SetBase );
            this.panel1.Controls.Add( this.Bnt_SetTool );
            this.panel1.Controls.Add( this.Combo_Tool );
            this.panel1.Controls.Add( this.Combo_Base );
            this.panel1.Controls.Add( this.label3 );
            this.panel1.Controls.Add( this.label2 );
            this.panel1.Controls.Add( this.label1 );
            this.panel1.Controls.Add( this.ComboBox_JogType );
            this.panel1.Controls.Add( this.Label_Jog6 );
            this.panel1.Controls.Add( this.Label_Jog5 );
            this.panel1.Controls.Add( this.Label_Jog4 );
            this.panel1.Controls.Add( this.Label_Jog3 );
            this.panel1.Controls.Add( this.Label_Jog2 );
            this.panel1.Controls.Add( this.Label_Jog1 );
            this.panel1.Controls.Add( this.Bnt_SafetyState );
            this.panel1.Controls.Add( this.Panel_ErrorInfo );
            this.panel1.Controls.Add( this.Tab_RobotInfo );
            this.panel1.Controls.Add( this.groupBox3 );
            this.panel1.Controls.Add( this.groupBox2 );
            this.panel1.Controls.Add( this.groupBox1 );
            this.panel1.Controls.Add( this.groupBox_Override );
            this.panel1.Controls.Add( this.Bnt_Home );
            this.panel1.Controls.Add( this.But_Stop );
            this.panel1.Controls.Add( this.Bnt_Pause );
            this.panel1.Controls.Add( this.Panel_DeviceInfo );
            this.panel1.Controls.Add( this.JogPanel );
            this.panel1.Location = new System.Drawing.Point( 3, 3 );
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size( 1096, 559 );
            this.panel1.TabIndex = 51;
            //
            // Radio_controller
            //
            this.Radio_controller.AutoSize = true;
            this.Radio_controller.Font = new System.Drawing.Font( "新細明體", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ( ( byte )( 136 ) ) );
            this.Radio_controller.Location = new System.Drawing.Point( 675, 502 );
            this.Radio_controller.Name = "Radio_controller";
            this.Radio_controller.Size = new System.Drawing.Size( 109, 25 );
            this.Radio_controller.TabIndex = 54;
            this.Radio_controller.Text = "Controller";
            this.Radio_controller.UseVisualStyleBackColor = true;
            this.Radio_controller.CheckedChanged += new System.EventHandler( this.Radio_controller_CheckedChanged );
            //
            // Btn_UpdateHRSS
            //
            this.Btn_UpdateHRSS.Location = new System.Drawing.Point( 124, 430 );
            this.Btn_UpdateHRSS.Name = "Btn_UpdateHRSS";
            this.Btn_UpdateHRSS.Size = new System.Drawing.Size( 50, 50 );
            this.Btn_UpdateHRSS.TabIndex = 70;
            this.Btn_UpdateHRSS.Text = "UpdateHRSS";
            this.Btn_UpdateHRSS.UseVisualStyleBackColor = true;
            this.Btn_UpdateHRSS.Click += new System.EventHandler( this.Btn_UpdateHRSS_Click );
            //
            // Radio_monitor
            //
            this.Radio_monitor.AutoSize = true;
            this.Radio_monitor.Font = new System.Drawing.Font( "新細明體", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ( ( byte )( 136 ) ) );
            this.Radio_monitor.Location = new System.Drawing.Point( 586, 502 );
            this.Radio_monitor.Name = "Radio_monitor";
            this.Radio_monitor.Size = new System.Drawing.Size( 93, 25 );
            this.Radio_monitor.TabIndex = 53;
            this.Radio_monitor.Text = "Monitor";
            this.Radio_monitor.UseVisualStyleBackColor = true;
            this.Radio_monitor.CheckedChanged += new System.EventHandler( this.Radio_monitor_CheckedChanged );
            //
            // label4
            //
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font( "新細明體", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ( ( byte )( 136 ) ) );
            this.label4.Location = new System.Drawing.Point( 528, 503 );
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size( 65, 21 );
            this.label4.TabIndex = 52;
            this.label4.Text = "Level: ";
            this.label4.UseMnemonic = false;
            //
            // button1
            //
            this.button1.Location = new System.Drawing.Point( 503, 104 );
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size( 50, 50 );
            this.button1.TabIndex = 67;
            this.button1.Text = "PNS GO";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler( this.button1_Click );
            //
            // Bnt_RsrGo
            //
            this.Bnt_RsrGo.Location = new System.Drawing.Point( 365, 103 );
            this.Bnt_RsrGo.Name = "Bnt_RsrGo";
            this.Bnt_RsrGo.Size = new System.Drawing.Size( 50, 50 );
            this.Bnt_RsrGo.TabIndex = 65;
            this.Bnt_RsrGo.Text = "RSR GO";
            this.Bnt_RsrGo.UseVisualStyleBackColor = true;
            this.Bnt_RsrGo.Click += new System.EventHandler( this.Bnt_RsrGo_Click );
            //
            // Label_RobotID
            //
            this.Label_RobotID.AutoSize = true;
            this.Label_RobotID.Font = new System.Drawing.Font( "標楷體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ( ( byte )( 136 ) ) );
            this.Label_RobotID.Location = new System.Drawing.Point( 16, 503 );
            this.Label_RobotID.Name = "Label_RobotID";
            this.Label_RobotID.Size = new System.Drawing.Size( 88, 16 );
            this.Label_RobotID.TabIndex = 4;
            this.Label_RobotID.Text = "ROBOT ID: ";
            //
            // Bnt_SetRobotId
            //
            this.Bnt_SetRobotId.Location = new System.Drawing.Point( 460, 487 );
            this.Bnt_SetRobotId.Name = "Bnt_SetRobotId";
            this.Bnt_SetRobotId.Size = new System.Drawing.Size( 50, 50 );
            this.Bnt_SetRobotId.TabIndex = 38;
            this.Bnt_SetRobotId.Text = "Set";
            this.Bnt_SetRobotId.UseVisualStyleBackColor = true;
            this.Bnt_SetRobotId.Click += new System.EventHandler( this.Bnt_SetRobotId_Click );
            //
            // TextBox_RobotID
            //
            this.TextBox_RobotID.Font = new System.Drawing.Font( "新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ( ( byte )( 136 ) ) );
            this.TextBox_RobotID.Location = new System.Drawing.Point( 110, 494 );
            this.TextBox_RobotID.Name = "TextBox_RobotID";
            this.TextBox_RobotID.Size = new System.Drawing.Size( 344, 36 );
            this.TextBox_RobotID.TabIndex = 69;
            this.TextBox_RobotID.Text = "robot id";
            //
            // TextBox_ProgramName
            //
            this.TextBox_ProgramName.Font = new System.Drawing.Font( "新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ( ( byte )( 136 ) ) );
            this.TextBox_ProgramName.Location = new System.Drawing.Point( 170, 110 );
            this.TextBox_ProgramName.Name = "TextBox_ProgramName";
            this.TextBox_ProgramName.Size = new System.Drawing.Size( 146, 36 );
            this.TextBox_ProgramName.TabIndex = 69;
            this.TextBox_ProgramName.Text = "program_Test";
            //
            // Tab_IO
            //
            this.Tab_IO.Controls.Add( this.TabPage_DI );
            this.Tab_IO.Controls.Add( this.TabPage_DO );
            this.Tab_IO.Controls.Add( this.TabPage_FI );
            this.Tab_IO.Controls.Add( this.TabPage_FO );
            this.Tab_IO.Controls.Add( this.TabPage_RI );
            this.Tab_IO.Controls.Add( this.TabPage_RO );
            this.Tab_IO.Controls.Add( this.TabPage_VO );
            this.Tab_IO.ItemSize = new System.Drawing.Size( 5, 20 );
            this.Tab_IO.Location = new System.Drawing.Point( 179, 155 );
            this.Tab_IO.Name = "Tab_IO";
            this.Tab_IO.SelectedIndex = 0;
            this.Tab_IO.Size = new System.Drawing.Size( 341, 327 );
            this.Tab_IO.SizeMode = System.Windows.Forms.TabSizeMode.FillToRight;
            this.Tab_IO.TabIndex = 0;
            //
            // TabPage_DI
            //
            this.TabPage_DI.Controls.Add( this.DataGrid_DI );
            this.TabPage_DI.Location = new System.Drawing.Point( 4, 24 );
            this.TabPage_DI.Name = "TabPage_DI";
            this.TabPage_DI.Padding = new System.Windows.Forms.Padding( 3 );
            this.TabPage_DI.Size = new System.Drawing.Size( 333, 299 );
            this.TabPage_DI.TabIndex = 0;
            this.TabPage_DI.Text = "DI";
            this.TabPage_DI.UseVisualStyleBackColor = true;
            //
            // DataGrid_DI
            //
            this.DataGrid_DI.AllowUserToAddRows = false;
            this.DataGrid_DI.AllowUserToDeleteRows = false;
            this.DataGrid_DI.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGrid_DI.Location = new System.Drawing.Point( 6, 7 );
            this.DataGrid_DI.Name = "DataGrid_DI";
            this.DataGrid_DI.ReadOnly = true;
            this.DataGrid_DI.RowTemplate.Height = 24;
            this.DataGrid_DI.Size = new System.Drawing.Size( 321, 286 );
            this.DataGrid_DI.TabIndex = 3;
            //
            // TabPage_DO
            //
            this.TabPage_DO.Controls.Add( this.DataGrid_DO );
            this.TabPage_DO.Location = new System.Drawing.Point( 4, 24 );
            this.TabPage_DO.Name = "TabPage_DO";
            this.TabPage_DO.Padding = new System.Windows.Forms.Padding( 3 );
            this.TabPage_DO.Size = new System.Drawing.Size( 333, 299 );
            this.TabPage_DO.TabIndex = 1;
            this.TabPage_DO.Text = "DO";
            this.TabPage_DO.UseVisualStyleBackColor = true;
            //
            // DataGrid_DO
            //
            this.DataGrid_DO.AllowUserToAddRows = false;
            this.DataGrid_DO.AllowUserToDeleteRows = false;
            this.DataGrid_DO.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGrid_DO.Location = new System.Drawing.Point( 6, 6 );
            this.DataGrid_DO.Name = "DataGrid_DO";
            this.DataGrid_DO.RowTemplate.Height = 24;
            this.DataGrid_DO.Size = new System.Drawing.Size( 321, 286 );
            this.DataGrid_DO.TabIndex = 4;
            this.DataGrid_DO.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler( this.DO_CellValueChanged );
            //
            // TabPage_FI
            //
            this.TabPage_FI.Controls.Add( this.DataGrid_FI );
            this.TabPage_FI.Location = new System.Drawing.Point( 4, 24 );
            this.TabPage_FI.Name = "TabPage_FI";
            this.TabPage_FI.Size = new System.Drawing.Size( 333, 299 );
            this.TabPage_FI.TabIndex = 2;
            this.TabPage_FI.Text = "FI";
            this.TabPage_FI.UseVisualStyleBackColor = true;
            //
            // DataGrid_FI
            //
            this.DataGrid_FI.AllowUserToAddRows = false;
            this.DataGrid_FI.AllowUserToDeleteRows = false;
            this.DataGrid_FI.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGrid_FI.Location = new System.Drawing.Point( 6, 6 );
            this.DataGrid_FI.Name = "DataGrid_FI";
            this.DataGrid_FI.ReadOnly = true;
            this.DataGrid_FI.RowTemplate.Height = 24;
            this.DataGrid_FI.Size = new System.Drawing.Size( 321, 286 );
            this.DataGrid_FI.TabIndex = 4;
            //
            // TabPage_FO
            //
            this.TabPage_FO.Controls.Add( this.DataGrid_FO );
            this.TabPage_FO.Location = new System.Drawing.Point( 4, 24 );
            this.TabPage_FO.Name = "TabPage_FO";
            this.TabPage_FO.Size = new System.Drawing.Size( 333, 299 );
            this.TabPage_FO.TabIndex = 3;
            this.TabPage_FO.Text = "FO";
            this.TabPage_FO.UseVisualStyleBackColor = true;
            //
            // DataGrid_FO
            //
            this.DataGrid_FO.AllowUserToAddRows = false;
            this.DataGrid_FO.AllowUserToDeleteRows = false;
            this.DataGrid_FO.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGrid_FO.Location = new System.Drawing.Point( 6, 6 );
            this.DataGrid_FO.Name = "DataGrid_FO";
            this.DataGrid_FO.ReadOnly = true;
            this.DataGrid_FO.RowTemplate.Height = 24;
            this.DataGrid_FO.Size = new System.Drawing.Size( 321, 286 );
            this.DataGrid_FO.TabIndex = 4;
            //
            // TabPage_RI
            //
            this.TabPage_RI.Controls.Add( this.DataGrid_RI );
            this.TabPage_RI.Location = new System.Drawing.Point( 4, 24 );
            this.TabPage_RI.Name = "TabPage_RI";
            this.TabPage_RI.Size = new System.Drawing.Size( 333, 299 );
            this.TabPage_RI.TabIndex = 4;
            this.TabPage_RI.Text = "RI";
            this.TabPage_RI.UseVisualStyleBackColor = true;
            //
            // DataGrid_RI
            //
            this.DataGrid_RI.AllowUserToAddRows = false;
            this.DataGrid_RI.AllowUserToDeleteRows = false;
            this.DataGrid_RI.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGrid_RI.Location = new System.Drawing.Point( 6, 6 );
            this.DataGrid_RI.Name = "DataGrid_RI";
            this.DataGrid_RI.ReadOnly = true;
            this.DataGrid_RI.RowTemplate.Height = 24;
            this.DataGrid_RI.Size = new System.Drawing.Size( 321, 286 );
            this.DataGrid_RI.TabIndex = 4;
            //
            // TabPage_RO
            //
            this.TabPage_RO.Controls.Add( this.DataGrid_RO );
            this.TabPage_RO.Location = new System.Drawing.Point( 4, 24 );
            this.TabPage_RO.Name = "TabPage_RO";
            this.TabPage_RO.Size = new System.Drawing.Size( 333, 299 );
            this.TabPage_RO.TabIndex = 5;
            this.TabPage_RO.Text = "RO";
            this.TabPage_RO.UseVisualStyleBackColor = true;
            //
            // DataGrid_RO
            //
            this.DataGrid_RO.AllowUserToAddRows = false;
            this.DataGrid_RO.AllowUserToDeleteRows = false;
            this.DataGrid_RO.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGrid_RO.Location = new System.Drawing.Point( 6, 6 );
            this.DataGrid_RO.Name = "DataGrid_RO";
            this.DataGrid_RO.RowTemplate.Height = 24;
            this.DataGrid_RO.Size = new System.Drawing.Size( 321, 286 );
            this.DataGrid_RO.TabIndex = 4;
            this.DataGrid_RO.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler( this.RO_CellValueChanged );
            //
            // TabPage_VO
            //
            this.TabPage_VO.Controls.Add( this.DataGrid_VO );
            this.TabPage_VO.Location = new System.Drawing.Point( 4, 24 );
            this.TabPage_VO.Name = "TabPage_VO";
            this.TabPage_VO.Size = new System.Drawing.Size( 333, 299 );
            this.TabPage_VO.TabIndex = 6;
            this.TabPage_VO.Text = "VO";
            this.TabPage_VO.UseVisualStyleBackColor = true;
            //
            // DataGrid_VO
            //
            this.DataGrid_VO.AllowUserToAddRows = false;
            this.DataGrid_VO.AllowUserToDeleteRows = false;
            this.DataGrid_VO.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGrid_VO.Location = new System.Drawing.Point( 6, 6 );
            this.DataGrid_VO.Name = "DataGrid_VO";
            this.DataGrid_VO.RowTemplate.Height = 24;
            this.DataGrid_VO.Size = new System.Drawing.Size( 321, 286 );
            this.DataGrid_VO.TabIndex = 4;
            this.DataGrid_VO.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler( this.VO_CellValueChanged );
            //
            // Combo_PNS
            //
            this.Combo_PNS.Font = new System.Drawing.Font( "新細明體", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ( ( byte )( 136 ) ) );
            this.Combo_PNS.FormattingEnabled = true;
            this.Combo_PNS.Location = new System.Drawing.Point( 550, 113 );
            this.Combo_PNS.Margin = new System.Windows.Forms.Padding( 0 );
            this.Combo_PNS.Name = "Combo_PNS";
            this.Combo_PNS.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Combo_PNS.Size = new System.Drawing.Size( 90, 29 );
            this.Combo_PNS.TabIndex = 68;
            this.Combo_PNS.Text = "null";
            //
            // Combo_RSR
            //
            this.Combo_RSR.Font = new System.Drawing.Font( "新細明體", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ( ( byte )( 136 ) ) );
            this.Combo_RSR.FormattingEnabled = true;
            this.Combo_RSR.Location = new System.Drawing.Point( 415, 111 );
            this.Combo_RSR.Name = "Combo_RSR";
            this.Combo_RSR.Size = new System.Drawing.Size( 60, 29 );
            this.Combo_RSR.TabIndex = 66;
            this.Combo_RSR.Text = "null";
            this.Combo_RSR.SelectedIndexChanged += new System.EventHandler( this.comboBox1_SelectedIndexChanged );
            //
            // TextBox_ConnectionLevel
            //
            this.TextBox_ConnectionLevel.Font = new System.Drawing.Font( "新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ( ( byte )( 136 ) ) );
            this.TextBox_ConnectionLevel.Location = new System.Drawing.Point( 729, 109 );
            this.TextBox_ConnectionLevel.Multiline = true;
            this.TextBox_ConnectionLevel.Name = "TextBox_ConnectionLevel";
            this.TextBox_ConnectionLevel.ReadOnly = true;
            this.TextBox_ConnectionLevel.Size = new System.Drawing.Size( 180, 43 );
            this.TextBox_ConnectionLevel.TabIndex = 64;
            this.TextBox_ConnectionLevel.Text = "CONNECTION LEVEL - ";
            this.TextBox_ConnectionLevel.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            //
            // Bnt_SetBase
            //
            this.Bnt_SetBase.Location = new System.Drawing.Point( 1039, 51 );
            this.Bnt_SetBase.Name = "Bnt_SetBase";
            this.Bnt_SetBase.Size = new System.Drawing.Size( 31, 20 );
            this.Bnt_SetBase.TabIndex = 63;
            this.Bnt_SetBase.Text = "edit";
            this.Bnt_SetBase.UseVisualStyleBackColor = true;
            this.Bnt_SetBase.Click += new System.EventHandler( this.Bnt_SetBase_Click );
            //
            // Bnt_SetTool
            //
            this.Bnt_SetTool.Location = new System.Drawing.Point( 1039, 22 );
            this.Bnt_SetTool.Name = "Bnt_SetTool";
            this.Bnt_SetTool.Size = new System.Drawing.Size( 31, 20 );
            this.Bnt_SetTool.TabIndex = 13;
            this.Bnt_SetTool.Text = "edit";
            this.Bnt_SetTool.UseVisualStyleBackColor = true;
            this.Bnt_SetTool.Click += new System.EventHandler( this.Bnt_SetTool_Click );
            //
            // Combo_Tool
            //
            this.Combo_Tool.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Combo_Tool.FormattingEnabled = true;
            this.Combo_Tool.Location = new System.Drawing.Point( 985, 22 );
            this.Combo_Tool.Name = "Combo_Tool";
            this.Combo_Tool.Size = new System.Drawing.Size( 48, 20 );
            this.Combo_Tool.TabIndex = 62;
            this.Combo_Tool.DropDown += new System.EventHandler( this.Tool_DropDown );
            this.Combo_Tool.DropDownClosed += new System.EventHandler( this.Tool_DropDownClosed );
            this.Combo_Tool.SelectedValueChanged += new System.EventHandler( this.Tool_SelectedValueChanged );
            //
            // Combo_Base
            //
            this.Combo_Base.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Combo_Base.FormattingEnabled = true;
            this.Combo_Base.Location = new System.Drawing.Point( 985, 52 );
            this.Combo_Base.Name = "Combo_Base";
            this.Combo_Base.Size = new System.Drawing.Size( 48, 20 );
            this.Combo_Base.TabIndex = 61;
            this.Combo_Base.DropDown += new System.EventHandler( this.Base_DropDown );
            this.Combo_Base.DropDownClosed += new System.EventHandler( this.Base_DropDownClosed );
            this.Combo_Base.SelectedValueChanged += new System.EventHandler( this.Base_SelectedValueChanged );
            //
            // label3
            //
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font( "新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ( ( byte )( 136 ) ) );
            this.label3.Location = new System.Drawing.Point( 938, 22 );
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size( 37, 16 );
            this.label3.TabIndex = 60;
            this.label3.Text = "Tool";
            //
            // label2
            //
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font( "新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ( ( byte )( 136 ) ) );
            this.label2.Location = new System.Drawing.Point( 938, 52 );
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size( 38, 16 );
            this.label2.TabIndex = 59;
            this.label2.Text = "Base";
            //
            // label1
            //
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font( "新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ( ( byte )( 136 ) ) );
            this.label1.Location = new System.Drawing.Point( 913, 87 );
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size( 66, 16 );
            this.label1.TabIndex = 58;
            this.label1.Text = "Jog Type";
            //
            // ComboBox_JogType
            //
            this.ComboBox_JogType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_JogType.FormattingEnabled = true;
            this.ComboBox_JogType.Location = new System.Drawing.Point( 985, 87 );
            this.ComboBox_JogType.Name = "ComboBox_JogType";
            this.ComboBox_JogType.Size = new System.Drawing.Size( 85, 20 );
            this.ComboBox_JogType.TabIndex = 57;
            this.ComboBox_JogType.SelectedIndexChanged += new System.EventHandler( this.ComboBox_JogType_SelectedIndexChanged );
            //
            // Label_Jog6
            //
            this.Label_Jog6.AutoSize = true;
            this.Label_Jog6.Font = new System.Drawing.Font( "新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ( ( byte )( 136 ) ) );
            this.Label_Jog6.Location = new System.Drawing.Point( 938, 504 );
            this.Label_Jog6.Name = "Label_Jog6";
            this.Label_Jog6.Size = new System.Drawing.Size( 27, 16 );
            this.Label_Jog6.TabIndex = 56;
            this.Label_Jog6.Text = "A6";
            //
            // Label_Jog5
            //
            this.Label_Jog5.AutoSize = true;
            this.Label_Jog5.Font = new System.Drawing.Font( "新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ( ( byte )( 136 ) ) );
            this.Label_Jog5.Location = new System.Drawing.Point( 938, 433 );
            this.Label_Jog5.Name = "Label_Jog5";
            this.Label_Jog5.Size = new System.Drawing.Size( 27, 16 );
            this.Label_Jog5.TabIndex = 55;
            this.Label_Jog5.Text = "A5";
            //
            // Label_Jog4
            //
            this.Label_Jog4.AutoSize = true;
            this.Label_Jog4.Font = new System.Drawing.Font( "新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ( ( byte )( 136 ) ) );
            this.Label_Jog4.Location = new System.Drawing.Point( 938, 361 );
            this.Label_Jog4.Name = "Label_Jog4";
            this.Label_Jog4.Size = new System.Drawing.Size( 27, 16 );
            this.Label_Jog4.TabIndex = 54;
            this.Label_Jog4.Text = "A4";
            //
            // Label_Jog3
            //
            this.Label_Jog3.AutoSize = true;
            this.Label_Jog3.Font = new System.Drawing.Font( "新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ( ( byte )( 136 ) ) );
            this.Label_Jog3.Location = new System.Drawing.Point( 938, 294 );
            this.Label_Jog3.Name = "Label_Jog3";
            this.Label_Jog3.Size = new System.Drawing.Size( 27, 16 );
            this.Label_Jog3.TabIndex = 53;
            this.Label_Jog3.Text = "A3";
            //
            // Label_Jog2
            //
            this.Label_Jog2.AutoSize = true;
            this.Label_Jog2.Font = new System.Drawing.Font( "新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ( ( byte )( 136 ) ) );
            this.Label_Jog2.Location = new System.Drawing.Point( 938, 230 );
            this.Label_Jog2.Name = "Label_Jog2";
            this.Label_Jog2.Size = new System.Drawing.Size( 27, 16 );
            this.Label_Jog2.TabIndex = 52;
            this.Label_Jog2.Text = "A2";
            //
            // Label_Jog1
            //
            this.Label_Jog1.AutoSize = true;
            this.Label_Jog1.Font = new System.Drawing.Font( "新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ( ( byte )( 136 ) ) );
            this.Label_Jog1.Location = new System.Drawing.Point( 938, 171 );
            this.Label_Jog1.Name = "Label_Jog1";
            this.Label_Jog1.Size = new System.Drawing.Size( 27, 16 );
            this.Label_Jog1.TabIndex = 51;
            this.Label_Jog1.Text = "A1";
            //
            // PosTimer
            //
            this.PosTimer.Interval = 1000;
            this.PosTimer.Tick += new System.EventHandler( this.PosTimer_Tick );
            //
            // ToolBase_Timer
            //
            this.ToolBase_Timer.Interval = 500;
            this.ToolBase_Timer.Tick += new System.EventHandler( this.ToolBase_Timer_Tick );
            //
            // ConnectionLevel_timer
            //
            this.ConnectionLevel_timer.Interval = 500;
            this.ConnectionLevel_timer.Tick += new System.EventHandler( this.ConnectionLevel_timer_Tick );
            //
            // Joint_Timer
            //
            this.Joint_Timer.Interval = 17;
            this.Joint_Timer.Tick += new System.EventHandler( this.Joint_Timer_Tick );
            //
            // openFileDialogUpdateFile
            //
            this.openFileDialogUpdateFile.Filter = "|*.exe";
            this.openFileDialogUpdateFile.Title = "Choose update package";
            //
            // DeviceTabControll
            //
            this.AutoScaleDimensions = new System.Drawing.SizeF( 6F, 12F );
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add( this.panel1 );
            this.Name = "DeviceTabControll";
            this.Size = new System.Drawing.Size( 1135, 584 );
            this.Panel_ErrorInfo.ResumeLayout( false );
            this.Panel_ErrorInfo.PerformLayout();
            this.Tab_RobotInfo.ResumeLayout( false );
            this.Tab_Pos.ResumeLayout( false );
            ( ( System.ComponentModel.ISupportInitialize )( this.DataGrid_Pos ) ).EndInit();
            this.Tab_Timer.ResumeLayout( false );
            ( ( System.ComponentModel.ISupportInitialize )( this.DataGrid_Timer ) ).EndInit();
            this.Tab_Counter.ResumeLayout( false );
            ( ( System.ComponentModel.ISupportInitialize )( this.DataGrid_Counter ) ).EndInit();
            this.Tab_PR.ResumeLayout( false );
            ( ( System.ComponentModel.ISupportInitialize )( this.DataGrid_PR ) ).EndInit();
            this.groupBox3.ResumeLayout( false );
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout( false );
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout( false );
            this.groupBox1.PerformLayout();
            this.groupBox_Override.ResumeLayout( false );
            this.groupBox_Override.PerformLayout();
            this.Panel_DeviceInfo.ResumeLayout( false );
            this.Panel_DeviceInfo.PerformLayout();
            this.JogPanel.ResumeLayout( false );
            this.panel1.ResumeLayout( false );
            this.panel1.PerformLayout();
            this.Tab_IO.ResumeLayout( false );
            this.TabPage_DI.ResumeLayout( false );
            ( ( System.ComponentModel.ISupportInitialize )( this.DataGrid_DI ) ).EndInit();
            this.TabPage_DO.ResumeLayout( false );
            ( ( System.ComponentModel.ISupportInitialize )( this.DataGrid_DO ) ).EndInit();
            this.TabPage_FI.ResumeLayout( false );
            ( ( System.ComponentModel.ISupportInitialize )( this.DataGrid_FI ) ).EndInit();
            this.TabPage_FO.ResumeLayout( false );
            ( ( System.ComponentModel.ISupportInitialize )( this.DataGrid_FO ) ).EndInit();
            this.TabPage_RI.ResumeLayout( false );
            ( ( System.ComponentModel.ISupportInitialize )( this.DataGrid_RI ) ).EndInit();
            this.TabPage_RO.ResumeLayout( false );
            ( ( System.ComponentModel.ISupportInitialize )( this.DataGrid_RO ) ).EndInit();
            this.TabPage_VO.ResumeLayout( false );
            ( ( System.ComponentModel.ISupportInitialize )( this.DataGrid_VO ) ).EndInit();
            this.ResumeLayout( false );

        }

        #endregion

        private System.Windows.Forms.Button Bnt_SafetyState;
        private System.Windows.Forms.Button Bnt_Clean;
        private System.Windows.Forms.Panel Panel_ErrorInfo;
        private System.Windows.Forms.TabControl Tab_RobotInfo;
        private System.Windows.Forms.TabPage Tab_Pos;
        private System.Windows.Forms.DataGridView DataGrid_Pos;
        private System.Windows.Forms.TabPage Tab_Timer;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ProgressBar Bar_Acc;
        private System.Windows.Forms.TextBox TextBox_Acc;
        private System.Windows.Forms.Button Bnt_AccDown;
        private System.Windows.Forms.Button Bnt_AccUp;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ProgressBar Bar_Ptp;
        private System.Windows.Forms.TextBox TextBox_Ptp;
        private System.Windows.Forms.Button Bnt_PtpUp;
        private System.Windows.Forms.Button Bnt_PtpDown;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ProgressBar Bar_Lin;
        private System.Windows.Forms.TextBox TextBox_Lin;
        private System.Windows.Forms.Button Bnt_LinUp;
        private System.Windows.Forms.Button Bnt_LinDown;
        private System.Windows.Forms.GroupBox groupBox_Override;
        private System.Windows.Forms.ProgressBar Bar_Override;
        private System.Windows.Forms.TextBox TextBox_Override;
        private System.Windows.Forms.Button Btn_OverrideUp;
        private System.Windows.Forms.Button Btn_OverrideDown;
        private System.Windows.Forms.Button Bnt_Home;
        private System.Windows.Forms.Button But_Stop;
        private System.Windows.Forms.Button Bnt_Pause;
        private System.Windows.Forms.Button Bnt_Go;
        private System.Windows.Forms.Panel Panel_DeviceInfo;
        private System.Windows.Forms.Label Label_Utilization;
        private System.Windows.Forms.Label Label_UtilizationRatio;
        private System.Windows.Forms.Label Label_Birthday;
        private System.Windows.Forms.Label Label_RobotType;
        private System.Windows.Forms.Label Label_OperationTime;
        private System.Windows.Forms.Label Label_HRSS_version;
        private System.Windows.Forms.Panel JogPanel;
        private System.Windows.Forms.Button JogPositive6;
        private System.Windows.Forms.Button JogNeg1;
        private System.Windows.Forms.Button JogNeg5;
        private System.Windows.Forms.Button JogPositive3;
        private System.Windows.Forms.Button JogNeg2;
        private System.Windows.Forms.Button JogPositive2;
        private System.Windows.Forms.Button JogNeg4;
        private System.Windows.Forms.Button JogPositive5;
        private System.Windows.Forms.Button JogNeg6;
        private System.Windows.Forms.Button JogPositive4;
        private System.Windows.Forms.Button JogNeg3;
        private System.Windows.Forms.Button JogPositive1;
        private System.Windows.Forms.Button Bnt_Servo;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox ComboBox_JogType;
        private System.Windows.Forms.Label Label_Jog6;
        private System.Windows.Forms.Label Label_Jog5;
        private System.Windows.Forms.Label Label_Jog4;
        private System.Windows.Forms.Label Label_Jog3;
        private System.Windows.Forms.Label Label_Jog2;
        private System.Windows.Forms.Label Label_Jog1;
        public System.Windows.Forms.Timer PosTimer;
        private System.Windows.Forms.TextBox TextBox_ErrorInfo;
        private System.Windows.Forms.TabPage Tab_Counter;
        private System.Windows.Forms.DataGridView DataGrid_Timer;
        private System.Windows.Forms.DataGridView DataGrid_Counter;
        private System.Windows.Forms.TabPage Tab_PR;
        private System.Windows.Forms.DataGridView DataGrid_PR;
        private System.Windows.Forms.ComboBox Combo_Tool;
        private System.Windows.Forms.ComboBox Combo_Base;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.Timer ToolBase_Timer;
        private System.Windows.Forms.Button Bnt_SetBase;
        private System.Windows.Forms.Button Bnt_SetTool;
        public System.Windows.Forms.Timer ConnectionLevel_timer;
        private System.Windows.Forms.TextBox TextBox_ConnectionLevel;
        private System.Windows.Forms.ComboBox Combo_PNS;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox Combo_RSR;
        private System.Windows.Forms.Button Bnt_RsrGo;
        private System.Windows.Forms.TabControl Tab_IO;
        private System.Windows.Forms.TabPage TabPage_DI;
        private System.Windows.Forms.TabPage TabPage_DO;
        private System.Windows.Forms.TabPage TabPage_FI;
        private System.Windows.Forms.TabPage TabPage_FO;
        private System.Windows.Forms.TabPage TabPage_RI;
        private System.Windows.Forms.TabPage TabPage_RO;
        private System.Windows.Forms.TabPage TabPage_VO;
        private System.Windows.Forms.DataGridView DataGrid_DI;
        private System.Windows.Forms.DataGridView DataGrid_DO;
        private System.Windows.Forms.DataGridView DataGrid_FI;
        private System.Windows.Forms.DataGridView DataGrid_FO;
        private System.Windows.Forms.DataGridView DataGrid_RI;
        private System.Windows.Forms.DataGridView DataGrid_RO;
        private System.Windows.Forms.DataGridView DataGrid_VO;
        public System.Windows.Forms.Timer Joint_Timer;
        private System.Windows.Forms.TextBox TextBox_ProgramName;
        private System.Windows.Forms.Label Label_RobotID;
        private System.Windows.Forms.Button Bnt_SetRobotId;
        private System.Windows.Forms.TextBox TextBox_RobotID;
        private System.Windows.Forms.Button Btn_UpdateHRSS;
        private System.Windows.Forms.OpenFileDialog openFileDialogUpdateFile;
        private System.Windows.Forms.RadioButton Radio_controller;
        private System.Windows.Forms.RadioButton Radio_monitor;
        private System.Windows.Forms.Label label4;
    }
}
