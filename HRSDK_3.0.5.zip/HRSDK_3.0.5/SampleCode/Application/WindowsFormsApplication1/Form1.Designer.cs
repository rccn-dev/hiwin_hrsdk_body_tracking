﻿namespace WindowsFormsApplication1 {
    partial class Form1 {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose( bool disposing ) {
            if ( disposing && ( components != null ) ) {
                components.Dispose();
            }
            base.Dispose( disposing );
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent() {
            this.button1 = new System.Windows.Forms.Button();
            this.TabControll_DeviceList = new System.Windows.Forms.TabControl();
            this.TextBox_DeviceIP = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.Radio_Auto = new System.Windows.Forms.RadioButton();
            this.Radio_Manual = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.Text_DeviceIP = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.Label_HRSDK_version = new System.Windows.Forms.Label();
            this.Panel_OpenGl = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            //
            // button1
            //
            this.button1.Location = new System.Drawing.Point( 217, 18 );
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size( 80, 76 );
            this.button1.TabIndex = 0;
            this.button1.Text = "Add";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler( this.button1_Click );
            //
            // TabControll_DeviceList
            //
            this.TabControll_DeviceList.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TabControll_DeviceList.DrawMode = System.Windows.Forms.TabDrawMode.OwnerDrawFixed;
            this.TabControll_DeviceList.Location = new System.Drawing.Point( 1, 126 );
            this.TabControll_DeviceList.Name = "TabControll_DeviceList";
            this.TabControll_DeviceList.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.TabControll_DeviceList.SelectedIndex = 0;
            this.TabControll_DeviceList.Size = new System.Drawing.Size( 1096, 627 );
            this.TabControll_DeviceList.TabIndex = 18;
            this.TabControll_DeviceList.DrawItem += new System.Windows.Forms.DrawItemEventHandler( this.DrawTab );
            this.TabControll_DeviceList.SelectedIndexChanged += new System.EventHandler( this.TabIndex_Changed );
            this.TabControll_DeviceList.TabIndexChanged += new System.EventHandler( this.TabIndex_Changed );
            this.TabControll_DeviceList.MouseDown += new System.Windows.Forms.MouseEventHandler( this.Mouse_Down );
            //
            // TextBox_DeviceIP
            //
            this.TextBox_DeviceIP.Location = new System.Drawing.Point( 61, 22 );
            this.TextBox_DeviceIP.Name = "TextBox_DeviceIP";
            this.TextBox_DeviceIP.Size = new System.Drawing.Size( 136, 22 );
            this.TextBox_DeviceIP.TabIndex = 19;
            //
            // panel1
            //
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add( this.groupBox4 );
            this.panel1.Location = new System.Drawing.Point( 683, 12 );
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size( 371, 108 );
            this.panel1.TabIndex = 20;
            //
            // groupBox4
            //
            this.groupBox4.Controls.Add( this.Radio_Auto );
            this.groupBox4.Controls.Add( this.Radio_Manual );
            this.groupBox4.Controls.Add( this.label2 );
            this.groupBox4.Controls.Add( this.button1 );
            this.groupBox4.Controls.Add( this.TextBox_DeviceIP );
            this.groupBox4.Controls.Add( this.Text_DeviceIP );
            this.groupBox4.Location = new System.Drawing.Point( 3, 3 );
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size( 303, 100 );
            this.groupBox4.TabIndex = 22;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Connect";
            //
            // Radio_Auto
            //
            this.Radio_Auto.AutoSize = true;
            this.Radio_Auto.Font = new System.Drawing.Font( "新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ( ( byte )( 136 ) ) );
            this.Radio_Auto.Location = new System.Drawing.Point( 145, 62 );
            this.Radio_Auto.Name = "Radio_Auto";
            this.Radio_Auto.Size = new System.Drawing.Size( 57, 20 );
            this.Radio_Auto.TabIndex = 26;
            this.Radio_Auto.Text = "Auto";
            this.Radio_Auto.UseVisualStyleBackColor = true;
            this.Radio_Auto.CheckedChanged += new System.EventHandler( this.Radio_Auto_CheckedChanged );
            //
            // Radio_Manual
            //
            this.Radio_Manual.AutoSize = true;
            this.Radio_Manual.Font = new System.Drawing.Font( "新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ( ( byte )( 136 ) ) );
            this.Radio_Manual.Location = new System.Drawing.Point( 61, 62 );
            this.Radio_Manual.Name = "Radio_Manual";
            this.Radio_Manual.Size = new System.Drawing.Size( 73, 20 );
            this.Radio_Manual.TabIndex = 25;
            this.Radio_Manual.Text = "Manual";
            this.Radio_Manual.UseVisualStyleBackColor = true;
            this.Radio_Manual.CheckedChanged += new System.EventHandler( this.Radio_Manual_CheckedChanged );
            //
            // label2
            //
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font( "新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ( ( byte )( 136 ) ) );
            this.label2.Location = new System.Drawing.Point( 7, 62 );
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size( 52, 16 );
            this.label2.TabIndex = 24;
            this.label2.Text = "Mode: ";
            this.label2.UseMnemonic = false;
            //
            // Text_DeviceIP
            //
            this.Text_DeviceIP.AutoSize = true;
            this.Text_DeviceIP.Location = new System.Drawing.Point( 6, 30 );
            this.Text_DeviceIP.Name = "Text_DeviceIP";
            this.Text_DeviceIP.Size = new System.Drawing.Size( 56, 12 );
            this.Text_DeviceIP.TabIndex = 20;
            this.Text_DeviceIP.Text = "Device IP: ";
            this.Text_DeviceIP.UseMnemonic = false;
            //
            // panel4
            //
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add( this.Label_HRSDK_version );
            this.panel4.Location = new System.Drawing.Point( 177, 12 );
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size( 485, 108 );
            this.panel4.TabIndex = 19;
            //
            // Label_HRSDK_version
            //
            this.Label_HRSDK_version.AutoSize = true;
            this.Label_HRSDK_version.Font = new System.Drawing.Font( "標楷體", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ( ( byte )( 136 ) ) );
            this.Label_HRSDK_version.Location = new System.Drawing.Point( 4, 10 );
            this.Label_HRSDK_version.Name = "Label_HRSDK_version";
            this.Label_HRSDK_version.Size = new System.Drawing.Size( 175, 21 );
            this.Label_HRSDK_version.TabIndex = 0;
            this.Label_HRSDK_version.Text = "HRSDK VERSION: ";
            //
            // Panel_OpenGl
            //
            this.Panel_OpenGl.Location = new System.Drawing.Point( 1103, 126 );
            this.Panel_OpenGl.Name = "Panel_OpenGl";
            this.Panel_OpenGl.Size = new System.Drawing.Size( 435, 567 );
            this.Panel_OpenGl.TabIndex = 21;
            //
            // Form1
            //
            this.AutoScaleDimensions = new System.Drawing.SizeF( 6F, 12F );
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size( 1550, 693 );
            this.Controls.Add( this.Panel_OpenGl );
            this.Controls.Add( this.panel4 );
            this.Controls.Add( this.panel1 );
            this.Controls.Add( this.TabControll_DeviceList );
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler( this.Form_Closing );
            this.Load += new System.EventHandler( this.Form_loing );
            this.panel1.ResumeLayout( false );
            this.groupBox4.ResumeLayout( false );
            this.groupBox4.PerformLayout();
            this.panel4.ResumeLayout( false );
            this.panel4.PerformLayout();
            this.ResumeLayout( false );

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TabControl TabControll_DeviceList;
        private System.Windows.Forms.TextBox TextBox_DeviceIP;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label Text_DeviceIP;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label Label_HRSDK_version;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Panel Panel_OpenGl;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton Radio_Auto;
        private System.Windows.Forms.RadioButton Radio_Manual;
    }
}

