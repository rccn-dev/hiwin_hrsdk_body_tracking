﻿Imports System.Text
Imports System.Threading

Module Module1
    Private Sub EventFun(command As UInt16, result As UInt16, ByRef msg As UInt16, length As Integer)
    End Sub
    Public callback As HRobot.CallBackFun
    Public device_id As Integer
    Sub Main()
        callback = New HRobot.CallBackFun(AddressOf EventFun)
        Dim SDK_ver As StringBuilder = New StringBuilder()
        Dim HRS_ver As StringBuilder = New StringBuilder()
        HRobot.get_hrsdk_version(SDK_ver)
        Console.WriteLine("SDK version: " & SDK_ver.ToString())
        device_id = HRobot.open_connection("127.0.0.1", 1, callback)
        If (device_id >= 0) Then
            HRobot.get_hrss_version(device_id, HRS_ver)
            Console.WriteLine("HRS version: " & HRS_ver.ToString())
            Console.WriteLine("connect successful.")
            CIRCmotion(device_id, callback)
            Console.WriteLine(" Press ""Enter"" key to quit the program.")
            Console.ReadLine()
            HRobot.disconnect(device_id)
        Else
            Console.WriteLine("connect failure.")
        End If
    End Sub
    Sub CIRCmotion(device_id As Integer, callback As HRobot.CallBackFun)
        HRobot.set_override_ratio(device_id, 100)

        If HRobot.get_motor_state(device_id) Then
            HRobot.set_motor_state(device_id, 1)
            Thread.Sleep(3000)
        End If

        Dim cp1() As Double = {-90, 400, -90, 0, 0, 0}
        Dim cp2() As Double = {-60, 350, -90, 0, 0, 0}
        Dim cp3() As Double = {30, 300, -90, 0, 0, 0}
        Dim cp4() As Double = {-75, 350, -90, 0, 0, 0}
        Dim cp5() As Double = {26, -80, -90, 0, 0, 0}
        Dim cp6() As Double = {32, -70, -90, 0, 0, 0}
        Dim cp7() As Double = {41, -70, -90, 0, 0, 0}
        Dim cp8() As Double = {37, -83, -90, 0, 0, 0}
        Dim Home() As Double = {0, 0, 0, 0, -90, 0}
        Dim ext_pos() As Double = {0, 0, 0}

        Console.WriteLine("run CIRC motion.")
        HRobot.set_override_ratio(device_id, 100)
        HRobot.ptp_axis(device_id, 0, Home)

        HRobot.ptp_pos(device_id, 0, cp1)
        HRobot.circ_pos(device_id, 0, cp2, cp3) ' circ motion
        HRobot.circ_pos(device_id, 0, cp4, cp1)
        HRobot.circ_axis(device_id, 0, cp5, cp6)
        HRobot.circ_axis(device_id, 0, cp7, cp8)
        HRobot.set_pr(device_id, 2, 0, cp2, ext_pos, 0, 0)
        HRobot.set_pr(device_id, 3, 0, cp3, ext_pos, 0, 0)
        HRobot.circ_pr(device_id, 0, 2, 3)
        Thread.Sleep(5000)

    End Sub


End Module
