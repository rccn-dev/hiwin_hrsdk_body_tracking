﻿Imports System.Text
Imports System.Threading

Module Module1
    Private Sub EventFun(command As UInt16, result As UInt16, ByRef msg As UInt16, length As Integer)
    End Sub

    Public callback As HRobot.CallBackFun
    Public device_id As Integer
    Sub Main()
        callback = New HRobot.CallBackFun(AddressOf EventFun)
        Dim SDK_ver As StringBuilder = New StringBuilder()
        Dim HRS_ver As StringBuilder = New StringBuilder()
        HRobot.get_hrsdk_version(SDK_ver)
        Console.WriteLine("SDK version: " & SDK_ver.ToString())
        device_id = HRobot.open_connection("127.0.0.1", 1, callback)
        If (device_id >= 0) Then
            HRobot.get_hrss_version(device_id, HRS_ver)
            Console.WriteLine("HRS version: " & HRS_ver.ToString())
            Console.WriteLine("connect successful.")
            LINmotion(device_id, callback)

            Console.WriteLine(" Press ""Enter"" key to quit the program.")
            Console.ReadLine()
            HRobot.disconnect(device_id)
        Else
            Console.WriteLine("connect failure.")
        End If
    End Sub

    Function wait_for_stop_motion(device_id As Integer)
        While (HRobot.get_motion_state(device_id) <> 1)
            If (HRobot.get_connection_level(device_id) = -1) Then
                Return False  ' The robot Is Not connected anymore
            End If
            Thread.Sleep(200)
        End While
        Return True
    End Function

    Sub run_lin_pos(device_id As Integer, pos()() As Double, mode As Integer, smooth_value As Double)
        HRobot.lin_pos(device_id, mode, smooth_value, pos(0))
        HRobot.lin_pos(device_id, mode, smooth_value, pos(1))
        HRobot.lin_pos(device_id, mode, smooth_value, pos(2))
        HRobot.lin_pos(device_id, mode, smooth_value, pos(3))
        HRobot.lin_pos(device_id, mode, smooth_value, pos(0))
        wait_for_stop_motion(device_id)
    End Sub

    Sub LINmotion(device_id As Integer, callback As HRobot.CallBackFun)
        HRobot.set_override_ratio(device_id, 100)


        If HRobot.get_motor_state(device_id) = 0 Then
            HRobot.set_motor_state(device_id, 1)
            Thread.Sleep(3000)
        End If

        Dim pos As Double()() = {
                New Double() {-150, 450, -50, 0, 0, 0},
                New Double() {150, 450, -100, 0, 0, 0},
                New Double() {150, 300, -150, 0, 0, 0},
                New Double() {-150, 300, -200, 0, 0, 0}
            }
        Dim rel_pos As Double()() = {
                New Double() {0, -200, 0, 0, 0, 0},
                New Double() {0, 100, 0, 0, 0, 0},
                New Double() {-50, 0, 0, 0, 0, 0},
                New Double() {0, -100, 0, 0, 0, 0},
                New Double() {0, 200, 0, 0, 0, 0},
                New Double() {-50, 0, 0, 0, 0, 0},
                New Double() {0, -200, 0, 0, 0, 0}
            }

        HRobot.jog_home(device_id)
        wait_for_stop_motion(device_id)

        'lin motion
        Console.WriteLine("Run line position. ")
        run_lin_pos(device_id, pos, 0, 0)

        Console.WriteLine("Run line relative position ")
        Dim lin_rel_home As Double() = {0, 480, -60, 0, 0, 0}
        Dim ext_pos As Double() = {0, 0, 0}
        HRobot.lin_pos(device_id, 0, 0, lin_rel_home)
        Thread.Sleep(1000)
        For i As Integer = 0 To rel_pos.Length - 1
            HRobot.lin_rel_pos(device_id, 0, 0, rel_pos(i))
            wait_for_stop_motion(device_id)
        Next

        ' rel_pr
        Console.WriteLine("Run line point register ")
        HRobot.set_pr(device_id, 1, 0, lin_rel_home, ext_pos, 0, 0)
        HRobot.lin_pr(device_id, 0, 0, 1)
        wait_for_stop_motion(device_id)

    End Sub
End Module
