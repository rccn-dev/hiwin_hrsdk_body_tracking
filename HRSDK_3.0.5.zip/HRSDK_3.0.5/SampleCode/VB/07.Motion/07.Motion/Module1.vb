﻿Imports System.Text
Imports System.Threading

Module Module1
    Private Sub EventFun(command As UInt16, result As UInt16, ByRef msg As UInt16, length As Integer)
    End Sub
    Public callback As HRobot.CallBackFun
    Public device_id As Integer
    Sub Main()
        callback = New HRobot.CallBackFun(AddressOf EventFun)
        Dim SDK_ver As StringBuilder = New StringBuilder()
        Dim HRS_ver As StringBuilder = New StringBuilder()
        HRobot.get_hrsdk_version(SDK_ver)
        Console.WriteLine("SDK version: " & SDK_ver.ToString())
        device_id = HRobot.open_connection("127.0.0.1", 1, callback)
        If (device_id >= 0) Then
            HRobot.get_hrss_version(device_id, HRS_ver)
            Console.WriteLine("HRS version: " & HRS_ver.ToString())
            Console.WriteLine("connect successful.")

            Motion(device_id, callback)
            Console.WriteLine(" Press ""Enter"" key to quit the program.")
            Console.ReadLine()
            HRobot.disconnect(device_id)
        Else
            Console.WriteLine("connect failure.")
        End If
    End Sub

    Function wait_for_stop_motion(device_id As Integer)
        While (HRobot.get_motion_state(device_id) <> 1)
            If (HRobot.get_connection_level(device_id) = -1) Then
                Return False  ' The robot Is Not connected anymore
            End If
            Thread.Sleep(200)
        End While
        Return True
    End Function

    Sub Motion(device_id As Integer, callback As HRobot.CallBackFun)
        If HRobot.get_motor_state(device_id) Then
            HRobot.set_motor_state(device_id, 1)
            Thread.Sleep(3000)
        End If

        Dim cp1() As Double = {-90, 400, -90, 0, 0, 0}
        Dim cp2() As Double = {-60, 350, -90, 0, 0, 0}
        Dim cp3() As Double = {30, 300, -90, 0, 0, 0}
        Dim cp4() As Double = {-75, 350, -90, 0, 0, 0}
        Dim cp5() As Double = {26, -80, -90, 0, 0, 0}
        Dim cp6() As Double = {32, -70, -90, 0, 0, 0}
        Dim cp7() As Double = {41, -70, -90, 0, 0, 0}
        Dim cp8() As Double = {37, -83, -90, 0, 0, 0}
        Dim Home() As Double = {0, 0, 0, 0, -90, 0}

        HRobot.set_override_ratio(device_id, 60)
        HRobot.ptp_pos(device_id, 0, cp1)
        wait_for_stop_motion(device_id)

        HRobot.circ_pos(device_id, 0, cp2, cp3) 'circ motion
        Thread.Sleep(1000)
        Console.WriteLine("motion hold ")
        HRobot.motion_hold(device_id)
        Thread.Sleep(2000)
        Console.WriteLine("motion continue ")
        HRobot.motion_continue(device_id)
        HRobot.circ_pos(device_id, 0, cp4, cp1)
        Thread.Sleep(1000)
        Console.WriteLine("motion abort ")
        HRobot.motion_abort(device_id)
        Thread.Sleep(1000)
        Console.WriteLine("motion delay 2 senconds.")

        HRobot.motion_delay(device_id, 2000)
        HRobot.circ_axis(device_id, 1, cp5, cp6)
        HRobot.circ_axis(device_id, 1, cp7, cp8)
        Console.WriteLine("waiting 2 senconds. ")
        Thread.Sleep(5000)
    End Sub

End Module
