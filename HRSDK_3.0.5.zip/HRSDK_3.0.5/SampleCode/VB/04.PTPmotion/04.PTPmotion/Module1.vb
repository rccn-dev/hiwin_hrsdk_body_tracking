﻿Imports System.Threading
Imports System.Text

Module Module1
    Private Sub EventFun(command As UInt16, result As UInt16, ByRef msg As UInt16, length As Integer)
    End Sub
    Public callback As HRobot.CallBackFun
    Public device_id As Integer
    Sub Main()
        callback = New HRobot.CallBackFun(AddressOf EventFun)
        Dim SDK_ver As StringBuilder = New StringBuilder()
        Dim HRS_ver As StringBuilder = New StringBuilder()
        HRobot.get_hrsdk_version(SDK_ver)
        Console.WriteLine("SDK version: " & SDK_ver.ToString())
        device_id = HRobot.open_connection("127.0.0.1", 1, callback)
        If (device_id >= 0) Then
            HRobot.get_hrss_version(device_id, HRS_ver)
            Console.WriteLine("HRS version: " & HRS_ver.ToString())
            Console.WriteLine("connect successful.")
            PTPMotion(device_id, callback)
        Else
            Console.WriteLine("connect failure.")
        End If
        Console.WriteLine(" Press ""Enter"" key to quit the program.")
        Console.ReadLine()
        HRobot.disconnect(device_id)
    End Sub
    Sub PTPMotion(device_id As Integer, callback As HRobot.CallBackFun)
        HRobot.set_override_ratio(device_id, 100)
        If (HRobot.get_motor_state(device_id) = 0) Then
            HRobot.set_motor_state(device_id, 1)   'Servo On
            Thread.Sleep(3000)
        End If


        Dim pos() As Double = {0, 300, -100, 0, 0, 0}
        Const pointNum As Integer = 8
        Dim pointIdx As Integer = 0
        Dim x(pointNum)
        Dim y(pointNum)
        Dim z(pointNum)
        Dim xoffset As Integer = 20
        Dim zoffset As Integer = 10


        x(pointIdx) = pos(0)
        y(pointIdx) = pos(1)
        z(pointIdx) = pos(2)
        pointIdx += 1

        x(pointIdx) = pos(0) + xoffset
        y(pointIdx) = pos(1)
        z(pointIdx) = pos(2)
        pointIdx += 1

        x(pointIdx) = pos(0) + xoffset
        y(pointIdx) = pos(1)
        z(pointIdx) = pos(2) - zoffset
        pointIdx += 1

        x(pointIdx) = pos(0) + xoffset
        y(pointIdx) = pos(1)
        z(pointIdx) = pos(2)
        pointIdx += 1

        x(pointIdx) = pos(0) - xoffset
        y(pointIdx) = pos(1)
        z(pointIdx) = pos(2)
        pointIdx += 1

        x(pointIdx) = pos(0) - xoffset
        y(pointIdx) = pos(1)
        z(pointIdx) = pos(2) - zoffset
        pointIdx += 1

        x(pointIdx) = pos(0) - xoffset
        y(pointIdx) = pos(1)
        z(pointIdx) = pos(2)
        pointIdx += 1

        x(pointIdx) = pos(0)
        y(pointIdx) = pos(1)
        z(pointIdx) = pos(2)

        'ptp motion
        Dim a As Integer = 0
        For a = 0 To pointNum - 1
            pos(0) = x(a)
            pos(1) = y(a)
            pos(2) = z(a)
            While (HRobot.get_command_count(device_id) > 100)
                Thread.Sleep(500)
            End While
            HRobot.ptp_pos(device_id, 1, pos)
        Next
        Thread.Sleep(5000)
        'ptp motion
        For a = 0 To pointNum - 1
            pos(0) = x(a)
            pos(1) = y(a) - 300
            pos(2) = z(a)
            While (HRobot.get_command_count(device_id) > 100)
                Thread.Sleep(500)
            End While
            HRobot.ptp_axis(device_id, 1, pos)
        Next
        Thread.Sleep(5000)
        pos(1) = 0
        'rel_pos
        Thread.Sleep(500)
        HRobot.ptp_rel_pos(device_id, 1, pos)
        'rel_axis
        Thread.Sleep(500)
        HRobot.ptp_rel_axis(device_id, 1, pos)
        HRobot.ptp_pr(device_id, 1, 1)
    End Sub
End Module
